export const kejahatanSiberArticles = [
  {
    slug: "kejahatan-aset-kripto",
    title: "Peran Polri dalam Pencegahan Kejahatan Aset Kripto",
    description: "Aset kripto seperti Bitcoin dan Ethereum menawarkan inovasi, namun juga membuka celah baru bagi aktivitas kejahatan siber seperti pencucian uang, penipuan, dan pendanaan terorisme.",
    image_description: "Logo Bitcoin dan Ethereum dengan borgol di atasnya, menggambarkan penegakan hukum terhadap kejahatan kripto.",
    category: "Kejahatan Siber",
    date: "2025-06-10",
    content: `
      <p class="mb-4">Ledakan popularitas aset kripto seperti Bitcoin, Ethereum, dan ribuan altcoin lainnya tidak hanya mengubah lanskap keuangan global, tetapi juga membuka kotak Pandora bagi bentuk-bentuk kejahatan siber yang semakin canggih. Sifatnya yang anonim, terdesentralisasi, dan tanpa batas negara menjadikannya alat yang menarik bagi pelaku kejahatan untuk melakukan pencucian uang, penipuan investasi, hingga pendanaan terorisme. Kepolisian Negara Republik Indonesia (Polri), khususnya melalui Direktorat Tindak Pidana Siber (Dittipidsiber), menghadapi tantangan baru yang memerlukan pendekatan multi-cabang untuk mitigasi dan penegakan hukum.</p>
      
      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Modus Operandi Kejahatan Kripto</h3>
      <ul class="list-disc list-inside space-y-2 text-gray-700 mb-4 pl-4">
        <li><strong>Penipuan Investasi (Scam):</strong> Skema Ponzi atau piramida berkedok investasi kripto dengan janji keuntungan tidak realistis (misalnya, kasus BitConnect).</li>
        <li><strong>Pencucian Uang (Money Laundering):</strong> Memindahkan dana hasil kejahatan melalui berbagai jenis koin dan dompet digital untuk menyamarkan asal-usulnya.</li>
        <li><strong>Ransomware:</strong> Pelaku mengenkripsi data korban dan meminta tebusan dalam bentuk Bitcoin atau Monero karena sulit dilacak.</li>
        <li><strong>Pasar Gelap (Dark Web Market):</strong> Transaksi narkoba, senjata, dan data curian di dark web seringkali menggunakan aset kripto sebagai alat pembayaran.</li>
        <li><strong>Phishing dan Peretasan Exchange:</strong> Mencuri kredensial pengguna atau meretas platform pertukaran aset kripto untuk menguras dana nasabah.</li>
      </ul>
      
      <hr class="my-6 border-gray-300" />
      
      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Peran Strategis Polri dalam Pencegahan</h3>
      
      <h4 class="text-xl font-semibold text-secondary mt-4 mb-2">1. Literasi Digital dan Pencegahan</h4>
      <p class="mb-4">Polri secara proaktif melakukan kampanye literasi digital melalui media sosial dan seminar untuk mengedukasi masyarakat tentang risiko investasi kripto ilegal. Ini adalah langkah preventif paling fundamental untuk mengurangi jumlah korban.</p>
      
      <h4 class="text-xl font-semibold text-secondary mt-4 mb-2">2. Pembentukan Tim Khusus Siber</h4>
      <p class="mb-4">Dittipidsiber telah membentuk tim khusus yang memiliki keahlian dalam analisis blockchain dan forensik digital. Tim ini bertugas melacak aliran dana kripto yang mencurigakan, mengidentifikasi dompet digital pelaku, dan menganalisis jejak transaksi di berbagai platform.</p>

      <h4 class="text-xl font-semibold text-secondary mt-4 mb-2">3. Kerja Sama Internasional</h4>
      <p class="mb-4">Kejahatan kripto bersifat lintas batas. Polri menjalin kerja sama erat dengan lembaga penegak hukum internasional seperti Interpol, FBI, dan kepolisian negara lain untuk berbagi informasi, melacak pelaku yang berada di luar negeri, dan melakukan operasi gabungan.</p>
      
      <h4 class="text-xl font-semibold text-secondary mt-4 mb-2">4. Penguatan Aturan dan Regulasi</h4>
      <p class="mb-4">Polri bekerja sama dengan Bappebti (Badan Pengawas Perdagangan Berjangka Komoditi) dan PPATK (Pusat Pelaporan dan Analisis Transaksi Keuangan) untuk memperkuat regulasi. Ini termasuk mewajibkan platform exchange kripto di Indonesia untuk menerapkan prinsip Know Your Customer (KYC) yang ketat guna mencegah akun anonim digunakan untuk kejahatan.</p>

      <hr class="my-6 border-gray-300" />

      <h3 class="text-xl font-semibold text-primary mt-6 mb-3">Tantangan ke Depan</h3>
      <p class="mb-2">Meskipun berbagai upaya telah dilakukan, tantangan tetap ada:</p>
      <ul class="list-disc list-inside space-y-1 text-gray-700 mb-4 pl-4">
          <li><strong>Teknologi yang Terus Berkembang:</strong> Munculnya *privacy coins* (seperti Monero dan Zcash) dan *decentralized mixers* membuat pelacakan menjadi semakin sulit.</li>
          <li><strong>Yurisdiksi Hukum:</strong> Sifat desentralisasi seringkali menyulitkan penentuan yurisdiksi hukum untuk menindak pelaku.</li>
          <li><strong>Keterbatasan Sumber Daya:</strong> Kebutuhan akan ahli forensik digital dan analis blockchain masih sangat tinggi.</li>
      </ul>

      <h3 class="text-xl font-semibold text-primary mt-6 mb-3">Penutup</h3>
      <p class="mb-4">Perang melawan kejahatan berbasis kripto adalah maraton, bukan sprint. Diperlukan sinergi berkelanjutan antara penegak hukum, regulator, sektor swasta (platform exchange), dan masyarakat. Dengan pendekatan yang komprehensif, Polri berada di garda terdepan untuk memastikan bahwa inovasi teknologi tidak disalahgunakan untuk merugikan keamanan dan ketertiban masyarakat.</p>
    `
  }
];