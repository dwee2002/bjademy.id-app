
import React from 'react';

const content = (
  <>
    <p className="mb-4">JakSafe adalah aplikasi pemantauan keamanan real-time yang mencakup seluruh wilayah Jakarta. Dirancang untuk meningkatkan rasa aman warga ibu kota, aplikasi ini menyediakan platform yang mudah diakses, cepat merespons, dan terintegrasi dengan aparat keamanan dalam menangani potensi ancaman, kejadian darurat, maupun laporan masyarakat.</p>
    
    <p className="mb-6">Dengan peta interaktif, notifikasi langsung, dan fitur lapor cepat, JakSafe membantu warga tetap waspada dan terinformasi—di mana pun dan kapan pun. Aplikasi ini dirancang sebagai bagian dari upaya integratif antara masyarakat dan aparat penegak hukum dalam menjaga ketertiban dan keselamatan publik, terutama di wilayah rawan insiden seperti kejahatan jalanan, bencana, demonstrasi, hingga gangguan ketertiban umum.</p>

    <hr className="my-6 border-gray-300" />

    <h3 className="text-2xl font-semibold text-primary mt-6 mb-4">🛡 Fitur Unggulan JakSafe</h3>
    <ul className="list-disc list-inside space-y-3 text-gray-700 mb-6 pl-4">
      <li><strong>Peta Keamanan Jakarta Real-Time:</strong> Visualisasi data insiden keamanan secara langsung di peta untuk pemantauan wilayah.</li>
      <li><strong>Notifikasi Ancaman Lokal:</strong> Peringatan dini otomatis kepada pengguna yang berada di dekat lokasi potensi ancaman atau kejadian darurat.</li>
      <li><strong>Laporan Warga (Foto/Video/Deskripsi):</strong> Fitur pelaporan yang mudah digunakan, memungkinkan warga mengirim bukti visual dan deskripsi kejadian langsung ke pusat komando.</li>
      <li><strong>Statistik & Tren Keamanan Mingguan:</strong> Analisis data untuk melihat tren keamanan, membantu dalam pengambilan keputusan dan perencanaan patroli.</li>
    </ul>
    
    <hr className="my-6 border-gray-300" />
    
    <h3 className="text-xl font-semibold text-primary mt-6 mb-3">Tim Pengembang & Kolaborasi</h3>
    <p className="mb-4">Tim pengembang aplikasi JakSafe terdiri dari gabungan praktisi IT, analis data, dan personel kepolisian aktif, dengan dukungan kolaborasi dari akademisi dan mitra smart city Jakarta.</p>

    <div className="mt-8 text-center">
      <a href="http://Jaksafe.replit.app" target="_blank" rel="noopener noreferrer" className="inline-block bg-primary text-primary-foreground font-bold py-3 px-6 rounded-lg shadow-lg hover:bg-primary/90 transition-colors">
        Kunjungi JakSafe Sekarang
      </a>
    </div>
  </>
);

const jaksafeApp = {
  slug: "jaksafe-monitor-keamanan-jakarta",
  title: "JakSafe: Aplikasi Pemantauan Keamanan Real-Time untuk Jakarta",
  description: "JakSafe adalah aplikasi pemantauan keamanan real-time yang dirancang untuk meningkatkan rasa aman warga Jakarta melalui peta interaktif, notifikasi langsung, dan fitur lapor cepat.",
  image: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/95c977c7ef68dd6a5b6d1875ba1c695d.jpg",
  image_description: "Peta interaktif aplikasi JakSafe yang menunjukkan insiden keamanan di Jakarta.",
  category: "Teknologi Kepolisian",
  author: "da2002",
  date: "2025-07-01",
  content: content,
  keywords: "JakSafe, keamanan Jakarta, aplikasi keamanan, smart city, lapor polisi, bimbel polri"
};

export default jaksafeApp;
