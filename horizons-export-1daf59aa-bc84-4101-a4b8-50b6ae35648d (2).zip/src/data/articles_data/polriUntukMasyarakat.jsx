
const content = `
      <p class="mb-4">Setiap tanggal 1 Juli, Kepolisian Negara Republik Indonesia (Polri) merayakan hari jadinya. Namun lebih dari sekadar seremoni, momen ini menjadi waktu yang tepat untuk merenungkan kembali: untuk siapa Polri bekerja? Jawabannya sederhana namun fundamental — untuk masyarakat.</p>
      
      <h3 class="text-2xl font-semibold text-primary mt-6 mb-3">Bukan Sekadar Penegak Hukum</h3>
      <p class="mb-4">Selama bertahun-tahun, citra polisi sering kali lekat dengan tindakan tegas dan atribut kekuasaan. Namun dalam praktik ideal, Polri adalah pelindung rakyat. Fungsi utamanya bukan hanya menegakkan hukum, tetapi juga mencegah kejahatan, mengedukasi masyarakat, dan menjadi solusi atas masalah keamanan sehari-hari.</p>
      <p class="mb-6">Saat masyarakat merasa aman untuk beraktivitas, bebas dari rasa takut, dan percaya bahwa hukum berlaku adil — di situlah Polri benar-benar hadir untuk mereka.</p>

      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-3">Pendekatan Humanis dan Polmas</h3>
      <p class="mb-4">Di era keterbukaan dan demokratisasi, pendekatan represif tidak lagi efektif. Yang dibutuhkan adalah pendekatan humanis dan partisipatif. Program Polmas (Pemolisian Masyarakat) misalnya, menjadi wujud nyata dari sinergi antara kepolisian dan masyarakat dalam menciptakan keamanan bersama.</p>
      <p class="mb-6">Melalui Bhabinkamtibmas, warga bisa berdiskusi langsung dengan polisi di tingkat desa dan kelurahan. Dari kasus kecil seperti keributan tetangga hingga ancaman radikalisme, semuanya bisa ditangani sejak dini dengan komunikasi yang baik.</p>

      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-3">Tantangan: Kepercayaan dan Profesionalisme</h3>
      <p class="mb-4">Namun tentu, Polri tidak lepas dari tantangan. Masih ada praktik pungli, kekerasan berlebihan, atau diskriminasi hukum oleh segelintir oknum yang merusak citra institusi. Masyarakat tidak hanya butuh polisi yang sigap, tapi juga jujur, adil, dan berintegritas.</p>
      <p class="mb-6">Perbaikan sistem internal, pengawasan publik, dan reformasi budaya organisasi harus terus dijalankan — bukan sebagai reaksi sesaat, tapi sebagai komitmen jangka panjang.</p>

      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-3">Polri Masa Depan: Profesional, Responsif, dan Dekat dengan Rakyat</h3>
      <p class="mb-4">Ke depan, Polri dituntut untuk lebih adaptif terhadap teknologi, responsif terhadap isu sosial, dan terbuka terhadap kritik. Masyarakat bukanlah musuh yang harus dicurigai, tapi mitra strategis dalam menciptakan keamanan kolektif.</p>
      <p class="mb-4">Polri bukan lagi “penguasa jalanan,” tetapi mitra kerja rakyat dalam mewujudkan Indonesia yang damai, tertib, dan adil.</p>
    `;

const polriUntukMasyarakat = {
  slug: "polri-untuk-masyarakat-pelindung-pengayom-pelayan",
  title: "Polri untuk Masyarakat: Menjadi Pelindung, Pengayom, dan Pelayan di Era Modern",
  description: "Sebuah refleksi tentang peran fundamental Polri sebagai pelindung, pengayom, dan pelayan masyarakat di era modern, serta tantangan dalam meraih kepercayaan publik.",
  image: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/af1d7c57bed43dfc0ba1469fcb1c24d3.jpg",
  image_description: "Anggota Brimob di atas kendaraan taktis dalam sebuah parade, berinteraksi dengan masyarakat yang mengibarkan bendera.",
  category: "Etika Kepolisian",
  author: "Catatan Coklat",
  date: "2025-07-01",
  content: content,
  keywords: "polri, masyarakat, pelindung, pengayom, pelayan"
};

export default polriUntukMasyarakat;
