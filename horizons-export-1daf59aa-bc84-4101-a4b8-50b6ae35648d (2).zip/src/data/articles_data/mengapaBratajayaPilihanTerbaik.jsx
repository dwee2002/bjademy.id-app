
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { WhatsAppIcon } from '@/components/icons/WhatsAppIcon';

const content = (
    <div className="space-y-8">
        <p className="text-lg leading-relaxed">
            Setiap tahunnya, ribuan pelajar dari seluruh Indonesia berlomba-lomba untuk meraih kursi di sekolah kedinasan, Akademi Kepolisian (Akpol), Akademi TNI (AD, AL, AU), hingga rekrutmen Bintara Polri dan TNI. Dengan tingkat persaingan yang makin ketat, tidak cukup hanya bermodal semangat. Dibutuhkan strategi, mental kuat, dan bimbingan yang terstruktur. Di sinilah Bratajaya Academy hadir sebagai partner terbaik untuk meraih masa depan yang gemilang.
        </p>

        <div className="space-y-4">
            <h3 className="text-2xl font-bold text-primary">1. Persaingan Ekstrem, Persiapan Harus Premium</h3>
            <p>
                Mereka yang lolos bukan hanya cerdas, tapi disiplin, tangguh, dan terlatih secara mental, fisik, dan akademik. Semua itu difasilitasi secara komprehensif oleh Bratajaya Academy.
            </p>
            <ul className="list-disc list-inside pl-4 space-y-2 text-muted-foreground">
                <li><strong>Sekolah Kedinasan 2024:</strong> 345.426 pendaftar, kuota hanya 6.259 kursi (tingkat kelulusan 1,8%).</li>
                <li><strong>Akpol:</strong> Rata-rata 20.000+ pendaftar untuk hanya 350-an taruna.</li>
                <li><strong>Akademi TNI:</strong> Puluhan ribu pendaftar, kuota sekitar 900 orang (gabungan AD, AL, AU).</li>
                <li><strong>Bintara Polri & TNI:</strong> Ratusan ribu pendaftar berebut ribuan kursi saja.</li>
            </ul>
        </div>

        <div className="space-y-4">
            <h3 className="text-2xl font-bold text-primary">2. Program Unggulan yang Menjawab Tantangan Seleksi</h3>
            <ul className="list-disc list-inside pl-4 space-y-1 text-muted-foreground">
                <li>✅ Akademik (CAT, TWK, TIU, TKP, Matematika, Bahasa Indonesia)</li>
                <li>✅ Psikotes & Tes Kepribadian</li>
                <li>✅ Simulasi Wawancara & Mental Ideologi (MI)</li>
                <li>✅ Pembinaan Fisik Berkala (lari, shuttle run, push-up, dll)</li>
                <li>✅ Pembinaan Mental & Karakter ala Taruna</li>
            </ul>
        </div>

        <div className="space-y-4">
            <h3 className="text-2xl font-bold text-primary">3. Pengajar Profesional dari Alumni Taruna & Praktisi TNI/POLRI</h3>
            <p>Dibimbing langsung oleh:</p>
            <ul className="list-disc list-inside pl-4 space-y-1 text-muted-foreground">
                <li>Alumni Akpol, Akmil, AAU, AAL</li>
                <li>Alumni STAN, STIN, IPDN, dan sekolah kedinasan lainnya</li>
                <li>Praktisi aktif dan purnawirawan TNI/POLRI</li>
                <li>Pelatih fisik dan psikolog berpengalaman</li>
            </ul>
        </div>

        <div className="space-y-4">
            <h3 className="text-2xl font-bold text-primary">4. Bukti Nyata: Lulus dan Mengabdi untuk Negeri</h3>
            <p>Tahun 2024, Bratajaya Academy mencatatkan hasil luar biasa:</p>
            <ul className="list-disc list-inside pl-4 space-y-1 text-muted-foreground">
                <li><strong>56 siswa</strong> lolos sekolah kedinasan</li>
                <li><strong>21 taruna</strong> diterima di Akpol & Akademi TNI</li>
                <li><strong>180+ siswa</strong> lulus seleksi Bintara TNI/POLRI</li>
            </ul>
        </div>

        <div className="space-y-4">
            <h3 className="text-2xl font-bold text-primary">5. Fleksibel: Offline & Online – Bisa Belajar dari Mana Saja</h3>
             <ul className="list-disc list-inside pl-4 space-y-1 text-muted-foreground">
                <li>Kelas tatap muka di kota-kota besar</li>
                <li>Kelas online interaktif dan sistem e-learning</li>
                <li>Tryout nasional, simulasi CAT, dan sesi motivasi</li>
            </ul>
        </div>

        <Card className="bg-primary/5 border-primary/20 mt-8">
            <CardContent className="p-6">
                <h3 className="text-2xl font-bold text-primary mb-4">6. Layanan Fast Response via WhatsApp</h3>
                <p className="mb-4">Untuk Anda yang ingin langsung berkonsultasi atau mendaftar, kami siap membantu dengan layanan respons cepat:</p>
                <a href="https://wa.me/6282211113049?text=Halo%2C%20Brata%20Jaya%21%20Saya%20tertarik%20dan%20ingin%20bertanya%20mengenai%20program%20bimbingan.%20Mohon%20informasinya." target="_blank" rel="noopener noreferrer">
                    <Button className="bg-green-500 hover:bg-green-600 text-white font-bold w-full md:w-auto">
                        <WhatsAppIcon className="mr-2 h-5 w-5" /> Hubungi kami via WhatsApp: 0822-1111-3049
                    </Button>
                </a>
                <p className="mt-4 text-sm text-muted-foreground">Terima kasih telah menghubungi Brata Jaya! Kami akan segera membalas pesan Anda.</p>
                <p className="mt-2">Untuk mempercepat respon, silakan pilih layanan berikut:</p>
                <ul className="list-none space-y-1 mt-2 text-muted-foreground">
                    <li>⿡ Informasi Pendaftaran Siswa Baru</li>
                    <li>⿢ Jadwal Latihan / Kegiatan</li>
                    <li>⿣ Konsultasi & Bimbingan Seleksi TNI/POLRI</li>
                    <li>⿤ Kerja Sama / Kunjungan</li>
                    <li>⿥ Lainnya (Silakan jelaskan lebih lanjut)</li>
                </ul>
                <p className="font-bold mt-4">⏰ Jam Operasional: Senin–Sabtu: 08.00 – 17.00 WIB, Minggu & Hari Libur: TETAP BUKA</p>
            </CardContent>
        </Card>

        <div className="text-center pt-6">
            <h3 className="text-3xl font-bold text-secondary">💥 Ayo Gabung dan Siapkan Masa Depanmu!</h3>
            <p className="text-lg mt-2">Karier sebagai Taruna Akpol, Taruna TNI, maupun Bintara Polri/TNI adalah impian yang bisa diraih dengan persiapan yang tepat. Bratajaya Academy siap menemani setiap langkahmu menuju cita-cita.</p>
            <p className="mt-4 text-sm font-semibold">🙏 Salam sukses, Brata Jaya – "Siap Membina, Siap Membara!"</p>
            <div className="mt-4 text-sm">
                <p>🌐 Website: <a href="http://www.bratajayaacademy.id" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">www.bratajayaacademy.id</a></p>
                <p>📱 Instagram: <a href="https://www.instagram.com/bratajayaacademy" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">@bratajayaacademy</a></p>
                <p>📞 WhatsApp Admin: <a href="https://wa.me/6282211113049" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">0822-1111-3049</a></p>
            </div>
        </div>
    </div>
);


const mengapaBratajayaPilihanTerbaik = {
  slug: 'mengapa-bratajaya-pilihan-terbaik',
  title: 'Mengapa Bratajaya Academy Pilihan Terbaik untuk Rekrutmen Sekolah Kedinasan, Akpol, TNI, dan Bintara?',
  description: 'Dengan persaingan ekstrem, Bratajaya Academy hadir sebagai partner terbaik untuk meraih masa depan gemilang di Sekolah Kedinasan, Akpol, TNI, dan Bintara.',
  date: '2025-07-11',
  author: 'Bratajaya Academy',
  image: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/e738f249952d1ccde991d24bafd056b9.jpg',
  content: content,
  keywords: 'bimbel terbaik, bimbel akpol, bimbel tni, sekolah kedinasan, bratajaya academy, tips lolos tni polri, bimbel jakarta, bimbel tangerang, bimbel depok, bimbel bekasi',
};

export default mengapaBratajayaPilihanTerbaik;
