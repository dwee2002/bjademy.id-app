export const pelayananPolisiArticles = [
  {
    slug: "gunakan-pernyataan-transparansi",
    title: "Gunakan Pernyataan Transparansi: Kunci Membangun Kepercayaan Publik",
    description: "Transparansi dalam setiap pernyataan dan komunikasi Polri adalah fondasi utama untuk membangun dan menjaga kepercayaan masyarakat di era keterbukaan informasi.",
    image: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/cae4e9461cbc748ee783ef001db387c1.jpg",
    category: "Pelayanan Polisi",
    date: "2025-06-14",
    content: `
      <p class="mb-4">Di tengah derasnya arus informasi dan pengawasan publik yang semakin ketat, transparansi bukan lagi pilihan, melainkan sebuah kewajiban bagi institusi publik, termasuk Kepolisian Negara Republik Indonesia (Polri). Setiap pernyataan, rilis media, atau komunikasi yang disampaikan kepada masyarakat harus didasarkan pada prinsip keterbukaan, akurasi, dan kejujuran. Inilah fondasi utama untuk membangun dan merawat kepercayaan publik yang berkelanjutan.</p>
      
      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Mengapa Transparansi Mutlak Diperlukan?</h3>
      <ul class="list-disc list-inside space-y-2 text-gray-700 mb-4 pl-4">
        <li><strong>Mencegah Disinformasi:</strong> Dengan menyediakan informasi yang jelas dan akurat, Polri dapat proaktif melawan hoaks dan narasi liar yang seringkali merugikan citra institusi dan menimbulkan keresahan.</li>
        <li><strong>Meningkatkan Akuntabilitas:</strong> Keterbukaan dalam penanganan kasus atau kebijakan menunjukkan bahwa institusi bertanggung jawab atas setiap tindakannya dan siap untuk dievaluasi oleh publik.</li>
        <li><strong>Membangun Hubungan Kolaboratif:</strong> Masyarakat yang percaya akan lebih partisipatif dan bersedia bekerja sama dengan polisi dalam menjaga keamanan dan ketertiban. Transparansi adalah jembatan menuju kemitraan tersebut.</li>
        <li><strong>Memperkuat Legitimasi:</strong> Institusi kepolisian yang transparan akan dilihat sebagai lembaga yang profesional dan berintegritas, sehingga legitimasinya di mata hukum dan masyarakat semakin kuat.</li>
      </ul>
      
      <hr class="my-6 border-gray-300" />
      
      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Praktik Pernyataan yang Transparan</h3>
      <p class="mb-2">Implementasi transparansi dapat diwujudkan melalui beberapa langkah konkret:</p>
      <ol class="list-decimal list-inside space-y-2 text-gray-700 mb-4 pl-4">
        <li><strong>Konferensi Pers yang Jelas:</strong> Menyampaikan kronologi, data awal, dan langkah-langkah yang akan diambil secara lugas, tanpa menutupi fakta esensial (dengan tetap menjaga kerahasiaan materi penyidikan).</li>
        <li><strong>Pemanfaatan Media Sosial Resmi:</strong> Menggunakan akun resmi sebagai sumber informasi primer untuk memberikan update perkembangan kasus atau klarifikasi isu secara cepat dan tepat.</li>
        <li><strong>Keterbukaan Data (Sesuai Batasan):</strong> Mempublikasikan data-data terkait kriminalitas atau pelayanan publik secara berkala untuk menunjukkan kinerja dan kondisi keamanan secara objektif.</li>
        <li><strong>Responsif terhadap Pertanyaan Publik:</strong> Menunjukkan kesediaan untuk menjawab pertanyaan dari media maupun masyarakat dengan sikap yang terbuka dan tidak defensif.</li>
      </ol>

      <hr class="my-6 border-gray-300" />

      <h3 class="text-xl font-semibold text-primary mt-6 mb-3">Penutup</h3>
      <p class="mb-4">"Gunakan Pernyataan Transparansi" bukan sekadar slogan, melainkan prinsip kerja yang harus diinternalisasi oleh setiap anggota Polri. Kepercayaan publik adalah aset paling berharga bagi kepolisian, dan transparansi adalah cara terbaik untuk meraih dan menjaganya. Dengan berkomunikasi secara terbuka, Polri tidak hanya menjalankan amanat reformasi birokrasi, tetapi juga meneguhkan posisinya sebagai pelindung, pengayom, dan pelayan masyarakat yang modern dan tepercaya.</p>
    `
  },
  {
    slug: "panduan-laporan-polisi",
    title: "Panduan Lengkap Membuat Laporan Polisi (LP)",
    description: "Membuat laporan polisi adalah hak setiap warga negara yang menjadi korban atau saksi tindak pidana. Berikut adalah panduan lengkap mengenai prosedur dan persiapan yang diperlukan.",
    image_description: "Seseorang sedang membuat laporan polisi di meja Sentra Pelayanan Kepolisian Terpadu (SPKT) yang modern dan ramah.",
    category: "Pelayanan Polisi",
    date: "2025-06-13",
    content: `
      <p class="mb-4">Membuat Laporan Polisi (LP) adalah langkah awal yang krusial dalam proses penegakan hukum. Laporan ini menjadi dasar bagi kepolisian untuk melakukan penyelidikan dan penyidikan terhadap suatu tindak pidana. Namun, banyak masyarakat yang masih bingung mengenai prosedur yang benar. Berikut adalah panduan lengkap untuk membantu Anda.</p>
      
      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Di Mana Membuat Laporan?</h3>
      <p class="mb-4">Laporan polisi dibuat di <strong>Sentra Pelayanan Kepolisian Terpadu (SPKT)</strong>. SPKT tersedia di setiap jenjang kantor polisi, mulai dari tingkat Polsek (Kepolisian Sektor), Polres (Kepolisian Resor), Polda (Kepolisian Daerah), hingga Mabes Polri.</p>
      <p class="mb-4"><strong>Saran:</strong> Laporkan kejadian di kantor polisi yang wilayah hukumnya mencakup lokasi kejadian (locus delicti) untuk mempercepat proses penyelidikan.</p>

      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Apa Saja yang Perlu Disiapkan?</h3>
      <p class="mb-2">Untuk memperlancar proses pelaporan, siapkan dokumen dan informasi berikut:</p>
      <ul class="list-disc list-inside space-y-2 text-gray-700 mb-4 pl-4">
        <li><strong>Identitas Diri:</strong> Kartu Tanda Penduduk (KTP) atau identitas lain yang sah (SIM, Paspor).</li>
        <li><strong>Bukti Awal:</strong> Siapkan bukti-bukti yang Anda miliki, meskipun minim. Contoh: foto, video, rekaman suara, tangkapan layar (screenshot) percakapan, atau dokumen terkait.</li>
        <li><strong>Informasi Kejadian:</strong> Ingat-ingat kembali kronologi kejadian secara rinci (apa, siapa, kapan, di mana, mengapa, dan bagaimana).</li>
        <li><strong>Saksi (jika ada):</strong> Jika ada saksi yang melihat kejadian, catat nama dan kontak mereka. Kehadiran saksi dapat memperkuat laporan Anda.</li>
      </ul>

      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Bagaimana Prosedur Pelaporan?</h3>
      <ol class="list-decimal list-inside space-y-2 text-gray-700 mb-4 pl-4">
        <li>Datang ke bagian SPKT dan sampaikan maksud Anda untuk membuat Laporan Polisi.</li>
        <li>Petugas akan mendengarkan penjelasan Anda mengenai kronologi kejadian.</li>
        <li>Anda akan diarahkan ke unit terkait (misalnya, Unit Reserse Kriminal) untuk diwawancarai lebih lanjut dan dibuatkan Berita Acara Pemeriksaan (BAP) awal sebagai pelapor.</li>
        <li>Setelah laporan diterima dan BAP dibuat, Anda akan menerima <strong>Surat Tanda Terima Laporan (STTLP)</strong> sebagai bukti bahwa laporan Anda telah resmi diterima oleh kepolisian.</li>
      </ol>
      
      <hr class="my-6 border-gray-300" />

      <h3 class="text-xl font-semibold text-primary mt-6 mb-3">Penting untuk Diketahui</h3>
      <ul class="list-disc list-inside space-y-2 text-gray-700 mb-4 pl-4">
        <li><strong>Gratis:</strong> Membuat laporan polisi tidak dipungut biaya sama sekali.</li>
        <li><strong>Jangan Takut:</strong> Sebagai pelapor atau saksi, Anda berhak mendapatkan perlindungan hukum.</li>
        <li><strong>Laporan Palsu:</strong> Memberikan laporan palsu dengan sengaja adalah tindak pidana dan dapat dikenai sanksi sesuai Pasal 220 KUHP.</li>
      </ul>

      <h3 class="text-xl font-semibold text-primary mt-6 mb-3">Penutup</h3>
      <p class="mb-4">Dengan memahami prosedur ini, masyarakat diharapkan tidak ragu lagi untuk melapor jika menjadi korban atau saksi kejahatan. Partisipasi aktif Anda sangat membantu kepolisian dalam menjaga keamanan dan ketertiban.</p>
    `
  },
  {
    slug: "inovasi-pelayanan-skck-online",
    title: "Inovasi Pelayanan SKCK Online: Kemudahan dan Transparansi di Era Digital",
    description: "Surat Keterangan Catatan Kepolisian (SKCK) kini semakin mudah diakses melalui platform online, sebuah langkah Polri untuk memangkas birokrasi dan meningkatkan kualitas pelayanan publik.",
    image_description: "Tampilan antarmuka website SKCK Online di layar laptop dengan latar belakang kantor polisi yang modern.",
    category: "Pelayanan Polisi",
    date: "2025-06-07",
    content: `
      <p class="mb-4">Surat Keterangan Catatan Kepolisian (SKCK), yang sebelumnya dikenal sebagai Surat Keterangan Kelakuan Baik (SKKB), adalah salah satu dokumen administratif yang paling sering dibutuhkan oleh masyarakat, baik untuk melamar pekerjaan, melanjutkan pendidikan, maupun keperluan lainnya. Menyadari tingginya kebutuhan ini, Polri telah melakukan terobosan signifikan dengan meluncurkan layanan SKCK online, sebuah inovasi yang bertujuan untuk memangkas birokrasi, meningkatkan efisiensi, dan menjamin transparansi.</p>
      
      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Alur dan Proses SKCK Online</h3>
      <p class="mb-4">Proses pengajuan SKCK secara online dirancang agar mudah diikuti oleh siapa saja:</p>
      <ol class="list-decimal list-inside space-y-2 text-gray-700 mb-4 pl-4">
        <li><strong>Akses Portal Resmi:</strong> Pemohon mengakses situs web resmi SKCK Polri (skck.polri.go.id).</li>
        <li><strong>Registrasi dan Pengisian Data:</strong> Pemohon melakukan registrasi akun dan mengisi formulir yang berisi data pribadi, riwayat keluarga, pendidikan, dan catatan pidana. Semua data diisi secara mandiri.</li>
        <li><strong>Unggah Dokumen:</strong> Pemohon mengunggah pindaian (scan) dokumen persyaratan seperti KTP, Kartu Keluarga, Akta Kelahiran, dan pas foto.</li>
        <li><strong>Pemilihan Loket Pengambilan:</strong> Pemohon memilih kantor polisi (Polsek, Polres, Polda, atau Mabes Polri) sebagai tempat untuk pengambilan fisik SKCK.</li>
        <li><strong>Pembayaran Biaya:</strong> Setelah pendaftaran berhasil, pemohon akan mendapatkan kode bayar untuk melakukan pembayaran PNBP (Penerimaan Negara Bukan Pajak) melalui berbagai kanal pembayaran digital.</li>
        <li><strong>Pengambilan Fisik:</strong> Pemohon datang ke loket yang telah dipilih dengan membawa bukti pendaftaran dan pembayaran untuk proses verifikasi sidik jari dan pengambilan fisik SKCK.</li>
      </ol>
      
      <hr class="my-6 border-gray-300" />
      
      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Keunggulan Layanan SKCK Online</h3>
      <ul class="list-disc list-inside space-y-2 text-gray-700 mb-4 pl-4">
        <li><strong>Efisiensi Waktu:</strong> Memangkas waktu antre yang panjang. Pemohon hanya perlu datang ke kantor polisi untuk tahap akhir (verifikasi dan pengambilan).</li>
        <li><strong>Aksesibilitas:</strong> Dapat diakses kapan saja dan di mana saja selama terhubung dengan internet, memberikan fleksibilitas bagi masyarakat.</li>
        <li><strong>Transparansi Biaya:</strong> Biaya resmi PNBP tertera dengan jelas dan pembayaran dilakukan melalui sistem, menghilangkan potensi pungutan liar.</li>
        <li><strong>Akurasi Data:</strong> Pengisian data secara mandiri oleh pemohon mengurangi risiko kesalahan input (human error) oleh petugas.</li>
        <li><strong>Integrasi Data:</strong> Sistem ini terhubung dengan basis data kriminal nasional, memastikan data yang tercantum dalam SKCK akurat dan terverifikasi.</li>
      </ul>
      
      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Tantangan dan Harapan</h3>
      <p class="mb-4">Meskipun membawa banyak kemudahan, tantangan seperti literasi digital masyarakat di beberapa daerah dan kebutuhan koneksi internet yang stabil masih menjadi perhatian. Harapannya, sosialisasi terus digencarkan dan infrastruktur digital terus ditingkatkan agar layanan ini dapat dinikmati secara merata oleh seluruh masyarakat Indonesia.</p>

      <h3 class="text-xl font-semibold text-primary mt-6 mb-3">Penutup</h3>
      <p class="mb-4">Layanan SKCK online adalah bukti nyata komitmen Polri dalam bertransformasi menuju institusi yang modern, transparan, dan berorientasi pada pelayanan publik. Inovasi ini tidak hanya menyederhanakan proses administratif, tetapi juga membangun kepercayaan masyarakat terhadap institusi kepolisian.</p>
    `
  }
];