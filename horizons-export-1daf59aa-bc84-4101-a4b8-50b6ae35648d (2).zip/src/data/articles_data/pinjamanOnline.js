export const pinjamanOnlineArticles = [
  {
    slug: "teror-pinjol-ilegal",
    title: "Teror Pinjol Ilegal: Dari Ancaman Digital hingga Peran Aktif Polri dalam Pemberantasan",
    description: "Pinjaman online (pinjol) ilegal telah menjadi momok menakutkan bagi masyarakat, menjerat korban dengan bunga tinggi dan metode penagihan yang tidak manusiawi. Polri mengambil peran aktif dalam memberantas praktik ini.",
    image_description: "Seseorang yang stres memegang ponsel dengan notifikasi ancaman dari pinjaman online ilegal.",
    category: "Pinjaman Online",
    date: "2025-06-04",
    content: `
      <p class="mb-4">Kemudahan akses finansial yang ditawarkan teknologi telah melahirkan pedang bermata dua: pinjaman online (pinjol). Di satu sisi, pinjol legal yang terdaftar di Otoritas Jasa Keuangan (OJK) memberikan solusi keuangan yang cepat dan mudah. Namun, di sisi lain, menjamurnya pinjol ilegal telah menciptakan teror digital yang meresahkan masyarakat. Dengan iming-iming pencairan dana instan tanpa syarat rumit, pinjol ilegal menjerat korban dalam lingkaran setan utang dengan bunga mencekik dan metode penagihan yang brutal.</p>
      
      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Ciri-Ciri dan Modus Operandi Pinjol Ilegal</h3>
      <ul class="list-disc list-inside space-y-2 text-gray-700 mb-4 pl-4">
        <li><strong>Tidak Terdaftar di OJK:</strong> Ciri utama dan paling mudah dikenali. Daftar pinjol legal dapat dicek di situs resmi OJK.</li>
        <li><strong>Akses Data Pribadi Berlebihan:</strong> Saat instalasi, aplikasi meminta izin akses ke seluruh data di ponsel, seperti kontak, galeri foto, dan riwayat panggilan, yang kemudian disalahgunakan untuk meneror.</li>
        <li><strong>Bunga dan Denda Tidak Transparan:</strong> Bunga yang sangat tinggi dan denda harian yang tidak masuk akal tanpa ada perjanjian yang jelas di awal.</li>
        <li><strong>Penawaran Melalui SMS/WA:</strong> Seringkali menawarkan pinjaman secara masif melalui pesan singkat tanpa diminta.</li>
        <li><strong>Alamat Kantor Tidak Jelas:</strong> Tidak memiliki identitas dan alamat kantor yang jelas dan terverifikasi.</li>
      </ul>
      
      <hr class="my-6 border-gray-300" />
      
      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Bentuk Teror dan Pelanggaran Hukum</h3>
      <p class="mb-4">Metode penagihan pinjol ilegal seringkali melanggar hukum dan norma sosial, antara lain:</p>
      <ul class="list-disc list-inside space-y-1 text-gray-700 mb-4 pl-4">
          <li><strong>Penyebaran Data Pribadi:</strong> Foto dan informasi pribadi korban disebar ke seluruh kontak di ponselnya dengan narasi palsu (misalnya, "buronan utang," "penipu"). Ini melanggar UU ITE dan UU Perlindungan Data Pribadi.</li>
          <li><strong>Ancaman dan Intimidasi:</strong> Melakukan pengancaman kekerasan fisik, pelecehan seksual verbal, dan teror psikologis lainnya. Ini dapat dijerat dengan pasal-pasal dalam KUHP.</li>
          <li><strong>Pencemaran Nama Baik:</strong> Mencemarkan nama baik korban di lingkungan sosial dan pekerjaannya.</li>
      </ul>
      
      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Peran Aktif Polri dalam Pemberantasan</h3>
      <p class="mb-2">Menanggapi keresahan masyarakat, Polri, melalui Satgas Waspada Investasi (SWI) yang beranggotakan OJK, Kominfo, dan lembaga lain, mengambil langkah-langkah tegas:</p>
      <ol class="list-decimal list-inside space-y-2 text-gray-700 mb-4 pl-4">
        <li><strong>Penindakan Hukum:</strong> Direktorat Tindak Pidana Ekonomi Khusus (Dittipideksus) dan Direktorat Tindak Pidana Siber (Dittipidsiber) Bareskrim Polri secara aktif melakukan penggerebekan dan penangkapan terhadap operator dan pimpinan perusahaan pinjol ilegal.</li>
        <li><strong>Patroli Siber:</strong> Melakukan patroli siber untuk mengidentifikasi aplikasi dan situs web pinjol ilegal untuk kemudian direkomendasikan pemblokirannya ke Kominfo.</li>
        <li><strong>Membuka Hotline Pengaduan:</strong> Menyediakan saluran pengaduan bagi masyarakat yang menjadi korban untuk melapor dengan aman.</li>
        <li><strong>Edukasi Publik:</strong> Bekerja sama dengan OJK, Polri gencar melakukan sosialisasi kepada masyarakat untuk waspada dan hanya menggunakan layanan fintech yang legal.</li>
      </ol>

      <h3 class="text-xl font-semibold text-primary mt-6 mb-3">Apa yang Harus Dilakukan Jika Terjerat?</h3>
      <p class="mb-2">Jika Anda atau kerabat terlanjur terjerat pinjol ilegal:</p>
       <ul class="list-disc list-inside space-y-1 text-gray-700 mb-4 pl-4">
          <li>Segera blokir semua nomor penagih dan hapus aplikasi.</li>
          <li>Beritahu seluruh kontak Anda bahwa data Anda disalahgunakan.</li>
          <li>Kumpulkan semua bukti teror (screenshot, rekaman) dan segera laporkan ke kantor polisi terdekat atau melalui situs patrolisiber.id.</li>
          <li>Jangan pernah membayar lagi, karena pembayaran tidak akan menghentikan teror.</li>
      </ul>

      <h3 class="text-xl font-semibold text-primary mt-6 mb-3">Penutup</h3>
      <p class="mb-4">Pemberantasan pinjol ilegal membutuhkan kerja sama dari semua pihak. Masyarakat harus lebih cerdas dan waspada, sementara regulator dan penegak hukum terus memperkuat pengawasan dan penindakan. Dengan sinergi yang kuat, teror digital ini dapat dihentikan untuk melindungi masyarakat dari kerugian finansial dan psikologis.</p>
    `
  }
];