
import React from 'react';

const rahasiaKuatPullUpLari = {
  slug: 'rahasia-kuat-pull-up-dan-lari',
  title: '💪 Rahasia Kuat Pull-Up dan Lari dari Pelatih Bratajaya Academy',
  description: 'Tips dan rahasia latihan dari pelatih fisik Bratajaya Academy untuk menguasai pull-up dan lari 12 menit dalam seleksi TNI/Polri.',
  image: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/12c3d7fb3a5974a7649d5d02da74c3ad.jpg',
  author: 'Coach Bratajaya',
  date: '2025-07-11',
  category: 'Jasmani',
  keywords: 'Tips pull-up, cara kuat lari, tes kesamaptaan jasmani, latihan fisik TNI Polri, Bratajaya Academy',
  content: `
    <p class="lead text-lg mb-6">Banyak calon taruna dan peserta seleksi TNI/Polri yang menganggap pull-up dan lari sebagai tantangan paling berat dalam tes kesamaptaan jasmani. Tak sedikit yang gugur hanya karena gagal mencapai standar minimal. Tapi jangan khawatir — Pelatih Fisik Bratajaya Academy membocorkan rahasia latihan yang bisa membuat kamu kuat pull-up dan lari dalam waktu singkat!</p>
    
    <h3 class="text-2xl font-bold mt-8 mb-4">🧠 Pahami Dulu: Kenapa Pull-Up & Lari Penting Banget?</h3>
    <p class="mb-4">Dalam seleksi, ini adalah standar minimal yang harus kamu taklukkan:</p>
    <ul class="list-disc list-inside mb-4 pl-4 space-y-2">
      <li><strong>Pull-Up (untuk pria):</strong> Minimal 8x dalam 1 menit (Polri), lebih tinggi untuk TNI.</li>
      <li><strong>Lari 12 Menit:</strong> Minimal 2.400 meter (Polri), TNI targetkan 2.800 – 3.200 meter.</li>
    </ul>
    <p>Keduanya dinilai menggunakan konversi nilai fisik. Jika jeblok, langsung gugur.</p>

    <h3 class="text-2xl font-bold mt-8 mb-4">🏋️ Tips Kuat Pull-Up ala Bratajaya Academy</h3>
    
    <h4 class="text-xl font-semibold mt-6 mb-2">✅ 1. Latihan Negatif Pull-Up (Untuk Pemula)</h4>
    <blockquote class="border-l-4 border-primary pl-4 italic my-4">“Kebanyakan siswa kami awalnya tidak bisa satu kali pun. Kami ajarkan negative pull-up dulu.”<br/> — Koko Alip, Kordinator Coach Bratajaya</blockquote>
    <p><strong>Caranya:</strong></p>
    <ul class="list-disc list-inside mb-4 pl-4 space-y-2">
        <li>Gunakan kursi atau lompat ke posisi pull-up atas.</li>
        <li>Turunkan tubuh secara perlahan (3–5 detik).</li>
        <li>Lakukan 3 set x 5–8 repetisi.</li>
    </ul>

    <h4 class="text-xl font-semibold mt-6 mb-2">✅ 2. Perkuat Otot Penopang: Punggung, Bahu, dan Lengan</h4>
    <p class="mb-2">Latihan pendukung ini penting agar kamu tidak hanya mengandalkan tenaga tangan, tapi otot besar seperti punggung dan bahu juga aktif.</p>
    <ul class="list-disc list-inside mb-4 pl-4 space-y-2">
        <li>Lat Pull-Down</li>
        <li>Barbell Row / Dumbbell Row</li>
        <li>Plank & Hanging Hold</li>
    </ul>

    <h4 class="text-xl font-semibold mt-6 mb-2">✅ 3. Latihan Setiap Hari dengan Pola Terprogram</h4>
    <p class="mb-2">Bratajaya menerapkan program <em>progressive overload</em>:</p>
    <ul class="list-disc list-inside mb-4 pl-4 space-y-2">
        <li><strong>Hari 1–3:</strong> Teknik + Volume (banyak repetisi, ringan)</li>
        <li><strong>Hari 4–6:</strong> Kekuatan (sedikit repetisi, beban)</li>
        <li><strong>Hari 7:</strong> Istirahat aktif</li>
    </ul>

    <h3 class="text-2xl font-bold mt-8 mb-4">🏃 Tips Kuat Lari 12 Menit ala Bratajaya Academy</h3>

    <h4 class="text-xl font-semibold mt-6 mb-2">✅ 1. Gunakan Metode Fartlek dan Tempo Run</h4>
    <blockquote class="border-l-4 border-primary pl-4 italic my-4">“Jangan cuma lari santai tiap hari. Gabungkan variasi intensitas untuk meningkatkan VO2 max.”<br/> — Coach Abdul Ghofur, Instruktur Lari Bratajaya</blockquote>
    <ul class="list-disc list-inside mb-4 pl-4 space-y-2">
        <li><strong>Fartlek:</strong> Lari cepat 1 menit – lari pelan 1 menit – ulangi 6–10 kali.</li>
        <li><strong>Tempo Run:</strong> Lari 15–20 menit dalam kecepatan 80% dari maksimal (ngos-ngosan tapi bisa bicara).</li>
    </ul>
    
    <h4 class="text-xl font-semibold mt-6 mb-2">✅ 2. Latihan Interval di Track atau Lapangan</h4>
    <p class="mb-2">Catat hasil tiap minggu dan bandingkan progresnya.</p>
    <ul class="list-disc list-inside mb-4 pl-4 space-y-2">
        <li>4x400 meter sprint (dengan jeda 1 menit)</li>
        <li>2x800 meter (dengan jeda 2 menit)</li>
        <li>1x1.600 meter time trial</li>
    </ul>
    
    <h4 class="text-xl font-semibold mt-6 mb-2">✅ 3. Perkuat Otot Kaki dan Napas</h4>
    <ul class="list-disc list-inside mb-4 pl-4 space-y-2">
        <li><strong>Hill Sprint:</strong> Lari tanjakan 10–20 detik (untuk power).</li>
        <li>Box Jump / Skipping / Calf Raise.</li>
        <li>Latihan pernapasan diafragma dan latihan tahan napas (apnea).</li>
    </ul>

    <h3 class="text-2xl font-bold mt-8 mb-4">🧂 Bonus: Pola Makan & Recovery</h3>
     <blockquote class="border-l-4 border-primary pl-4 italic my-4">“Latihan keras tapi makannya asal, ya tetap jeblok. Di Bratajaya, kami bimbing juga soal ini.”</blockquote>
    <p><strong>Tips Nutrisi:</strong></p>
    <ul class="list-disc list-inside mb-4 pl-4 space-y-2">
        <li>Protein cukup (telur, tempe, dada ayam).</li>
        <li>Karbo kompleks (nasi merah, kentang).</li>
        <li>Air putih minimal 2 liter/hari.</li>
        <li>Kurangi gorengan, gula, dan minuman manis.</li>
    </ul>
     <p><strong>Tips Istirahat:</strong></p>
    <ul class="list-disc list-inside mb-4 pl-4 space-y-2">
        <li>Tidur cukup 6–8 jam.</li>
        <li>Gunakan es batu untuk kompres setelah latihan keras.</li>
        <li>Jangan latihan berat 1 hari sebelum tes asli.</li>
    </ul>

    <div class="bg-primary/10 border-l-4 border-primary text-primary-foreground p-6 rounded-lg mt-8">
        <h4 class="text-xl font-bold text-primary mb-2">🔥 Sudah Banyak yang Buktikan, Sekarang Giliranmu!</h4>
        <p class="text-primary/90">Banyak alumni Bratajaya yang awalnya tidak bisa pull-up sama sekali dan hanya kuat lari 1.800 meter, kini sudah lolos Akpol, TNI, dan Bintara dengan nilai fisik di atas rata-rata.</p>
        <p class="mt-2 text-primary/90">Kalau kamu serius, latihan di bawah bimbingan pelatih profesional Bratajaya adalah jalan tercepat menuju lulus seleksi.</p>
    </div>
  `,
};

export default rahasiaKuatPullUpLari;
