
import React from 'react';

const content = (
  <div className="space-y-6">
    <p className="mb-6 text-lg leading-relaxed">
      Kepercayaan publik terhadap institusi kepolisian merupakan fondasi penting dalam penegakan hukum dan pemeliharaan ketertiban masyarakat. Sebuah survei baru-baru ini mengungkapkan berbagai harapan masyarakat terhadap perbaikan institusi kepolisian. Hasil survei ini memberikan panduan berharga bagi Polri untuk terus berbenah dan meningkatkan kualitas pelayanannya.
    </p>

    <hr className="my-8 border-gray-300" />

    <h2 className="text-2xl font-semibold text-primary mb-6 text-center">Poin Utama Harapan Masyarakat</h2>

    <div className="grid md:grid-cols-2 gap-8 mb-8">
      <div className="bg-yellow-100 p-6 rounded-lg shadow-md flex flex-col items-center text-center">
        <div className="text-5xl font-bold text-yellow-600 mb-3">68,1%</div>
        <img  alt="Ikon bersih dari pungli dan suap" class="w-20 h-20 mb-3" src="https://images.unsplash.com/photo-1565700226144-62b726591e38" />
        <p className="text-lg font-medium text-gray-700">Lebih bersih dari pungli dan suap menyuap.</p>
        <p className="text-sm text-gray-600 mt-1">Masyarakat mendambakan institusi kepolisian yang berintegritas tinggi dan bebas dari praktik korupsi.</p>
      </div>

      <div className="bg-blue-100 p-6 rounded-lg shadow-md flex flex-col items-center text-center">
        <div className="text-5xl font-bold text-blue-600 mb-3">63,8%</div>
        <img  alt="Ikon adil dan profesional" class="w-20 h-20 mb-3" src="https://images.unsplash.com/photo-1589994965851-a8f479c573a9" />
        <p className="text-lg font-medium text-gray-700">Lebih adil, profesional, dan tidak pandang bulu.</p>
        <p className="text-sm text-gray-600 mt-1">Penegakan hukum yang adil tanpa diskriminasi dan pelayanan yang profesional menjadi harapan besar.</p>
      </div>
      
      <div className="bg-green-100 p-6 rounded-lg shadow-md flex flex-col items-center text-center">
        <div className="text-5xl font-bold text-green-600 mb-3">45,4%</div>
        <img  alt="Ikon humanis dan dekat dengan masyarakat" class="w-20 h-20 mb-3" src="https://images.unsplash.com/photo-1625129740692-8eade16c3a42" />
        <p className="text-lg font-medium text-gray-700">Lebih humanis, dekat dengan masyarakat.</p>
        <p className="text-sm text-gray-600 mt-1">Pendekatan yang lebih humanis dan membangun kedekatan dengan masyarakat diharapkan dapat meningkatkan rasa aman.</p>
      </div>

      <div className="bg-gray-100 p-6 rounded-lg shadow-md flex flex-col items-center text-center">
        <div className="text-5xl font-bold text-gray-600 mb-3">10,1%</div>
        <img  alt="Ikon lainnya" class="w-20 h-20 mb-3" src="https://images.unsplash.com/photo-1662057219054-ac91f1c562b5" />
        <p className="text-lg font-medium text-gray-700">Lainnya.</p>
        <p className="text-sm text-gray-600 mt-1">Berbagai harapan lain juga disampaikan, menunjukkan keinginan masyarakat akan perbaikan yang komprehensif.</p>
      </div>
    </div>

    <hr className="my-8 border-gray-300" />

    <h3 className="text-xl font-semibold text-primary mt-6 mb-3">Implikasi untuk Institusi Kepolisian</h3>
    <p className="mb-4 text-gray-700">Hasil survei ini menggarisbawahi area-area krusial yang perlu menjadi fokus perbaikan bagi institusi kepolisian. Peningkatan integritas, profesionalisme, keadilan dalam penegakan hukum, serta pendekatan yang lebih humanis adalah kunci untuk membangun kembali dan memperkuat kepercayaan publik.</p>
    <p className="text-gray-700">Langkah-langkah konkret seperti reformasi internal, penguatan pengawasan, peningkatan kualitas SDM, dan dialog yang lebih intensif dengan masyarakat perlu terus didorong untuk mewujudkan harapan-harapan tersebut.</p>
  </div>
);

const harapanMasyarakatPolri = {
  slug: "harapan-masyarakat-terhadap-perbaikan-institusi-kepolisian",
  title: "Harapan Masyarakat Terhadap Perbaikan Institusi Kepolisian",
  description: "Survei menunjukkan berbagai harapan masyarakat untuk perbaikan institusi kepolisian di Indonesia, menekankan aspek keadilan, profesionalisme, dan integritas.",
  image: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/6591210c8ab80fb3469a8138b3972f96.jpg",
  image_description: "Alumni Bratajaya Academy yang telah sukses menjadi anggota Polri, menjadi bukti nyata dedikasi dalam membina calon abdi negara.",
  category: "Etika Kepolisian",
  author: "Survei Opini Publik",
  date: "2025-06-13",
  content: content,
  keywords: "harapan masyarakat polri, survei polisi, perbaikan polri, polisi profesional, polisi humanis, bimbel polri jakarta"
};

export default harapanMasyarakatPolri;
