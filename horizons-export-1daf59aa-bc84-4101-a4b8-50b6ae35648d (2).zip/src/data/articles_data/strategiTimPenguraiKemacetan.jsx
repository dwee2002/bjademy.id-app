
const strategiTimPenguraiKemacetan = {
    slug: "strategi-tim-pengurai-kemacetan-polda-metro-jaya",
    title: "Strategi Tim Pengurai Kemacetan Polda Metro Jaya",
    description: "Penjelasan mengenai strategi penempatan personel, klasifikasi lokasi rawan macet, standar personel, dan skenario penempatan strategis oleh Tim Pengurai Kemacetan Polda Metro Jaya.",
    image: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/4192342d7f1ac92d5da0c6f64975fb5e.jpg",
    image_description: "Infografis Strategi Tim Pengurai Kemacetan Polda Metro Jaya",
    category: "Lalu Lintas",
    author: "Polda Metro Jaya",
    date: "2025-06-13",
    content: `
      <p class="mb-4">Kemacetan lalu lintas merupakan salah satu tantangan utama di kota-kota besar seperti Jakarta. Polda Metro Jaya telah menyusun strategi komprehensif untuk tim pengurai kemacetan, yang melibatkan penempatan personel yang efektif dan pemanfaatan teknologi. Infografis ini merinci berbagai aspek dari strategi tersebut.</p>
      
      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Klasifikasi Lokasi Rawan Macet</h3>
      <p class="mb-2 text-gray-700">Lokasi rawan macet diklasifikasikan berdasarkan tingkat keparahannya:</p>
      <ul class="list-disc list-inside space-y-1 text-gray-700 mb-6 pl-4">
        <li><strong class="text-red-600">Merah:</strong> Kritis / Simpul Kota</li>
        <li><strong class="text-yellow-500">Sedang:</strong> Tingkat kemacetan sedang</li>
        <li><strong class="text-green-600">Hijau:</strong> Rendah tapi konsisten</li>
      </ul>

      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Standar Minimal Personel per Titik</h3>
      <p class="mb-2 text-gray-700">Jumlah minimal personel yang ditempatkan per titik disesuaikan dengan klasifikasi lokasi:</p>
      <ul class="list-none space-y-2 text-gray-700 mb-6 pl-4">
        <li class="flex items-center"><span class="inline-block w-4 h-4 bg-red-500 rounded-full mr-2"></span> 4 Personel</li>
        <li class="flex items-center"><span class="inline-block w-4 h-4 bg-yellow-500 rounded-full mr-2"></span> 3 Personel</li>
        <li class="flex items-center"><span class="inline-block w-4 h-4 bg-green-500 rounded-full mr-2"></span> 2 Personel</li>
      </ul>

      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Komposisi Petugas Shift Pagi & Sore</h3>
      <table class="w-full mb-6 border-collapse">
        <thead>
          <tr class="bg-primary/10">
            <th class="border p-2 text-left text-primary">Total</th>
            <th class="border p-2 text-left text-primary">Personel</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td class="border p-2 text-gray-700">Zona Merah</td>
            <td class="border p-2 text-gray-700">20</td>
          </tr>
          <tr>
            <td class="border p-2 text-gray-700">Zona Kuning</td>
            <td class="border p-2 text-gray-700">27</td>
          </tr>
          <tr>
            <td class="border p-2 text-gray-700">Zona Hijau</td>
            <td class="border p-2 text-gray-700">15</td>
          </tr>
          <tr class="font-semibold bg-gray-100">
            <td class="border p-2 text-gray-800">TOTAL</td>
            <td class="border p-2 text-gray-800">211</td>
          </tr>
        </tbody>
      </table>

      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Skenario Penempatan Strategis (Shift)</h3>
       <p class="mb-2 text-gray-700">Total 21 shift dengan rincian personel per zona:</p>
      <table class="w-full mb-6 border-collapse">
        <thead>
          <tr class="bg-primary/10">
            <th class="border p-2 text-left text-primary">Zona</th>
            <th class="border p-2 text-left text-primary">Personel</th>
            <th class="border p-2 text-left text-primary">Shift</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td class="border p-2 text-gray-700">Zona (Merah)</td>
            <td class="border p-2 text-gray-700">25</td>
            <td class="border p-2 text-gray-700">20</td>
          </tr>
          <tr>
            <td class="border p-2 text-gray-700">Kuning</td>
            <td class="border p-2 text-gray-700">27</td>
            <td class="border p-2 text-gray-700">28</td>
          </tr>
          <tr>
            <td class="border p-2 text-gray-700">Hijau</td>
            <td class="border p-2 text-gray-700">15</td>
            <td class="border p-2 text-gray-700">211 (Total Personel)</td>
          </tr>
        </tbody>
      </table>
      
      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Skenario Penempatan Strategis (Wilayah)</h3>
      <ul class="list-disc list-inside space-y-1 text-gray-700 mb-6 pl-4">
        <li><strong>Jakarta Pusat:</strong> TL Senen, TL Carolus, Pintu Besar Selatan</li>
        <li><strong>Jakarta Kuning:</strong> (Detail tidak terbaca jelas dari gambar)</li>
      </ul>
      
      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Pemanfaatan Teknologi & Sistem Pendukung</h3>
      <ul class="list-disc list-inside space-y-2 text-gray-700 mb-6 pl-4">
        <li><strong>Absensi Digital:</strong> Menggunakan Android HT dengan absensi GPS.</li>
        <li><strong>Monitoring Real-time:</strong> Supervisi melalui Command Center.</li>
        <li><strong>Sistem Rotasi:</strong> Setiap petasi 3-4 jam.</li>
        <li><strong>Backup Unit:</strong> Kesiapan unit Kencam Sabhara / Brimob.</li>
      </ul>

      <hr class="my-6 border-gray-300" />
      
      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Saran Pelaksanaan</h3>
      <ul class="list-disc list-inside space-y-1 text-gray-700 mb-6 pl-4">
        <li>Absensi digital (Android HT).</li>
        <li>Sabhara / Binmas.</li>
      </ul>

      <hr class="my-6 border-gray-300" />

      <h3 class="text-xl font-semibold text-primary mt-6 mb-3">Penutup</h3>
      <p class="mb-4">Dengan strategi yang terencana dan didukung oleh teknologi, diharapkan tim pengurai kemacetan dapat bekerja lebih efektif dalam menjaga kelancaran lalu lintas di wilayah Polda Metro Jaya. Koordinasi dan disiplin personel menjadi kunci keberhasilan implementasi strategi ini.</p>
    `
  };

export default strategiTimPenguraiKemacetan;
