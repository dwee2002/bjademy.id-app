export const faktorPenyebabKriminalitasArticles = [
  {
    slug: "faktor-penyebab-tingkat-kriminalitas-tinggi",
    title: "Faktor Penyebab Tingkat Kriminalitas Tinggi",
    description: "Analisis mendalam mengenai berbagai faktor yang berkontribusi terhadap tingginya tingkat kriminalitas, termasuk aspek sosial, ekonomi, dan lingkungan.",
    image: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/0a0789ee1a5a7230d8179a7f122ba703.jpg",
    image_description: "Infografis faktor-faktor penyebab tingginya tingkat kriminalitas.",
    category: "Ketertiban Umum",
    author: "Analisis Kriminologi",
    date: "2025-06-13",
    content: `
      <p class="mb-6 text-lg">Tingginya angka kriminalitas di suatu wilayah dipengaruhi oleh berbagai faktor kompleks yang saling terkait. Memahami akar permasalahan ini penting untuk merumuskan strategi pencegahan yang efektif. Berikut adalah beberapa faktor utama yang sering diidentifikasi sebagai penyebab meningkatnya kriminalitas:</p>
      
      <hr class="my-8 border-gray-300" />

      <div class="grid md:grid-cols-2 gap-x-8 gap-y-6 mb-8">
        <div>
          <h3 class="text-2xl font-semibold text-primary mb-3">1. Kemiskinan</h3>
          <div class="flex items-start">
            <img  alt="Ilustrasi kemiskinan" class="w-24 h-auto mr-4 rounded-md shadow-sm" src="https://images.unsplash.com/photo-1571332969182-af9ceb8b1da0" />
            <p class="text-gray-700">Keterbatasan ekonomi dapat mendorong individu untuk melakukan tindak kriminal sebagai upaya memenuhi kebutuhan dasar hidup yang tidak terpenuhi.</p>
          </div>
        </div>
        <div>
          <h3 class="text-2xl font-semibold text-primary mb-3">2. Ketidaksetaraan Sosial dan Ekonomi</h3>
          <div class="flex items-start">
            <img  alt="Ilustrasi ketidaksetaraan sosial" class="w-24 h-auto mr-4 rounded-md shadow-sm" src="https://images.unsplash.com/photo-1586755596549-c105e88e20f5" />
            <p class="text-gray-700">Kesenjangan yang lebar antara kelompok kaya dan miskin dapat menimbulkan rasa frustrasi, iri hati, dan ketidakadilan yang berpotensi memicu perilaku kriminal.</p>
          </div>
        </div>
        <div>
          <h3 class="text-2xl font-semibold text-primary mb-3">3. Pengangguran</h3>
          <div class="flex items-start">
            <img  alt="Ilustrasi pengangguran" class="w-24 h-auto mr-4 rounded-md shadow-sm" src="https://images.unsplash.com/photo-1583780678824-a29cb7e32d2e" />
            <p class="text-gray-700">Tidak adanya pekerjaan dan sumber penghasilan yang stabil dapat meningkatkan risiko seseorang terlibat dalam aktivitas kriminal untuk bertahan hidup atau mengisi waktu luang dengan cara negatif.</p>
          </div>
        </div>
        <div>
          <h3 class="text-2xl font-semibold text-primary mb-3">4. Penyalahgunaan Narkoba dan Alkohol</h3>
          <div class="flex items-start">
            <img  alt="Ilustrasi penyalahgunaan narkoba" class="w-24 h-auto mr-4 rounded-md shadow-sm" src="https://images.unsplash.com/photo-1541256637751-3f632b8525ff" />
            <p class="text-gray-700">Kecanduan zat adiktif seringkali memaksa individu untuk melakukan kejahatan demi membiayai ketergantungan mereka, serta dapat menurunkan kesadaran dan kontrol diri.</p>
          </div>
        </div>
        <div>
          <h3 class="text-2xl font-semibold text-primary mb-3">5. Masalah Keluarga dan Lingkungan</h3>
          <div class="flex items-start">
            <img  alt="Ilustrasi masalah keluarga" class="w-24 h-auto mr-4 rounded-md shadow-sm" src="https://images.unsplash.com/photo-1532377416656-e35d0e574765" />
            <p class="text-gray-700">Lingkungan keluarga yang tidak harmonis, kurangnya kasih sayang, pengawasan orang tua yang lemah, serta pengaruh negatif dari lingkungan pergaulan dapat membentuk pola perilaku menyimpang.</p>
          </div>
        </div>
        <div>
          <h3 class="text-2xl font-semibold text-primary mb-3">6. Kurangnya Pendidikan</h3>
          <div class="flex items-start">
            <img  alt="Ilustrasi kurangnya pendidikan" class="w-24 h-auto mr-4 rounded-md shadow-sm" src="https://images.unsplash.com/photo-1525506104102-574ac86f8834" />
            <p class="text-gray-700">Tingkat pendidikan yang rendah seringkali berkorelasi dengan terbatasnya peluang kerja formal, yang pada gilirannya dapat meningkatkan kerentanan terhadap tindak kriminal.</p>
          </div>
        </div>
        <div>
          <h3 class="text-2xl font-semibold text-primary mb-3">7. Konflik Sosial</h3>
          <div class="flex items-start">
            <img  alt="Ilustrasi konflik sosial" class="w-24 h-auto mr-4 rounded-md shadow-sm" src="https://images.unsplash.com/photo-1602242108693-b5e725cc811d" />
            <p class="text-gray-700">Ketegangan antar kelompok dalam masyarakat, diskriminasi, atau perebutan sumber daya dapat memicu konflik yang berujung pada tindakan kriminal.</p>
          </div>
        </div>
      </div>

      <hr class="my-8 border-gray-300" />

      <div class="bg-primary/5 p-6 rounded-lg shadow-md">
        <blockquote class="text-lg italic text-gray-800 border-l-4 border-primary pl-4">
          <p>"Kriminalitas itu terjadi pada angka pengangguran yang tingkat pendidikannya rendah. Apalagi pengangguran itu adalah anak-anak muda, itu kaitannya dengan kriminalitas. Jelas itu."</p>
          <footer class="mt-2 text-sm text-gray-600">- Tadjudin Nur Effendi, Pengamat Ketenagakerjaan Universitas Gadjah Mada (UGM)</footer>
        </blockquote>
      </div>

      <hr class="my-8 border-gray-300" />

      <h3 class="text-xl font-semibold text-primary mt-6 mb-3">Kesimpulan</h3>
      <p class="mb-4 text-gray-700">Penanganan kriminalitas memerlukan pendekatan multidimensional yang tidak hanya fokus pada penegakan hukum, tetapi juga pada perbaikan kondisi sosial ekonomi, penguatan institusi keluarga dan pendidikan, serta resolusi konflik sosial. Upaya pencegahan yang komprehensif dan berkelanjutan adalah kunci untuk menciptakan masyarakat yang lebih aman dan tertib.</p>
    `
  }
];