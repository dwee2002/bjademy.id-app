
import React from 'react';

const content = (
  <>
    <p className="mb-4">Praktik mafia tanah menjadi salah satu kejahatan yang meresahkan masyarakat dan dapat menimbulkan kerugian besar. Pemalsuan dokumen seringkali menjadi pintu masuk untuk jual beli tanah secara ilegal. Penting bagi masyarakat untuk mengenali modus operandi yang biasa digunakan oleh para pelaku.</p>
    
    <hr className="my-6 border-gray-300" />

    <h3 className="text-2xl font-semibold text-primary mt-6 mb-4">Modus Operandi Umum Mafia Tanah</h3>
    <p className="mb-4">Berdasarkan berbagai kasus yang telah terungkap, beberapa modus operandi yang sering digunakan oleh mafia tanah antara lain:</p>
    <ul className="list-disc list-inside space-y-2 text-gray-700 mb-6 pl-4">
      <li>
        <strong>Pemalsuan Identitas:</strong> Pelaku menggunakan Kartu Tanda Penduduk (KTP) palsu atau memalsukan identitas pemilik tanah yang sah untuk mengelabui pihak terkait.
      </li>
      <li>
        <strong>Pemalsuan Dokumen Tanah:</strong> Sertipikat tanah, Akta Jual Beli (AJB), Girik, atau dokumen kepemilikan lainnya dipalsukan sedemikian rupa sehingga tampak asli.
      </li>
      <li>
        <strong>Akta Jual Beli Palsu:</strong> Membuat akta jual beli fiktif seolah-olah telah terjadi transaksi yang sah antara pemilik asli dengan pihak yang dikuasai oleh mafia tanah.
      </li>
      <li>
        <strong>Rekayasa Peralihan Hak:</strong> Melakukan manipulasi dalam proses peralihan hak atas tanah, misalnya dengan memanfaatkan celah hukum, berkolusi dengan oknum tertentu, atau mengajukan gugatan hukum dengan dasar bukti palsu.
      </li>
      <li>
        <strong>Pendudukan Ilegal:</strong> Menduduki tanah sengketa atau tanah kosong secara ilegal dan kemudian berusaha melegalkannya melalui berbagai cara.
      </li>
      <li>
        <strong>Memanfaatkan Konflik Keluarga:</strong> Mengambil keuntungan dari sengketa waris atau konflik internal keluarga pemilik tanah untuk menguasai aset tanah.
      </li>
    </ul>
    
    <hr className="my-6 border-gray-300" />
    
    <h3 className="text-2xl font-semibold text-primary mt-6 mb-4">Langkah Pencegahan dan Perlindungan</h3>
    <p className="mb-4">Masyarakat diimbau untuk selalu waspada dan melakukan langkah-langkah pencegahan, seperti:</p>
    <ul className="list-disc list-inside space-y-2 text-gray-700 mb-6 pl-4">
      <li>Selalu periksa keaslian dokumen kepemilikan tanah ke instansi yang berwenang (Badan Pertanahan Nasional/BPN).</li>
      <li>Gunakan jasa Pejabat Pembuat Akta Tanah (PPAT) yang terpercaya dan memiliki reputasi baik dalam setiap transaksi tanah.</li>
      <li>Jangan mudah percaya dengan tawaran harga tanah yang terlalu murah atau proses yang terlalu mudah.</li>
      <li>Segera daftarkan tanah Anda dan pastikan sertipikat atas nama Anda sendiri.</li>
      <li>Jika menemukan indikasi praktik mafia tanah, segera laporkan kepada pihak berwajib atau Satgas Anti Mafia Tanah.</li>
    </ul>

    <hr className="my-6 border-gray-300" />

    <h3 className="text-xl font-semibold text-primary mt-6 mb-3">Penutup</h3>
    <p className="mb-4">Dengan kewaspadaan dan pemahaman yang baik mengenai modus operandi mafia tanah, diharapkan masyarakat dapat lebih proaktif dalam melindungi hak atas tanahnya dan terhindar dari praktik kejahatan ini. Peran serta aktif masyarakat dalam melaporkan dugaan praktik mafia tanah juga sangat penting untuk pemberantasan kejahatan ini.</p>
  </>
);

const mafiaTanah = {
  slug: "waspada-mafia-tanah-kenali-modus-operandi",
  title: "Waspada Mafia Tanah: Kenali Modus Operandinya",
  description: "Mafia tanah merupakan ancaman serius yang dapat merugikan masyarakat. Kenali modus operandi mereka untuk melindungi aset berharga Anda.",
  image: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/c817cd0ba2b52d8b992db85db7f9c245.jpg",
  image_description: "Infografis mengenai modus operandi mafia tanah, termasuk pemalsuan dokumen dan rekayasa peralihan hak.",
  category: "Hukum Pidana",
  author: "Satgas Anti Mafia Tanah",
  date: "2025-06-13",
  content: content,
  keywords: "mafia tanah, sengketa tanah, hukum pertanahan, modus mafia tanah, bimbel polri"
};

export default mafiaTanah;
