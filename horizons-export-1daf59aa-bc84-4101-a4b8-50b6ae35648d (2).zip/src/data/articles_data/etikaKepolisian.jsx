import React from 'react';

const content = (
  <>
      <p className="mb-4 text-lg leading-relaxed">Di era digital, media sosial bukan lagi sekadar ruang pribadi, tetapi etalase yang mencerminkan nilai dan profesionalisme individu, termasuk bagi anggota Kepolisian Negara Republik Indonesia (Polri). Setiap unggahan, komentar, atau interaksi dapat dengan cepat menjadi sorotan publik dan memengaruhi citra institusi secara keseluruhan. Oleh karena itu, pemahaman mendalam mengenai etika dan panduan penggunaan media sosial menjadi suatu keharusan.</p>
      
      <hr className="my-6 border-gray-300" />

      <h3 className="text-2xl font-semibold text-primary mt-6 mb-4">Mengapa Etika Bermedia Sosial Penting bagi Anggota Polri?</h3>
      <ul className="list-disc list-inside space-y-2 text-muted-foreground mb-4 pl-4">
        <li><strong>Menjaga Wibawa Institusi:</strong> Perilaku anggota di dunia maya adalah cerminan langsung dari citra Polri di mata masyarakat.</li>
        <li><strong>Mencegah Konflik Kepentingan:</strong> Menghindari unggahan yang dapat ditafsirkan sebagai keberpihakan, terutama dalam isu politik, SARA, atau kasus yang sedang ditangani.</li>
        <li><strong>Melindungi Informasi Rahasia:</strong> Mencegah kebocoran informasi operasional, data internal, atau hal-hal yang bersifat rahasia jabatan.</li>
        <li><strong>Membangun Kepercayaan Publik:</strong> Menggunakan media sosial sebagai sarana positif untuk edukasi, sosialisasi, dan membangun hubungan baik dengan masyarakat.</li>
      </ul>
      
      <hr className="my-6 border-gray-300" />
      
      <h3 className="text-2xl font-semibold text-primary mt-6 mb-4">Panduan Praktis Bermedia Sosial (Do's and Don'ts)</h3>
      
      <h4 className="text-xl font-semibold text-green-600 mt-4 mb-2">Yang Harus Dilakukan (Do's):</h4>
      <ul className="list-disc list-inside space-y-1 text-muted-foreground mb-4 pl-4">
        <li>Berpikir sebelum mengunggah (Think before posting).</li>
        <li>Menyebarkan konten yang bersifat informatif, edukatif, dan positif.</li>
        <li>Menunjukkan sikap humanis dan empati dalam berinteraksi.</li>
        <li>Menggunakan bahasa yang santun, sopan, dan mudah dipahami.</li>
        <li>Segera meluruskan informasi yang keliru (klarifikasi) jika diperlukan, melalui jalur resmi.</li>
      </ul>
      
      <h4 className="text-xl font-semibold text-destructive mt-4 mb-2">Yang Harus Dihindari (Don'ts):</h4>
      <ul className="list-disc list-inside space-y-1 text-muted-foreground mb-4 pl-4">
        <li>Mengunggah foto atau video yang menampilkan gaya hidup mewah (hedonisme).</li>
        <li>Memberikan komentar negatif, provokatif, atau ujaran kebencian.</li>
        <li>Membocorkan informasi terkait pelaksanaan tugas, operasi, atau identitas rekan kerja.</li>
        <li>Mengeluh tentang pekerjaan, pimpinan, atau institusi di ruang publik.</li>
        <li>Terlibat dalam perdebatan politik praktis atau menunjukkan keberpihakan pada salah satu calon/partai.</li>
      </ul>

      <hr className="my-6 border-gray-300" />

      <h3 className="text-xl font-semibold text-primary mt-6 mb-3">Aspek Hukum yang Perlu Diperhatikan</h3>
      <p className="mb-4 text-muted-foreground">Selain Peraturan Kapolri (Perkap) tentang etika, anggota Polri juga terikat pada UU ITE. Pelanggaran seperti pencemaran nama baik, penyebaran berita bohong (hoax), atau ujaran kebencian dapat berujung pada sanksi disiplin, kode etik, bahkan pidana.</p>

      <h3 className="text-xl font-semibold text-primary mt-6 mb-3">Penutup</h3>
      <p className="mb-4 text-muted-foreground">Jejak digital abadi. Kebijaksanaan dalam menggunakan media sosial adalah bentuk tanggung jawab setiap anggota Polri untuk menjaga kehormatan diri, keluarga, dan institusi. Jadikan media sosial sebagai alat untuk mendekatkan Polri dengan masyarakat, bukan sebaliknya.</p>
  </>
);

const etikaKepolisian = {
    slug: "etika-media-sosial-polri",
    title: "Etika dan Panduan Penggunaan Media Sosial bagi Anggota Polri",
    description: "Di era digital, media sosial menjadi cerminan institusi. Anggota Polri harus bijak dalam berekspresi untuk menjaga citra, kepercayaan publik, dan marwah institusi.",
    image: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/71d5eb8c76742a8b94f1c107144e59f4.jpg",
    image_description: "Seorang polisi berseragam menggunakan smartphone dengan ikon media sosial di sekelilingnya, merepresentasikan etika digital.",
    category: "Etika Kepolisian",
    author: "Divisi Propam Polri",
    date: "2025-06-12",
    content: content,
    keywords: "etika polri, media sosial polisi, uu ite, citra polri, profesionalisme polisi, panduan medsos, hedonisme"
};

export default etikaKepolisian;