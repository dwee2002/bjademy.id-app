export const tawuranRemajaJakartaArticles = [
  {
    slug: "optimalisasi-penanganan-rawan-tawuran-jakarta",
    title: "Optimalisasi Penanganan Titik Rawan Tawuran Remaja di Jakarta",
    category: "Ketertiban Umum",
    date: "2025-02-01",
    author: "Tim Kamtibmas Jakarta",
    image: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/0ac7c25961409dfd2feb6b067f756a74.jpg",
    image_description: "Polisi berdiskusi dengan remaja sambil minum kopi, membahas keamanan dan ketertiban melalui program Ngopi Kamtibmas.",
    description: "Program 'Ngopi Kamtibmas' sebagai upaya optimalisasi penanganan titik rawan tawuran remaja di Jakarta dengan fokus pada wilayah Johar Baru, Tambora, dan Cengkareng.",
    content: `
      <p class="mb-4">Program inovatif 'Ngopi Kamtibmas' diluncurkan sebagai strategi proaktif untuk mengoptimalkan penanganan titik rawan tawuran remaja di wilayah DKI Jakarta. Inisiatif ini dijadwalkan untuk Februari 2025 dan bertujuan untuk membangun dialog serta kedekatan antara aparat kepolisian dan generasi muda.</p>
      <h2 class="text-2xl font-semibold text-primary mb-3 mt-6">Fokus Wilayah Prioritas</h2>
      <p class="mb-4">Program ini akan difokuskan pada tiga wilayah yang teridentifikasi memiliki kerawanan tinggi terhadap tawuran remaja:</p>
      <ul class="list-disc list-inside mb-4 pl-4">
        <li class="mb-1">Wilayah Johar Baru</li>
        <li class="mb-1">Tambora</li>
        <li class="mb-1">Cengkareng</li>
      </ul>
      <p class="mb-4">Pemilihan wilayah ini didasarkan pada data dan analisis kejadian tawuran sebelumnya, serta masukan dari masyarakat setempat.</p>
      <h2 class="text-2xl font-semibold text-primary mb-3 mt-6">Pendekatan Komprehensif</h2>
      <p class="mb-4">Optimalisasi penanganan akan dilakukan melalui pendekatan multi-aspek yang melibatkan berbagai elemen:</p>
      <ul class="list-disc list-inside mb-4 pl-4">
        <li class="mb-1"><strong>Sosial-intelijen:</strong> Pengumpulan informasi dan pemahaman mendalam mengenai akar masalah, pemicu, serta jaringan yang terlibat dalam tawuran remaja. Ini melibatkan pendekatan humanis untuk mendapatkan kepercayaan dari komunitas.</li>
        <li class="mb-1"><strong>Pemetaan Spasial:</strong> Identifikasi dan analisis lokasi-lokasi (hotspots) yang sering menjadi tempat berkumpul atau terjadinya tawuran. Data spasial ini akan digunakan untuk perencanaan patroli dan intervensi yang lebih efektif.</li>
        <li class="mb-1"><strong>Kolaborasi Lintas Sektor:</strong> Melibatkan berbagai pihak terkait seperti pemerintah daerah, tokoh masyarakat, tokoh agama, sekolah, orang tua, dan organisasi kepemudaan untuk menciptakan solusi bersama yang berkelanjutan. Sinergi ini diharapkan dapat membangun lingkungan yang kondusif dan mengurangi potensi konflik.</li>
      </ul>
      <p class="mb-4">Melalui 'Ngopi Kamtibmas' dan pendekatan terstruktur ini, diharapkan dapat tercipta penurunan signifikan angka tawuran remaja, serta meningkatnya kesadaran akan pentingnya keamanan dan ketertiban di lingkungan masyarakat.</p>
    `
  }
];