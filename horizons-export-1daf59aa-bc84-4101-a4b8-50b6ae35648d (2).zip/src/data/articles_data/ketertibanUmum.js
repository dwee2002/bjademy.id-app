export const ketertibanUmumArticles = [
  {
    slug: "premanisme-jakarta",
    title: "Premanisme di Jakarta: Duri dalam Daging Ketertiban Ibu Kota",
    description: "Jakarta sebagai ibu kota negara bukan hanya pusat pemerintahan dan ekonomi, tetapi juga barometer keamanan nasional. Namun, di balik derap pembangunan dan gemerlap modernitas, kota ini masih bergelut dengan fenomena lama bernama premanisme.",
    image_description: "Siluet beberapa orang berpenampilan preman di sebuah gang kumuh di perkotaan Jakarta pada malam hari.",
    category: "Ketertiban Umum",
    date: "2025-06-05",
    content: `
      <h3 class="text-xl font-semibold text-primary mt-6 mb-3">🛑 Pengantar</h3>
      <p class="mb-4">Jakarta sebagai ibu kota negara bukan hanya pusat pemerintahan dan ekonomi, tetapi juga barometer keamanan nasional. Namun, di balik derap pembangunan dan gemerlap modernitas, kota ini masih bergelut dengan fenomena lama bernama premanisme.</p>
      <p class="mb-4">Premanisme bak duri dalam daging—meresahkan, tersembunyi, tetapi berdampak sistemik. Ia hidup di sela-sela pasar tradisional, kawasan parkir liar, hingga proyek-proyek pembangunan strategis. Meski sering disebut penyakit sosial, premanisme sebenarnya adalah bentuk kejahatan terorganisir yang memanfaatkan kekosongan pengawasan dan lemahnya penegakan hukum di tingkat akar rumput.</p>
      
      <hr class="my-6 border-gray-300" />

      <h3 class="text-xl font-semibold text-primary mt-6 mb-3">📉 Fakta Lapangan</h3>
      <p class="mb-2">Menurut data Pusat Informasi Kriminal Nasional (Pusiknas) Polri:</p>
      <ul class="list-disc list-inside space-y-1 text-gray-700 mb-4">
        <li>Hingga Mei 2025, lebih dari 2.000 kasus premanisme telah ditindak di seluruh Indonesia.</li>
        <li>Di wilayah Polda Metro Jaya, ratusan tersangka ditangkap hanya dalam satu bulan lewat Operasi Berantas Jaya.</li>
        <li>Modus mencakup: pemalakan, penguasaan lahan, parkir liar, hingga intimidasi oleh ormas berkedok sosial.</li>
      </ul>
      <p class="mb-2">Kawasan rawan antara lain:</p>
      <ul class="list-disc list-inside space-y-1 text-gray-700 mb-4">
        <li>Pasar Induk Kramat Jati</li>
        <li>Terminal Kalideres dan Pulo Gadung</li>
        <li>Pelabuhan Tanjung Priok</li>
        <li>Tanah Abang, Mangga Besar, dan Pluit</li>
      </ul>
      <p class="mb-4">Preman kerap memanfaatkan nama ormas, “koperasi”, atau jasa keamanan ilegal untuk melegitimasi aktivitas pungli dan pemerasan.</p>

      <hr class="my-6 border-gray-300" />

      <h3 class="text-xl font-semibold text-primary mt-6 mb-3">⚠️ Dampak Premanisme</h3>
      <ol class="list-decimal list-inside space-y-1 text-gray-700 mb-4 pl-4">
        <li><strong>Ekonomi terganggu:</strong> Pedagang pasar mengeluhkan pungutan hingga Rp 50.000/hari.</li>
        <li><strong>Investasi terhambat:</strong> Investor ragu masuk ke wilayah yang “dikuasai” kelompok tak resmi.</li>
        <li><strong>Kehidupan sosial mencekam:</strong> Warga enggan melapor karena takut dibalas.</li>
        <li><strong>Lembaga negara dilecehkan:</strong> Preman menghalangi petugas pajak, Satpol PP, dan kepolisian saat bertugas.</li>
      </ol>

      <hr class="my-6 border-gray-300" />

      <h3 class="text-xl font-semibold text-primary mt-6 mb-3">👮‍♂️ Respons Aparat dan Pemerintah</h3>
      <p class="mb-2">Polda Metro Jaya menggulirkan Operasi Berantas Jaya, yang fokus pada:</p>
      <ul class="list-disc list-inside space-y-1 text-gray-700 mb-4">
        <li>Penindakan tegas terhadap pelaku dan pemodalnya.</li>
        <li>Pembubaran posko ilegal dan pencopotan atribut ormas liar.</li>
        <li>Penertiban debt collector ilegal.</li>
        <li>Pembinaan sosial terhadap pelaku ringan, agar tidak kembali.</li>
      </ul>
      <p class="mb-2">Pemprov DKI juga terlibat dalam:</p>
      <ul class="list-disc list-inside space-y-1 text-gray-700 mb-4">
        <li>Penataan ulang pasar dan kawasan parkir.</li>
        <li>Penguatan Satpol PP di titik rawan.</li>
      </ul>
      
      <hr class="my-6 border-gray-300" />

      <h3 class="text-xl font-semibold text-primary mt-6 mb-3">💡 Solusi Jangka Panjang</h3>
      <ol class="list-decimal list-inside space-y-1 text-gray-700 mb-4">
        <li>Penegakan hukum tanpa kompromi: Preman harus diproses hukum, bukan sekadar dibina.</li>
        <li>Revitalisasi keamanan komunitas: Babinkamtibmas dan tokoh masyarakat dilibatkan secara aktif.</li>
        <li>Audit organisasi masyarakat: Ormas yang berperilaku menyimpang harus dicabut izinnya.</li>
        <li>Sistem pelaporan digital anonim: Masyarakat harus bisa lapor tanpa takut.</li>
        <li>Edukasi dan literasi hukum: Melawan preman bukan hanya tugas polisi, tapi kewajiban warga negara.</li>
      </ol>

      <hr class="my-6 border-gray-300" />
      
      <h3 class="text-xl font-semibold text-primary mt-6 mb-3">✍️ Penutup</h3>
      <p class="mb-4">Premanisme bukan sekadar kriminalitas kecil. Ia adalah wajah dari ketimpangan sosial, lemahnya pengawasan, dan kompromi terhadap hukum. Jakarta yang ingin menjadi kota global tak bisa membiarkan premanisme bertahan dalam bentuk apapun. Penindakan harus konsisten, merata, dan transparan—karena kota yang aman bukan hanya impian, melainkan hak setiap warga.</p>
    `
  }
];