
import React from 'react';

const content = (
  <>
    <p className="mb-4">NGawi - Kepolres Ngawi AKBP Dwiasi Wiyaputera bersama Bupati Ngawi Ony Anwar menandatangani Nota Kesepahaman (MoU) Program Bhatarling (Bhayangkara Pendamping Pertanian Ramah Lingkungan). Penandatanganan ini bertujuan untuk memperkuat sinergi dalam pendampingan petugas penyuluh lapangan dari dinas pertanian serta memastikan kelancaran distribusi pupuk subsidi kepada para petani di wilayah Kabupaten Ngawi.</p>
    
    <hr className="my-6 border-gray-300" />

    <h3 className="text-2xl font-semibold text-primary mt-6 mb-4">Detail Program Bhatarling</h3>
    <p className="mb-4">Program Bhatarling merupakan inisiatif strategis yang melibatkan peran aktif Bhayangkara (anggota Polri) dalam mendukung sektor pertanian. Fokus utama program ini adalah:</p>
    <ul className="list-disc list-inside space-y-2 text-gray-700 mb-6 pl-4">
      <li><strong>Pendampingan Penyuluh Pertanian:</strong> Anggota Polri akan bekerja sama dengan penyuluh pertanian lapangan untuk memberikan dukungan, keamanan, dan fasilitasi dalam menjalankan tugas penyuluhan kepada petani.</li>
      <li><strong>Pertanian Ramah Lingkungan:</strong> Mendorong praktik pertanian yang berkelanjutan dan ramah lingkungan, sejalan dengan upaya pelestarian alam dan peningkatan kualitas hasil panen.</li>
      <li><strong>Pengawasan Distribusi Pupuk Subsidi:</strong> Memastikan pupuk subsidi sampai kepada petani yang berhak secara tepat waktu dan tepat sasaran, serta mencegah potensi penyelewengan.</li>
    </ul>
    
    <hr className="my-6 border-gray-300" />
    
    <h3 className="text-2xl font-semibold text-primary mt-6 mb-4">Harapan dan Tujuan</h3>
    <p className="mb-4">Dalam sambutannya, Kepolres Ngawi AKBP Dwiasi Wiyaputera menyampaikan bahwa kerja sama ini diharapkan dapat meningkatkan kesejahteraan petani dan ketahanan pangan di Kabupaten Ngawi. "Dengan adanya pendampingan dari Bhayangkara, kami berharap para penyuluh pertanian dapat bekerja lebih optimal dan distribusi pupuk subsidi berjalan lancar tanpa hambatan," ujar AKBP Dwiasi Wiyaputera.</p>
    <p className="mb-4">Bupati Ngawi, Ony Anwar, menyambut baik program ini dan mengapresiasi peran serta Polres Ngawi dalam mendukung sektor pertanian. "Sinergi antara pemerintah daerah dan kepolisian sangat penting untuk kemajuan pertanian di Ngawi. Program Bhatarling ini adalah wujud nyata kolaborasi tersebut," kata Bupati Ony Anwar.</p>
    
    <hr className="my-6 border-gray-300" />

    <h3 className="text-xl font-semibold text-primary mt-6 mb-3">Langkah Selanjutnya</h3>
    <p className="mb-4">Setelah penandatanganan MoU ini, akan segera dibentuk tim kerja gabungan yang akan merumuskan langkah-langkah teknis pelaksanaan program Bhatarling di lapangan. Sosialisasi kepada para petani dan pihak terkait juga akan segera dilakukan untuk memastikan program ini dapat berjalan efektif dan memberikan manfaat maksimal.</p>
  </>
);

const mouBhatarlingNgawi = {
  slug: "mou-program-bhatarling-ngawi",
  title: "Penandatanganan MoU Program Bhatarling di Ngawi",
  description: "Kepolres Ngawi AKBP Dwiasi Wiyaputera dan Bupati Ngawi Ony Anwar menandatangani MoU Program Bhatarling (Bhayangkara Pendamping Pertanian Ramah Lingkungan).",
  image: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/e63bd6d88c7d8908408626465e921e59.jpg",
  image_description: "Penandatanganan MoU Program Bhatarling antara Kepolres Ngawi dan Bupati Ngawi.",
  category: "Kerja Sama Kepolisian",
  author: "Humas Polres Ngawi",
  date: "2025-06-13",
  content: content,
  keywords: "bhatarling, polres ngawi, pertanian ngawi, pupuk subsidi, kerja sama polri"
};

export default mouBhatarlingNgawi;
