
const tahapanPidanaMakar = {
    slug: "tahapan-pembuktian-dugaan-pidana-makar",
    title: "Tahapan Pembuktian Dugaan Pidana Makar",
    description: "Proses pembuktian dugaan pidana makar sesuai pasal 110 KUHP an d/au 106 jo 87 KUHP, meliputi pelaporan, penyelidikan, penetapan tersangka, dan peradilan.",
    image: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/ef07fa4468fbb9f638e88b59adca35f6.jpg",
    image_description: "Infografis tahapan pembuktian dugaan pidana makar.",
    category: "Hukum Pidana",
    author: "Divisi Hukum Polri",
    date: "2025-06-13",
    content: `
      <p class="mb-4">Proses pembuktian dugaan tindak pidana makar merupakan serangkaian tindakan hukum yang kompleks dan harus dilakukan secara cermat sesuai dengan ketentuan perundang-undangan yang berlaku, khususnya Pasal 110 KUHP dan/atau Pasal 106 jo Pasal 87 KUHP. Berikut adalah tahapan-tahapan penting dalam pembuktian dugaan pidana makar:</p>
      
      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">1. Pelaporan</h3>
      <div class="flex items-start mb-6">
        <div class="mr-4">
          <img   alt="Ilustrasi proses pelaporan polisi" class="w-32 h-auto rounded-lg shadow-md" src="https://images.unsplash.com/photo-1685157681640-506a6dfb2eeb" />
        </div>
        <p class="text-gray-700">Tahap awal dimulai dengan adanya laporan atau pengaduan dari masyarakat, atau temuan dari aparat penegak hukum mengenai adanya dugaan tindak pidana makar. Laporan ini harus disertai dengan informasi awal atau bukti permulaan yang cukup.</p>
      </div>
      <ul class="list-disc list-inside space-y-1 text-gray-700 mb-6 pl-4">
        <li>Penyampaian laporan polisi secara resmi.</li>
      </ul>
      
      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">2. Penyelidikan</h3>
      <div class="flex items-start mb-6">
        <div class="mr-4">
          <img   alt="Ilustrasi proses penyelidikan oleh detektif" class="w-32 h-auto rounded-lg shadow-md" src="https://images.unsplash.com/photo-1515286931300-dc3c73e0205f" />
        </div>
        <p class="text-gray-700">Setelah laporan diterima, pihak kepolisian akan melakukan serangkaian tindakan penyelidikan untuk mencari dan menemukan suatu peristiwa yang diduga sebagai tindak pidana guna menentukan dapat atau tidaknya dilakukan penyidikan. Ini melibatkan Olah Tempat Kejadian Perkara (TKP), gelar kasus awal, dan pengumpulan bukti-bukti awal.</p>
      </div>
      <ul class="list-disc list-inside space-y-1 text-gray-700 mb-6 pl-4">
        <li>Olah TKP.</li>
        <li>Gelar kasus.</li>
        <li>Pengumpulan bukti lebih lanjut.</li>
      </ul>

      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">3. Penetapan Tersangka</h3>
      <div class="flex items-start mb-6">
        <div class="mr-4">
          <img   alt="Ilustrasi penetapan tersangka dengan borgol" class="w-32 h-auto rounded-lg shadow-md" src="https://images.unsplash.com/photo-1694875464882-0d3e1a2efa5b" />
        </div>
        <p class="text-gray-700">Jika dari hasil penyidikan ditemukan bukti permulaan yang cukup (minimal dua alat bukti yang sah sesuai Pasal 184 KUHAP), maka penyidik dapat melakukan gelar perkara untuk menetapkan seseorang sebagai tersangka. Alat bukti dapat berupa keterangan saksi, keterangan ahli, surat, petunjuk, dan keterangan terdakwa.</p>
      </div>
      <ul class="list-disc list-inside space-y-1 text-gray-700 mb-6 pl-4">
        <li>Penetapan tersangka dengan minimal dua alat bukti.</li>
      </ul>

      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">4. Peradilan</h3>
      <div class="flex items-start mb-6">
        <div class="mr-4">
          <img   alt="Ilustrasi proses persidangan di pengadilan" class="w-32 h-auto rounded-lg shadow-md" src="https://images.unsplash.com/photo-1568092806323-8ec13dfa9b92" />
        </div>
        <p class="text-gray-700">Setelah berkas perkara dinyatakan lengkap (P21) oleh Jaksa Penuntut Umum (JPU), perkara akan dilimpahkan ke pengadilan untuk disidangkan. Dalam proses persidangan, akan dilakukan pemeriksaan terhadap terdakwa dan saksi-saksi, serta pembuktian oleh penuntut umum dan pembelaan dari terdakwa atau penasihat hukumnya. Hakim akan menilai seluruh alat bukti dan fakta persidangan sebelum menjatuhkan putusan.</p>
      </div>
      <ul class="list-disc list-inside space-y-1 text-gray-700 mb-6 pl-4">
        <li>Dilaksanakannya proses persidangan.</li>
      </ul>

      <hr class="my-6 border-gray-300" />

      <h3 class="text-xl font-semibold text-primary mt-6 mb-3">Penting untuk Diperhatikan</h3>
      <p class="mb-4">Setiap tahapan dalam proses pembuktian dugaan pidana makar harus dilakukan dengan menjunjung tinggi asas praduga tak bersalah dan hak-hak tersangka/terdakwa sebagaimana diatur dalam KUHAP. Transparansi dan akuntabilitas dalam setiap proses penegakan hukum adalah kunci untuk mencapai keadilan.</p>
    `
};

export default tahapanPidanaMakar;