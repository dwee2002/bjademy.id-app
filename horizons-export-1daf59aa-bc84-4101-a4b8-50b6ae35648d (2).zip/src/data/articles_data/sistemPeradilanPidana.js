export const sistemPeradilanPidanaArticles = [
  {
    slug: "kewenangan-penyidik-penuntut",
    title: "Kewenangan Penyidik dan Penuntut: Harmonisasi Fungsi dalam Sistem Peradilan Pidana",
    description: "Dalam sistem peradilan pidana Indonesia, kewenangan penyidik (Polri) dan penuntut umum (Kejaksaan) merupakan dua komponen yang krusial dalam menegakkan hukum secara adil dan efisien.",
    image_description: "Dua pejabat, satu polisi penyidik dan satu jaksa penuntut umum, sedang berdiskusi di depan tumpukan berkas perkara.",
    category: "Sistem Peradilan Pidana",
    date: "2025-06-03",
    content: `
      <p class="mb-4">Dalam sistem peradilan pidana Indonesia, kewenangan penyidik (Polri) dan penuntut umum (Kejaksaan) merupakan dua komponen yang krusial dalam menegakkan hukum secara adil dan efisien. Namun, dalam praktiknya, terdapat tumpang tindih, perbedaan persepsi, bahkan konflik kewenangan yang dapat menghambat penegakan hukum.</p>
      
      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">1. Landasan Hukum Kewenangan</h3>
      <div class="pl-4">
        <h4 class="text-xl font-semibold text-secondary mt-4 mb-2">a. Penyidik (Polri)</h4>
        <ul class="list-disc list-inside space-y-1 text-gray-700 mb-3 ml-4">
          <li>Berdasarkan Pasal 6 KUHAP dan UU No. 2 Tahun 2002, penyidik Polri berwenang melakukan:</li>
          <ul class="list-disc list-inside space-y-1 text-gray-700 mb-3 ml-6">
            <li>Penyelidikan dan penyidikan</li>
            <li>Penangkapan, penahanan, penggeledahan, dan penyitaan</li>
            <li>Pemanggilan dan pemeriksaan saksi, tersangka, dan ahli</li>
            <li>Penyerahan berkas perkara ke jaksa</li>
          </ul>
        </ul>

        <h4 class="text-xl font-semibold text-secondary mt-4 mb-2">b. Penuntut Umum (Kejaksaan)</h4>
        <ul class="list-disc list-inside space-y-1 text-gray-700 mb-3 ml-4">
          <li>Berdasarkan Pasal 14 KUHAP dan UU No. 16 Tahun 2004 tentang Kejaksaan:</li>
          <ul class="list-disc list-inside space-y-1 text-gray-700 mb-3 ml-6">
            <li>Melakukan penuntutan</li>
            <li>Mengendalikan penyidikan (pasal 8 ayat 3)</li>
            <li>Menyusun surat dakwaan dan membuktikan di pengadilan</li>
            <li>Menyampaikan petunjuk kepada penyidik (P-19), menyatakan lengkap (P-21)</li>
          </ul>
        </ul>
      </div>
      
      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">2. Permasalahan di Lapangan</h3>
      <div class="pl-4">
        <ul class="list-disc list-inside space-y-1 text-gray-700 mb-3 ml-4">
          <li>Dualisme tafsir terkait batas kewenangan pengendalian perkara.</li>
          <li>Ketidaksepahaman dalam penilaian alat bukti, terutama pada kasus yang kompleks (korupsi, siber, pidana ekonomi).</li>
          <li>Keterlambatan P-19 berulang hingga mempengaruhi asas peradilan cepat dan sederhana.</li>
          <li>Kurangnya sistem terpadu digital dalam tracking penanganan perkara antarinstansi.</li>
        </ul>
      </div>

      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">3. Rekomendasi Kebijakan</h3>
      <div class="pl-4">
        <h4 class="text-xl font-semibold text-secondary mt-4 mb-2">✅ a. Penguatan Harmonisasi Kelembagaan</h4>
        <ul class="list-disc list-inside space-y-1 text-gray-700 mb-3 ml-4">
          <li>Revisi terbatas KUHAP untuk menegaskan posisi jaksa sebagai pengendali perkara, namun dengan prinsip koordinatif bukan subordinatif.</li>
          <li>Pembentukan Forum Koordinasi Penyidikan dan Penuntutan (FKPP) di tingkat Polda–Kejati.</li>
        </ul>

        <h4 class="text-xl font-semibold text-secondary mt-4 mb-2">✅ b. Digitalisasi Sistem Penanganan Perkara</h4>
        <ul class="list-disc list-inside space-y-1 text-gray-700 mb-3 ml-4">
          <li>Pengembangan Sistem Perkara Terpadu Polri–Kejaksaan berbasis timestamp dan status P19/P21 real-time.</li>
          <li>Integrasi case tracker antara e-penyidikan Polri dengan CMS Kejaksaan.</li>
        </ul>

        <h4 class="text-xl font-semibold text-secondary mt-4 mb-2">✅ c. Standarisasi Petunjuk dan Supervisi</h4>
        <ul class="list-disc list-inside space-y-1 text-gray-700 mb-3 ml-4">
          <li>Petunjuk jaksa (P-19) harus bersifat spesifik, tidak berulang, dan sesuai hukum acara pidana.</li>
          <li>Perlu mekanisme mediasi antarpenyidik-jaksa bila terjadi kebuntuan hukum.</li>
        </ul>

        <h4 class="text-xl font-semibold text-secondary mt-4 mb-2">✅ d. Pelatihan Bersama dan Evaluasi Kinerja Bersinergi</h4>
        <ul class="list-disc list-inside space-y-1 text-gray-700 mb-3 ml-4">
          <li>Pelatihan hukum acara bersama bagi penyidik dan jaksa penuntut, khususnya pada kasus dengan kompleksitas tinggi.</li>
          <li>Penilaian kinerja berbasis capaian penyelesaian perkara dengan pendekatan one team–one goal.</li>
        </ul>
      </div>
      
      <hr class="my-6 border-gray-300" />
      
      <h3 class="text-xl font-semibold text-primary mt-6 mb-3">Penutup</h3>
      <p class="mb-4">Kewenangan penyidik dan penuntut adalah dua sisi mata uang dalam sistem keadilan pidana. Untuk mencapai keadilan yang substantif dan efisien, sinergi keduanya harus didorong melalui kebijakan yang adil, digitalisasi sistem, dan dialog profesional. Polda Metro Jaya dapat menjadi percontohan kolaborasi penyidik–penuntut berbasis integritas, teknologi, dan semangat reformasi hukum.</p>
    `
  }
];