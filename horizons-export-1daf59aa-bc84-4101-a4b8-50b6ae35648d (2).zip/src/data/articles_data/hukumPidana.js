export const hukumPidanaArticles = [
  {
    slug: "pasal-303-kuhp-judi-online",
    title: "Pasal 303 KUHP dan Jerat Hukum Judi Online: Analisis dan Upaya Pemberantasan",
    description: "Meskipun tidak secara eksplisit menyebut 'judi online', Pasal 303 KUHP menjadi landasan utama aparat penegak hukum untuk menjerat pelaku dan bandar judi di ruang digital.",
    image_description: "Tampilan antarmuka permainan judi online di layar laptop dengan palu hakim di depannya, melambangkan hukum.",
    category: "Hukum Pidana",
    date: "2025-06-08",
    content: `
      <p class="mb-4">Maraknya judi online telah menjadi masalah sosial dan hukum yang meresahkan di Indonesia. Fenomena ini tidak hanya menguras sumber daya ekonomi masyarakat, tetapi juga memicu berbagai tindak kejahatan turunan. Meskipun Kitab Undang-Undang Hukum Pidana (KUHP) disusun jauh sebelum era internet, Pasal 303 KUHP tetap menjadi senjata utama penegak hukum untuk memerangi perjudian, termasuk yang berbasis online.</p>

      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Bunyi dan Tafsir Pasal 303 KUHP</h3>
      <p class="mb-4">Pasal 303 KUHP pada intinya melarang setiap perbuatan yang menawarkan atau memberikan kesempatan untuk permainan judi dan menjadikannya sebagai pencaharian. Unsur-unsur penting dalam pasal ini adalah:</p>
      <ul class="list-disc list-inside space-y-2 text-gray-700 mb-4 pl-4">
        <li><strong>Permainan Judi:</strong> Setiap permainan yang pada umumnya bergantung pada peruntungan atau untung-untungan semata.</li>
        <li><strong>Menawarkan atau Memberi Kesempatan:</strong> Termasuk membuat, menyelenggarakan, atau menjadi perantara dalam permainan judi.</li>
        <li><strong>Menjadikan Pencaharian:</strong> Melakukan kegiatan perjudian sebagai mata pencaharian utama atau sampingan.</li>
      </ul>
      <p class="mb-4">Dalam konteks judi online, penafsiran hukum diperluas. "Menawarkan kesempatan" ditafsirkan mencakup tindakan membuat situs web, menjadi admin, mempromosikan lewat media sosial, hingga menyediakan rekening untuk transaksi deposit dan withdraw.</p>
      
      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Kombinasi dengan UU ITE</h3>
      <p class="mb-4">Untuk memperkuat jerat hukum, penyidik seringkali mengombinasikan Pasal 303 KUHP dengan Pasal 27 ayat (2) UU No. 19 Tahun 2016 tentang Informasi dan Transaksi Elektronik (UU ITE). Pasal ini secara spesifik melarang setiap orang dengan sengaja dan tanpa hak mendistribusikan dan/atau mentransmisikan dan/atau membuat dapat diaksesnya Informasi Elektronik dan/atau Dokumen Elektronik yang memiliki muatan perjudian.</p>
      <p class="mb-4">Kombinasi kedua pasal ini memungkinkan penegak hukum menjerat tidak hanya bandar dan pemain, tetapi juga pihak-pihak lain yang terlibat dalam ekosistem judi online, seperti influencer yang mempromosikan, penyedia rekening, dan bahkan pemain biasa.</p>
      
      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Upaya Pemberantasan oleh Polri</h3>
      <ol class="list-decimal list-inside space-y-2 text-gray-700 mb-4 pl-4">
        <li><strong>Patroli Siber:</strong> Direktorat Tindak Pidana Siber (Dittipidsiber) Bareskrim Polri secara rutin melakukan patroli untuk mengidentifikasi situs-situs dan akun media sosial yang mempromosikan judi online.</li>
        <li><strong>Pemblokiran Situs:</strong> Bekerja sama dengan Kementerian Komunikasi dan Informatika (Kominfo), Polri merekomendasikan pemblokiran ribuan situs judi online setiap bulannya.</li>
        <li><strong>Penindakan Tegas:</strong> Melakukan penangkapan terhadap jaringan bandar judi online, termasuk yang beroperasi dari luar negeri, melalui kerja sama internasional.</li>
        <li><strong>Edukasi Publik:</strong> Mengkampanyekan bahaya judi online melalui berbagai platform media untuk meningkatkan kesadaran masyarakat.</li>
      </ol>

      <hr class="my-6 border-gray-300" />

      <h3 class="text-xl font-semibold text-primary mt-6 mb-3">Tantangan dan Penutup</h3>
      <p class="mb-4">Meskipun upaya pemberantasan gencar dilakukan, tantangan tetap besar. Situs judi online mudah dibuat kembali dengan nama baru, dan banyak server yang ditempatkan di luar negeri, menyulitkan penindakan hukum. Oleh karena itu, selain penegakan hukum yang tegas, diperlukan pendekatan komprehensif yang melibatkan edukasi, pemulihan korban kecanduan judi, serta penguatan sistem keuangan untuk mendeteksi transaksi mencurigakan. Perang melawan judi online adalah pertarungan jangka panjang yang membutuhkan sinergi dari semua elemen bangsa.</p>
    `
  }
];