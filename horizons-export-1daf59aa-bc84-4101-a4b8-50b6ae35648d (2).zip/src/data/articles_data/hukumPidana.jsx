
import React from 'react';

const content = (
  <>
      <p className="mb-4 text-lg leading-relaxed">Hukum pidana adalah bagian dari hukum publik yang mengatur tindakan-tindakan yang dilarang oleh negara karena dianggap merugikan dan membahayakan masyarakat, serta menetapkan sanksi bagi para pelanggarnya. Memahami dasar-dasar hukum pidana sangat penting, tidak hanya bagi para penegak hukum, tetapi juga bagi setiap warga negara agar terhindar dari perbuatan melawan hukum.</p>
      
      <hr className="my-6 border-gray-300" />

      <h3 className="text-2xl font-semibold text-primary mt-6 mb-4">Tujuan Hukum Pidana</h3>
      <ul className="list-disc list-inside space-y-2 text-muted-foreground mb-4 pl-4">
        <li><strong>Melindungi Kepentingan Umum:</strong> Menjaga ketertiban, keamanan, dan kedamaian dalam masyarakat.</li>
        <li><strong>Memberikan Efek Jera:</strong> Mencegah pelaku dan orang lain untuk melakukan kejahatan serupa di masa depan.</li>
        <li><strong>Mendidik Masyarakat:</strong> Menanamkan nilai-nilai dan norma-norma yang berlaku agar ditaati oleh seluruh lapisan masyarakat.</li>
        <li><strong>Menyelesaikan Konflik:</strong> Menyediakan mekanisme penyelesaian konflik yang adil melalui proses peradilan.</li>
      </ul>
      
      <hr className="my-6 border-gray-300" />
      
      <h3 className="text-2xl font-semibold text-primary mt-6 mb-4">Asas-Asas Fundamental dalam Hukum Pidana Indonesia</h3>
      
      <h4 className="text-xl font-semibold text-gray-700 mt-4 mb-2">1. Asas Legalitas (Nullum Delictum, Nulla Poena Sine Praevia Lege Poenali)</h4>
      <p className="text-muted-foreground mb-4 pl-4">Seseorang tidak dapat dihukum kecuali atas perbuatan yang telah diatur sebagai tindak pidana dalam undang-undang sebelum perbuatan tersebut dilakukan. Asas ini menjamin kepastian hukum.</p>
      
      <h4 className="text-xl font-semibold text-gray-700 mt-4 mb-2">2. Asas Teritorial</h4>
      <p className="text-muted-foreground mb-4 pl-4">Hukum pidana Indonesia berlaku bagi setiap orang yang melakukan tindak pidana di dalam wilayah Indonesia, baik WNI maupun WNA.</p>

      <h4 className="text-xl font-semibold text-gray-700 mt-4 mb-2">3. Asas Personalitas (Nasional Aktif)</h4>
      <p className="text-muted-foreground mb-4 pl-4">Hukum pidana Indonesia berlaku bagi Warga Negara Indonesia (WNI) yang melakukan tindak pidana di luar negeri.</p>

      <h4 className="text-xl font-semibold text-gray-700 mt-4 mb-2">4. Asas Perlindungan (Nasional Pasif)</h4>
      <p className="text-muted-foreground mb-4 pl-4">Hukum pidana Indonesia dapat diterapkan terhadap siapapun (WNI atau WNA) yang melakukan kejahatan di luar negeri yang merugikan kepentingan nasional Indonesia.</p>

      <hr className="my-6 border-gray-300" />

      <h3 className="text-xl font-semibold text-primary mt-6 mb-3">Unsur-Unsur Tindak Pidana</h3>
      <p className="mb-4 text-muted-foreground">Secara umum, sebuah perbuatan dapat dikategorikan sebagai tindak pidana jika memenuhi dua unsur utama:</p>
      <ul className="list-decimal list-inside space-y-1 text-muted-foreground mb-4 pl-4">
          <li><strong>Unsur Objektif (Actus Reus):</strong> Adanya perbuatan/tindakan fisik yang dilarang oleh hukum.</li>
          <li><strong>Unsur Subjektif (Mens Rea):</strong> Adanya niat jahat atau kesalahan pada diri pelaku saat melakukan perbuatan tersebut (kesengajaan atau kelalaian).</li>
      </ul>

      <h3 className="text-xl font-semibold text-primary mt-6 mb-3">Penutup</h3>
      <p className="mb-4 text-muted-foreground">Pemahaman yang baik tentang hukum pidana membantu menciptakan kesadaran hukum di tengah masyarakat. Dengan mengetahui batasan-batasan yang diatur oleh hukum, setiap individu dapat berperan aktif dalam menjaga ketertiban dan keadilan sosial.</p>
  </>
);

const hukumPidana = {
    slug: "mengenal-dasar-dasar-hukum-pidana-di-indonesia",
    title: "Mengenal Dasar-Dasar Hukum Pidana di Indonesia",
    description: "Memahami apa itu hukum pidana, tujuannya, asas-asas fundamental yang melandasinya, serta unsur-unsur penting yang membentuk suatu tindak pidana.",
    image: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/78c0e664ce9c8a94605de372132a5433.jpg",
    image_description: "Palu hakim di atas buku hukum, melambangkan keadilan dan penegakan hukum pidana.",
    category: "Hukum",
    author: "Tim Hukum Bratajaya",
    date: "2025-06-08",
    content: content,
    keywords: "hukum pidana, asas legalitas, KUHP, tindak pidana, actus reus, mens rea, sistem peradilan"
};

export default hukumPidana;
