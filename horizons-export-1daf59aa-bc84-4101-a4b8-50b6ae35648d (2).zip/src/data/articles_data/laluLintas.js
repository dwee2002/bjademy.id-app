export const laluLintasArticles = [
  {
    slug: "urgensi-etle-reformasi-lalu-lintas",
    title: "Urgensi Tilang Elektronik (ETLE) dalam Reformasi Lalu Lintas",
    description: "Electronic Traffic Law Enforcement (ETLE) menjadi ujung tombak reformasi dalam penegakan hukum lalu lintas di Indonesia, bertujuan untuk meningkatkan disiplin, mengurangi interaksi pungli, dan menciptakan keadilan.",
    image_description: "Kamera ETLE modern terpasang di persimpangan jalan yang ramai di Jakarta, memantau lalu lintas.",
    category: "Lalu Lintas",
    date: "2025-06-06",
    content: `
      <p class="mb-4">Electronic Traffic Law Enforcement (ETLE) atau tilang elektronik bukan lagi sekadar wacana, melainkan telah menjadi ujung tombak reformasi dalam penegakan hukum lalu lintas di Indonesia. Diinisiasi oleh Korlantas Polri, implementasi ETLE bertujuan untuk menciptakan budaya tertib berlalu lintas yang transparan, akuntabel, dan berkeadilan, sekaligus meminimalisir potensi pungutan liar (pungli) di lapangan.</p>
      
      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Bagaimana ETLE Bekerja?</h3>
      <p class="mb-4">Sistem ETLE terintegrasi melalui serangkaian tahapan digital:</p>
      <ol class="list-decimal list-inside space-y-2 text-gray-700 mb-4 pl-4">
        <li><strong>Deteksi Pelanggaran:</strong> Kamera canggih dengan teknologi ANPR (Automatic Number Plate Recognition) secara otomatis menangkap gambar kendaraan yang melanggar, seperti menerobos lampu merah, tidak menggunakan sabuk pengaman, atau menggunakan ponsel saat berkendara.</li>
        <li><strong>Verifikasi Petugas:</strong> Data pelanggaran dikirim ke back office, di mana petugas melakukan verifikasi untuk memastikan keabsahan pelanggaran.</li>
        <li><strong>Pengiriman Surat Konfirmasi:</strong> Setelah terverifikasi, surat konfirmasi pelanggaran dikirim ke alamat pemilik kendaraan yang terdaftar, lengkap dengan bukti foto dan rincian pelanggaran.</li>
        <li><strong>Konfirmasi Pelanggar:</strong> Pemilik kendaraan wajib melakukan konfirmasi (baik secara online maupun offline) dalam batas waktu yang ditentukan.</li>
        <li><strong>Penerbitan Tilang dan Pembayaran:</strong> Jika pelanggaran diakui, petugas akan menerbitkan surat tilang dengan kode BRIVA untuk pembayaran denda melalui bank.</li>
      </ol>
      
      <hr class="my-6 border-gray-300" />
      
      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Manfaat Implementasi ETLE</h3>
      <ul class="list-disc list-inside space-y-2 text-gray-700 mb-4 pl-4">
        <li><strong>Meningkatkan Disiplin:</strong> Kesadaran bahwa setiap pelanggaran akan tercatat oleh sistem mendorong pengendara untuk lebih patuh pada aturan.</li>
        <li><strong>Mengurangi Pungli:</strong> Meminimalisir interaksi langsung antara pelanggar dan petugas di lapangan, sehingga menutup celah untuk praktik pungli.</li>
        <li><strong>Penegakan Hukum yang Objektif:</strong> Bukti digital yang kuat (foto dan video) membuat penindakan menjadi lebih objektif dan sulit dibantah.</li>
        <li><strong>Efisiensi Data:</strong> Data pelanggaran terekam secara digital, memudahkan analisis untuk menentukan titik rawan pelanggaran dan merumuskan kebijakan lalu lintas yang lebih baik.</li>
      </ul>
      
      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Tantangan dan Pengembangan ke Depan</h3>
      <p class="mb-4">Meskipun efektif, implementasi ETLE masih menghadapi tantangan, seperti data kendaraan yang belum diperbarui (misalnya setelah jual-beli), keterbatasan jangkauan kamera di seluruh wilayah, dan perlunya edukasi berkelanjutan kepada masyarakat. Ke depan, pengembangan ETLE akan mencakup:</p>
      <ul class="list-disc list-inside space-y-1 text-gray-700 mb-4 pl-4">
        <li><strong>ETLE Mobile:</strong> Petugas dilengkapi dengan kamera portabel untuk menindak pelanggaran di area yang tidak terjangkau kamera statis.</li>
        <li><strong>Integrasi dengan Sistem Lain:</strong> Menghubungkan data ETLE dengan sistem perpanjangan SIM dan STNK, di mana pelanggar yang belum membayar denda akan diblokir layanannya.</li>
        <li><strong>Pengenalan Wajah (Face Recognition):</strong> Untuk memastikan identitas pelanggar sebenarnya, terutama pada kasus penggunaan kendaraan pinjaman.</li>
      </ul>

      <h3 class="text-xl font-semibold text-primary mt-6 mb-3">Penutup</h3>
      <p class="mb-4">ETLE adalah langkah maju yang signifikan dalam modernisasi penegakan hukum lalu lintas di Indonesia. Dengan dukungan teknologi dan partisipasi aktif masyarakat, sistem ini berpotensi besar untuk mewujudkan lalu lintas yang lebih aman, tertib, dan beradab.</p>
    `
  }
];