import React from 'react';

const tipsLolosSeleksiTaruna = {
    slug: "tips-lolos-seleksi-taruna-dari-alumni",
    title: "Tips Lolos Seleksi Taruna dari Alumni Bratajaya Academy",
    description: "Dapatkan 5 tips jitu lolos seleksi Akpol, Akademi TNI, dan Bintara dari para alumni sukses Bratajaya Academy. Mulai dari disiplin latihan, simulasi CAT, hingga persiapan mental.",
    image: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/78f4efde556c6179f9fbe21acd660f3b.jpg",
    image_description: "Perjalanan sukses alumni Bratajaya Academy, dari latihan hingga kelulusan.",
    category: "Tips & Trik",
    author: "Tim Bratajaya Academy",
    date: "2025-07-11",
    content: `
      <p class="text-lg mb-6">Kami mewawancarai beberapa alumni yang berhasil lolos seleksi Akpol, Akademi TNI, maupun Bintara Polri dan TNI. Inilah 5 tips utama dari mereka yang mengikuti bimbingan di Bratajaya Academy:</p>
      
      <div class="space-y-8">

        <!-- Tip 1 -->
        <div class="p-6 bg-slate-50 rounded-xl border border-slate-200">
          <h3 class="text-xl font-bold text-primary mb-3">✅ 1. Disiplin Ikuti Jadwal Latihan, Jangan Pilih-Pilih Materi</h3>
          <blockquote class="border-l-4 border-primary pl-4 mb-4 italic text-gray-700">
            "Waktu ikut Bratajaya, saya ikuti semua kelas—bahkan yang saya pikir saya sudah bisa. Ternyata itu penting banget. Jadwal akademik, fisik, sampai motivasi mental itu saling melengkapi."
            <footer class="mt-2 text-sm font-semibold text-gray-600">— Aulia (Lolos Sepolwan 2024)</footer>
          </blockquote>
          <p><strong class="font-semibold text-primary">Tips:</strong> Jangan hanya fokus ke akademik kalau kamu merasa lemah di fisik, atau sebaliknya. Ikuti semua materi secara konsisten.</p>
        </div>

        <!-- Tip 2 -->
        <div class="p-6 bg-slate-50 rounded-xl border border-slate-200">
          <h3 class="text-xl font-bold text-primary mb-3">✅ 2. Ikuti Simulasi CAT dan Psikotes Sebanyak Mungkin</h3>
          <blockquote class="border-l-4 border-primary pl-4 mb-4 italic text-gray-700">
            "Saya sempat gagal tahun sebelumnya karena nilai CAT saya tipis di bawah passing grade. Di Bratajaya, saya dibiasakan ikut tryout nasional hampir tiap pekan. Itu bikin saya terbiasa dengan tekanan dan waktu."
            <footer class="mt-2 text-sm font-semibold text-gray-600">— Nadya (Lolos IPDN)</footer>
          </blockquote>
          <p><strong class="font-semibold text-primary">Tips:</strong> Jangan cuma belajar teori. Ikuti simulasi real-time, latihan psikotes, dan evaluasi berkala supaya terbiasa saat tes sungguhan.</p>
        </div>

        <!-- Tip 3 -->
        <div class="p-6 bg-slate-50 rounded-xl border border-slate-200">
          <h3 class="text-xl font-bold text-primary mb-3">✅ 3. Bangun Kebiasaan Latihan Fisik Pagi Hari</h3>
          <blockquote class="border-l-4 border-primary pl-4 mb-4 italic text-gray-700">
            "Latihan fisik bareng tim Bratajaya sangat membantu. Saya jadi terbiasa bangun pagi, lari 12 menit, push-up, sit-up, dan shuttle run. Pas tes samapta, saya sudah tahu ritmenya."
            <footer class="mt-2 text-sm font-semibold text-gray-600">— MARDIYANTO (Lolos AKMIL 2023)</footer>
          </blockquote>
          <p><strong class="font-semibold text-primary">Tips:</strong> Mulai rutinitas fisik minimal 3–4 kali seminggu sejak dini. Jangan tunggu undangan tes baru latihan.</p>
        </div>

        <!-- Tip 4 -->
        <div class="p-6 bg-slate-50 rounded-xl border border-slate-200">
          <h3 class="text-xl font-bold text-primary mb-3">✅ 4. Jaga Pola Makan & Kesehatan Sejak Awal</h3>
          <blockquote class="border-l-4 border-primary pl-4 mb-4 italic text-gray-700">
            "Di Bratajaya, kami diajarkan soal standar postur ideal, tips jaga tensi, sampai menghindari makanan pemicu kolesterol. Saya bahkan tahu latihan pernapasan untuk tes visus mata."
            <footer class="mt-2 text-sm font-semibold text-gray-600">— Brian Bahat (Lolos AKPOL 2022)</footer>
          </blockquote>
          <p><strong class="font-semibold text-primary">Tips:</strong> Perhatikan nutrisi, jam tidur, dan pola makan. Jangan remehkan tes kesehatan, karena banyak peserta gugur di sini.</p>
        </div>

        <!-- Tip 5 -->
        <div class="p-6 bg-slate-50 rounded-xl border border-slate-200">
          <h3 class="text-xl font-bold text-primary mb-3">✅ 5. Bangun Mental Juang & Jangan Takut Gagal</h3>
          <blockquote class="border-l-4 border-primary pl-4 mb-4 italic text-gray-700">
            "Saya pernah gagal dua kali. Di Bratajaya, saya dibina untuk tidak sekadar kuat fisik, tapi juga kuat mental. Pembinaan mental ideologi dan sesi motivasi sangat membantu saya bangkit."
            <footer class="mt-2 text-sm font-semibold text-gray-600">— Malla Maldiva (Lolos PPSS POLRI 2024)</footer>
          </blockquote>
          <p><strong class="font-semibold text-primary">Tips:</strong> Mental tahan banting adalah kunci utama. Jangan mudah minder atau takut gagal. Bratajaya punya banyak alumni yang sukses setelah mencoba lebih dari sekali.</p>
        </div>

      </div>

      <hr class="my-8 border-gray-300" />

      <div class="mt-8 text-center p-6 bg-blue-50 rounded-xl">
        <h3 class="text-2xl font-bold text-primary mb-4">💬 Pesan dari Para Alumni</h3>
        <div class="space-y-4">
            <p class="text-lg italic text-gray-800">"Bimbingan di Bratajaya itu bukan sekadar belajar, tapi pembentukan karakter. Disiplin, tekun, dan percaya diri."</p>
            <p class="font-semibold text-gray-600">— IFANTRI (SPN LIDO 2021)</p>
            <p class="text-lg italic text-gray-800 mt-4">"Kalau kamu serius, Bratajaya adalah tempat terbaik untuk mempersiapkan segalanya."</p>
            <p class="font-semibold text-gray-600">— ALVIN D (SPN LIDO 2021)</p>
        </div>
      </div>
    `
};

export default tipsLolosSeleksiTaruna;