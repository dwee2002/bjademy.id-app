export const etikaKepolisianArticles = [
  {
    slug: "etika-media-sosial-polri",
    title: "Etika dan Panduan Penggunaan Media Sosial bagi Anggota Polri",
    description: "Di era digital, media sosial menjadi cerminan institusi. Anggota Polri harus bijak dalam berekspresi untuk menjaga citra, kepercayaan publik, dan marwah institusi.",
    image_description: "Seorang polisi berseragam menggunakan smartphone dengan ikon media sosial di sekelilingnya, merepresentasikan etika digital.",
    category: "Etika Kepolisian",
    date: "2025-06-12",
    content: `
      <p class="mb-4">Di era digital, media sosial bukan lagi sekadar ruang pribadi, tetapi etalase yang mencerminkan nilai dan profesionalisme individu, termasuk bagi anggota Kepolisian Negara Republik Indonesia (Polri). Setiap unggahan, komentar, atau interaksi dapat dengan cepat menjadi sorotan publik dan memengaruhi citra institusi secara keseluruhan. Oleh karena itu, pemahaman mendalam mengenai etika dan panduan penggunaan media sosial menjadi suatu keharusan.</p>
      
      <hr class="my-6 border-gray-300" />

      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Mengapa Etika Bermedia Sosial Penting bagi Anggota Polri?</h3>
      <ul class="list-disc list-inside space-y-2 text-gray-700 mb-4 pl-4">
        <li><strong>Menjaga Wibawa Institusi:</strong> Perilaku anggota di dunia maya adalah cerminan langsung dari citra Polri di mata masyarakat.</li>
        <li><strong>Mencegah Konflik Kepentingan:</strong> Menghindari unggahan yang dapat ditafsirkan sebagai keberpihakan, terutama dalam isu politik, SARA, atau kasus yang sedang ditangani.</li>
        <li><strong>Melindungi Informasi Rahasia:</strong> Mencegah kebocoran informasi operasional, data internal, atau hal-hal yang bersifat rahasia jabatan.</li>
        <li><strong>Membangun Kepercayaan Publik:</strong> Menggunakan media sosial sebagai sarana positif untuk edukasi, sosialisasi, dan membangun hubungan baik dengan masyarakat.</li>
      </ul>
      
      <hr class="my-6 border-gray-300" />
      
      <h3 class="text-2xl font-semibold text-primary mt-6 mb-4">Panduan Praktis Bermedia Sosial (Do's and Don'ts)</h3>
      
      <h4 class="text-xl font-semibold text-green-600 mt-4 mb-2">Yang Harus Dilakukan (Do's):</h4>
      <ul class="list-disc list-inside space-y-1 text-gray-700 mb-4 pl-4">
        <li>Berpikir sebelum mengunggah (Think before posting).</li>
        <li>Menyebarkan konten yang bersifat informatif, edukatif, dan positif.</li>
        <li>Menunjukkan sikap humanis dan empati dalam berinteraksi.</li>
        <li>Menggunakan bahasa yang santun, sopan, dan mudah dipahami.</li>
        <li>Segera meluruskan informasi yang keliru (klarifikasi) jika diperlukan, melalui jalur resmi.</li>
      </ul>
      
      <h4 class="text-xl font-semibold text-destructive mt-4 mb-2">Yang Harus Dihindari (Don'ts):</h4>
      <ul class="list-disc list-inside space-y-1 text-gray-700 mb-4 pl-4">
        <li>Mengunggah foto atau video yang menampilkan gaya hidup mewah (hedonisme).</li>
        <li>Memberikan komentar negatif, provokatif, atau ujaran kebencian.</li>
        <li>Membocorkan informasi terkait pelaksanaan tugas, operasi, atau identitas rekan kerja.</li>
        <li>Mengeluh tentang pekerjaan, pimpinan, atau institusi di ruang publik.</li>
        <li>Terlibat dalam perdebatan politik praktis atau menunjukkan keberpihakan pada salah satu calon/partai.</li>
      </ul>

      <hr class="my-6 border-gray-300" />

      <h3 class="text-xl font-semibold text-primary mt-6 mb-3">Aspek Hukum yang Perlu Diperhatikan</h3>
      <p class="mb-4">Selain Peraturan Kapolri (Perkap) tentang etika, anggota Polri juga terikat pada UU ITE. Pelanggaran seperti pencemaran nama baik, penyebaran berita bohong (hoax), atau ujaran kebencian dapat berujung pada sanksi disiplin, kode etik, bahkan pidana.</p>

      <h3 class="text-xl font-semibold text-primary mt-6 mb-3">Penutup</h3>
      <p class="mb-4">Jejak digital abadi. Kebijaksanaan dalam menggunakan media sosial adalah bentuk tanggung jawab setiap anggota Polri untuk menjaga kehormatan diri, keluarga, dan institusi. Jadikan media sosial sebagai alat untuk mendekatkan Polri dengan masyarakat, bukan sebaliknya.</p>
    `
  }
];