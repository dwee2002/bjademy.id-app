
export const categories = [];
