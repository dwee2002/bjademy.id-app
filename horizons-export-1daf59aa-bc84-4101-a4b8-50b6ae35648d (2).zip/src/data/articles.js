import mengapaBratajayaPilihanTerbaik from './articles_data/mengapaBratajayaPilihanTerbaik';
import tipsLolosSeleksiTaruna from './articles_data/tipsLolosSeleksiTaruna.jsx';
import rahasiaKuatPullUpLari from './articles_data/rahasiaKuatPullUpLari.jsx';

export const articles = [
  rahasiaKuatPullUpLari,
  tipsLolosSeleksiTaruna,
  mengapaBratajayaPilihanTerbaik,
].filter(Boolean); // Filter out any undefined entries from commented-out imports

export const getArticleBySlug = (slug) => {
  return articles.find(article => article && article.slug === slug);
};