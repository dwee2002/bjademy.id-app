import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { articles } from '@/data/articles';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar, User } from 'lucide-react';
import SEO from '@/components/SEO';

const BlogPage = () => {
    // Sort articles by date, newest first
    const sortedArticles = [...articles].sort((a, b) => new Date(b.date) - new Date(a.date));

    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: { staggerChildren: 0.1 }
        }
    };

    const itemVariants = {
        hidden: { y: 20, opacity: 0 },
        visible: {
            y: 0,
            opacity: 1,
            transition: {
                type: 'spring',
                stiffness: 100
            }
        }
    };

    return (
        <>
            <SEO
                title="Blog & Artikel - Tips Sukses Masuk TNI, Polri & Kedinasan | Bratajaya Academy"
                description="Kumpulan artikel, panduan, dan tips terbaru dari Bratajaya Academy untuk membantu Anda lolos seleksi TNI, Polri, dan Sekolah Kedinasan di Jakarta, Tangerang, Depok, dan Bekasi."
                keywords="Blog bimbel TNI, artikel bimbel Polri, tips seleksi Akpol, panduan masuk kedinasan, strategi tes TNI Polri, Bratajaya Academy blog"
                pageUrl="/blog"
            />
            <div className="container mx-auto px-4 py-16">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                    className="text-center mb-12"
                >
                    <h1 className="text-4xl sm:text-5xl font-bold text-primary">Blog Bratajaya Academy</h1>
                    <p className="mt-4 text-lg text-muted-foreground max-w-3xl mx-auto">
                        Wawasan, tips, dan cerita inspiratif untuk menemani perjalanan Anda menuju seragam impian.
                    </p>
                </motion.div>

                <motion.div
                    className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
                    variants={containerVariants}
                    initial="hidden"
                    animate="visible"
                >
                    {sortedArticles.map((article) => (
                        <motion.div key={article.slug} variants={itemVariants}>
                            <Card className="h-full flex flex-col overflow-hidden hover:shadow-xl transition-shadow duration-300">
                                <Link to={`/blog/${article.slug}`}>
                                    <img
                                        src={article.image || "https://images.unsplash.com/photo-1557682250-33bd709cbe85?w=500"}
                                        alt={article.title}
                                        className="w-full h-48 object-cover"
                                    />
                                </Link>
                                <CardHeader>
                                    <CardTitle className="text-xl h-20 line-clamp-3">
                                        <Link to={`/blog/${article.slug}`} className="hover:text-primary transition-colors">
                                            {article.title}
                                        </Link>
                                    </CardTitle>
                                    <div className="flex items-center text-xs text-muted-foreground space-x-4 pt-2">
                                        <div className="flex items-center">
                                            <Calendar className="mr-1.5 h-4 w-4" />
                                            <span>{new Date(article.date).toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
                                        </div>
                                        <div className="flex items-center">
                                            <User className="mr-1.5 h-4 w-4" />
                                            <span>{article.author}</span>
                                        </div>
                                    </div>
                                </CardHeader>
                                <CardContent className="flex-grow">
                                    <CardDescription className="line-clamp-4">{article.description}</CardDescription>
                                </CardContent>
                                <div className="p-6 pt-0">
                                     <Button asChild variant="link" className="p-0 h-auto text-primary">
                                        <Link to={`/blog/${article.slug}`}>
                                            Baca Selengkapnya →
                                        </Link>
                                    </Button>
                                </div>
                            </Card>
                        </motion.div>
                    ))}
                </motion.div>
            </div>
        </>
    );
};

export default BlogPage;