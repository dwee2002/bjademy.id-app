import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { WhatsAppIcon } from "@/components/icons/WhatsAppIcon";
import SEO from '@/components/SEO';
import { useToast } from "@/components/ui/use-toast";

const RegistrationPage = () => {
    const { toast } = useToast();
    const phoneNumber = "6282211113049";
    const whatsappMessage = encodeURIComponent("Halo Bratajaya Academy, saya ingin mendaftar program bimbingan. Mohon informasinya.");

    const handleSubmit = (e) => {
        e.preventDefault();
        toast({
            title: "🚧 Fitur Dalam Pengembangan",
            description: "Pendaftaran online melalui form akan segera hadir. Untuk saat ini, silakan daftar melalui WhatsApp.",
        });
    };

    return (
        <>
            <SEO
                title="Pendaftaran Online Bimbel TNI & Polri | Bratajaya Academy"
                description="Daftar online bimbel TNI & Polri di Bratajaya Academy. Mulai persiapan Anda dari Jakarta, Tangerang, Depok, atau Bekasi untuk menjadi taruna sukses. Hubungi kami via WhatsApp untuk pendaftaran cepat."
                keywords="Daftar Bimbel Akpol, Pendaftaran Online TNI Polri, Formulir Bimbel Jakarta, Pendaftaran Bratajaya Academy Tangerang, Cara daftar bimbel Polri, Bimbel Akpol Depok, Bimbel TNI Bekasi"
                pageUrl="/pendaftaran"
            />
            <div className="container mx-auto px-4 py-16">
                <motion.div
                    initial={{ y: -20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ duration: 0.7 }}
                    className="text-center mb-12"
                >
                    <h1 className="text-4xl sm:text-5xl font-bold text-primary">Pendaftaran Bratajaya Academy</h1>
                    <p className="mt-4 text-lg text-muted-foreground max-w-3xl mx-auto">
                        Ambil langkah pertama menuju karir impian Anda sebagai abdi negara. Kami siap membimbing Anda dari Jakarta, Tangerang, Depok, Bekasi, dan sekitarnya.
                    </p>
                </motion.div>

                <div className="grid md:grid-cols-2 gap-12 items-start">
                    <motion.div
                        initial={{ opacity: 0, x: -30 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.8 }}
                        viewport={{ once: true }}
                    >
                        <Card className="w-full">
                            <CardHeader>
                                <CardTitle className="text-2xl">Formulir Pendaftaran (Segera Hadir)</CardTitle>
                                <CardDescription>
                                    Fitur pendaftaran online melalui formulir ini sedang dalam pengembangan. Silakan gunakan pendaftaran via WhatsApp.
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <form onSubmit={handleSubmit}>
                                    <div className="grid w-full items-center gap-4">
                                        <div className="flex flex-col space-y-1.5">
                                            <Label htmlFor="name">Nama Lengkap</Label>
                                            <Input id="name" placeholder="Masukkan nama lengkap Anda" disabled />
                                        </div>
                                        <div className="flex flex-col space-y-1.5">
                                            <Label htmlFor="phone">Nomor Telepon</Label>
                                            <Input id="phone" placeholder="Contoh: 081234567890" disabled />
                                        </div>
                                        <div className="flex flex-col space-y-1.5">
                                            <Label htmlFor="email">Email</Label>
                                            <Input id="email" placeholder="emailanda@contoh.com" disabled />
                                        </div>
                                        <Button type="submit" className="w-full" disabled>Kirim Pendaftaran</Button>
                                    </div>
                                </form>
                            </CardContent>
                        </Card>
                    </motion.div>

                    <motion.div
                        initial={{ opacity: 0, x: 30 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.8, delay: 0.2 }}
                        viewport={{ once: true }}
                    >
                        <Card className="bg-primary text-primary-foreground border-secondary">
                             <CardHeader>
                                <CardTitle className="text-2xl text-secondary">Cara Mendaftar Saat Ini</CardTitle>
                                <CardDescription className="text-primary-foreground/80">
                                    Pendaftaran paling cepat dan mudah adalah melalui WhatsApp. Tim kami siap membantu Anda.
                                </CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                <div>
                                    <h4 className="font-semibold text-lg mb-2">Langkah 1: Siapkan Data Diri</h4>
                                    <p className="text-primary-foreground/80">
                                        Siapkan nama lengkap, asal sekolah, dan program yang Anda minati (TNI/Polri/Kedinasan).
                                    </p>
                                </div>
                                <div>
                                    <h4 className="font-semibold text-lg mb-2">Langkah 2: Hubungi Kami</h4>
                                    <p className="text-primary-foreground/80">
                                        Klik tombol di bawah untuk langsung terhubung dengan admin kami melalui WhatsApp.
                                    </p>
                                </div>
                                <a
                                    href={`https://wa.me/${phoneNumber}?text=${whatsappMessage}`}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="w-full"
                                >
                                    <Button className="w-full bg-green-500 hover:bg-green-600 text-white font-bold text-lg">
                                        <WhatsAppIcon className="w-6 h-6 mr-3" />
                                        Daftar via WhatsApp
                                    </Button>
                                </a>
                                <p className="text-center text-sm text-primary-foreground/70">
                                    Nomor Admin: {phoneNumber}
                                </p>
                            </CardContent>
                        </Card>
                    </motion.div>
                </div>
            </div>
        </>
    );
};

export default RegistrationPage;