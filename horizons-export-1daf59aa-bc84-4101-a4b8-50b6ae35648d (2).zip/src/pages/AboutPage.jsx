import React from 'react';
import { motion } from 'framer-motion';
import { Building, Eye, Goal, Users, Award } from 'lucide-react';
import SEO from '@/components/SEO';

const teamMembers = [
  { 
    name: 'IPTU Pol. Alip Amf', 
    role: 'Kordinator Coach (KOKO)', 
    image_url: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/edd1ee3740d0f28726dd91c2f6383cfb.jpg',
    image_description: 'Potret Kordinator Coach (KOKO) IPTU Pol. Alip Amf' 
  },
  { 
    name: 'Ci Mey', 
    role: 'Spesialis Akademik', 
    image_url: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/045376884e3a02a9ebb827770a79b74d.jpg',
    image_description: 'Potret Spesialis Akademik Ci Mey' 
  },
  { 
    name: 'Abdul Ghofur', 
    role: 'Pelatih Jasmani dan Renang', 
    image_url: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/142a779fb2ee623d2cc5223b46de498d.jpg',
    image_description: 'Potret pelatih jasmani dan renang Abdul Ghofur' 
  },
];

const AboutPage = () => {
  const aboutPageSchema = {
    "@context": "https://schema.org",
    "@type": "AboutPage",
    "url": "https://www.bratajayaacademy.id/tentang-bratajaya",
    "mainEntity": {
      "@type": "EducationalOrganization",
      "name": "Bratajaya Academy",
      "description": "Sejarah, visi, misi, dan tim pengajar profesional Bratajaya Academy, bimbel terpercaya untuk calon taruna di Jakarta, Tangerang, Depok, dan Bekasi.",
      "founder": {
        "@type": "Person",
        "name": "IPTU Pol. Alip Amf"
      }
    }
  };

  return (
    <div className="bg-background text-foreground">
      <SEO
        title="Tentang Kami - Sejarah, Visi, Misi | Bratajaya Academy"
        description="Pelajari sejarah, visi, misi, dan tim pengajar profesional Bratajaya Academy, bimbel terpercaya untuk calon taruna di Jakarta, Tangerang, Depok, dan Bekasi."
        keywords="Tentang Bratajaya Academy, Sejarah Bimbel Akpol Tangerang, Visi Misi Bratajaya, Tim Pengajar Profesional TNI Polri, Bimbel Jakarta, Bimbel Depok"
        schema={aboutPageSchema}
        pageUrl="/tentang-bratajaya"
      />
      {/* Hero Section */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="bg-primary text-primary-foreground py-16"
      >
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl sm:text-5xl font-bold">Tentang Bratajaya Academy</h1>
          <p className="mt-4 text-lg max-w-3xl mx-auto text-primary-foreground/80">
            Membentuk Generasi Unggul dari Jakarta, Tangerang, Depok, dan Bekasi untuk Mengabdi pada Negeri.
          </p>
        </div>
      </motion.div>

      {/* Sejarah Section */}
      <div className="container mx-auto px-4 py-16 sm:py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ x: -50, opacity: 0 }}
            whileInView={{ x: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-primary mb-4 flex items-center">
              <Building className="h-8 w-8 mr-3" />
              Sejarah Kami
            </h2>
            <p className="text-muted-foreground mb-4">
              Bratajaya Academy didirikan atas keprihatinan mendalam terhadap banyaknya calon taruna/i dari wilayah Jakarta, Tangerang, Depok, Bekasi dan sekitarnya yang memiliki potensi besar namun gagal dalam seleksi karena kurangnya persiapan yang terarah dan komprehensif. Berangkat dari pengalaman para pendiri yang merupakan praktisi dan akademisi di bidangnya, kami berkomitmen untuk menciptakan sebuah lembaga bimbingan yang tidak hanya fokus pada aspek akademik, tetapi juga membentuk fisik, mental, dan karakter yang tangguh.
            </p>
            <p className="text-muted-foreground">
              Sejak berdiri, kami telah menjadi rumah bagi ribuan pejuang mimpi, membimbing mereka melewati setiap tahapan seleksi yang ketat dengan metode pengajaran yang modern, fasilitas lengkap, dan tim pengajar yang berdedikasi.
            </p>
          </motion.div>
          <motion.div
            className="rounded-lg overflow-hidden shadow-2xl flex items-center justify-center bg-gray-100 p-8"
            initial={{ x: 50, opacity: 0 }}
            whileInView={{ x: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.2 }}
          >
            <img  
              className="w-full h-auto object-contain max-h-[400px]"
              alt="Logo Yayasan Wira Brata Jaya" src="https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/7f535cd146fdc7c08b2713d04d032460.jpg" />
          </motion.div>
        </div>
      </div>

      {/* Visi & Misi Section */}
      <div className="bg-card py-16 sm:py-24">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ x: -50, opacity: 0 }}
              whileInView={{ x: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: 0.2 }}
            >
              <h2 className="text-3xl font-bold text-primary mb-4 flex items-center">
                <Eye className="h-8 w-8 mr-3" />
                Visi Kami
              </h2>
              <p className="text-muted-foreground mb-4">
                Menjadi lembaga bimbingan belajar terdepan dan terpercaya di Indonesia, khususnya di area Jabodetabek, dalam mempersiapkan calon Taruna Akpol, TNI, Polri, dan sekolah kedinasan lainnya yang berintegritas, profesional, dan siap mengabdi kepada bangsa dan negara.
              </p>
               <h2 className="text-3xl font-bold text-primary mb-4 flex items-center">
                <Goal className="h-8 w-8 mr-3" />
                Misi Kami
              </h2>
              <ul className="list-disc list-inside text-muted-foreground space-y-2">
                <li>Menyediakan program bimbingan yang holistik, mencakup aspek akademik, fisik, psikologi, dan mental-spiritual.</li>
                <li>Menggunakan kurikulum yang relevan dan metode pengajaran inovatif.</li>
                <li>Menyediakan fasilitas pendukung yang modern dan lengkap.</li>
                <li>Membentuk karakter siswa yang disiplin, jujur, dan memiliki jiwa korsa.</li>
              </ul>
            </motion.div>
            <motion.div
              className="rounded-lg overflow-hidden shadow-2xl"
              initial={{ x: 50, opacity: 0 }}
              whileInView={{ x: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: 0.2 }}
            >
              <img  
                className="w-full h-full object-cover"
                alt="Gedung Bratajaya Academy sebagai simbol visi dan misi" src="https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/069cb337433ff01556fd7b366bf595b5.jpg" />
            </motion.div>
          </div>
        </div>
      </div>
      
      {/* Success Stat Section */}
      <div className="container mx-auto px-4 py-16 sm:py-24 text-center">
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-primary mb-4 flex items-center justify-center">
            <Award className="h-8 w-8 mr-3" />
            Rekam Jejak Keberhasilan
          </h2>
          <p className="text-2xl text-muted-foreground max-w-4xl mx-auto">
            Dengan bangga kami telah membimbing lebih dari <span className="font-bold text-secondary">2000 siswa</span>, dengan <span className="font-bold text-secondary">tingkat kelulusan 70%</span> yang kini telah sukses menjadi Perwira, Bintara, Praja IPDN, dan abdi negara di berbagai sekolah kedinasan lainnya.
          </p>
        </motion.div>
      </div>

      {/* Tim Pengajar Section */}
      <div className="bg-card py-16 sm:py-24">
        <div className="container mx-auto px-4">
          <motion.div
            className="text-center mb-12"
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-primary mb-4 flex items-center justify-center">
              <Users className="h-8 w-8 mr-3" />
              Tim Pengajar Profesional
            </h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Kami didukung oleh tim pengajar yang terdiri dari para ahli di bidangnya, termasuk perwira aktif, purnawirawan, akademisi, dan psikolog.
            </p>
          </motion.div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {teamMembers.map((member, index) => (
              <motion.div
                key={index}
                className="text-center"
                initial={{ y: 50, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.7, delay: index * 0.2 }}
              >
                <div className="relative w-40 h-40 mx-auto mb-4">
                  <img 
                    className="rounded-full w-full h-full object-cover shadow-lg"
                    alt={member.image_description}
                   src={member.image_url} />
                </div>
                <h3 className="text-xl font-bold text-primary">{member.name}</h3>
                <p className="text-secondary font-semibold">{member.role}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;