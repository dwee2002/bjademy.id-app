import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/Input';
import { PlusCircle, Trash2, CheckCircle, Circle } from 'lucide-react';

const ToDoPage = () => {
  const [tasks, setTasks] = useState(() => {
    const savedTasks = localStorage.getItem('tasks');
    return savedTasks ? JSON.parse(savedTasks) : [];
  });
  const [taskInput, setTaskInput] = useState('');

  useEffect(() => {
    localStorage.setItem('tasks', JSON.stringify(tasks));
  }, [tasks]);

  const addTask = () => {
    if (taskInput.trim() !== '') {
      setTasks([...tasks, { id: Date.now(), text: taskInput, completed: false }]);
      setTaskInput('');
    }
  };

  const toggleTask = (id) => {
    setTasks(
      tasks.map((task) =>
        task.id === id ? { ...task, completed: !task.completed } : task
      )
    );
  };

  const deleteTask = (id) => {
    setTasks(tasks.filter((task) => task.id !== id));
  };

  const handleKeyPress = (event) => {
    if (event.key === 'Enter') {
      addTask();
    }
  };

  return (
    <div className="dt-app-container">
      <motion.h1 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="dt-app-title"
      >
        DT daftartugas
      </motion.h1>
      <div className="dt-input-container">
        <Input
          type="text"
          id="taskInput"
          placeholder="Tambahkan tugas..."
          value={taskInput}
          onChange={(e) => setTaskInput(e.target.value)}
          onKeyPress={handleKeyPress}
          className="dt-task-input"
        />
        <Button onClick={addTask} className="dt-add-button">
          <PlusCircle size={18} className="mr-2" />
          Tambah
        </Button>
      </div>
      <ul className="dt-task-list">
        <AnimatePresence>
          {tasks.map((task) => (
            <motion.li
              key={task.id}
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 50, transition: { duration: 0.3 } }}
              transition={{ type: 'spring', stiffness: 300, damping: 25 }}
              className={`dt-task-item ${task.completed ? 'completed' : ''}`}
            >
              <span onClick={() => toggleTask(task.id)} className="dt-task-text">
                {task.completed ? <CheckCircle size={20} className="mr-2 text-green-500" /> : <Circle size={20} className="mr-2 text-gray-400" />}
                {task.text}
              </span>
              <Button onClick={() => deleteTask(task.id)} variant="ghost" size="icon" className="dt-delete-button">
                <Trash2 size={18} className="text-red-500 hover:text-red-700" />
              </Button>
            </motion.li>
          ))}
        </AnimatePresence>
        {tasks.length === 0 && (
           <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="dt-empty-state-message"
           >
            Belum ada tugas. Saatnya produktif!
           </motion.p>
        )}
      </ul>
    </div>
  );
};

export default ToDoPage;