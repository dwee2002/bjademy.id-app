import React from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, UserCircle, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { articles, getArticleBySlug } from '@/data/articles'; // Import articles and getArticleBySlug
import SEO from '@/components/SEO';

const ArticleDetailPage = () => {
  const { slug } = useParams();
  const navigate = useNavigate();
  const article = getArticleBySlug(slug);

  React.useEffect(() => {
    if (!article) {
      const timer = setTimeout(() => {
        navigate('/blog');
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [article, navigate]);

  const articleSchema = article ? {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    "headline": article.title,
    "description": article.description,
    "image": article.image,
    "author": {
      "@type": "Organization",
      "name": "Bratajaya Academy",
      "url": "https://www.bratajayaacademy.id"
    },
    "publisher": {
      "@type": "Organization",
      "name": "Bratajaya Academy",
      "logo": {
        "@type": "ImageObject",
        "url": "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/0f5d91feeec599efec99e5642e6ddb89.jpg"
      }
    },
    "datePublished": article.date,
    "dateModified": article.date
  } : null;
  
  if (!article) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-3xl font-bold text-destructive mb-4">Artikel Tidak Ditemukan</h1>
        <p className="text-muted-foreground">Sepertinya artikel yang Anda cari tidak ada atau telah dihapus. Anda akan diarahkan kembali ke halaman blog.</p>
        <Button asChild variant="link" className="mt-4 text-primary">
          <Link to="/blog">Kembali ke Blog</Link>
        </Button>
      </div>
    );
  }
  
  const formattedDate = article.date
    ? new Date(article.date).toLocaleDateString('id-ID', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      })
    : null;

  return (
    <>
      <SEO
        title={`${article.title}`}
        description={article.description}
        keywords={article.keywords || `tips ${article.category}, ${article.title}, Bratajaya Academy`}
        schema={articleSchema}
        pageUrl={`/blog/${article.slug}`}
        imageUrl={article.image}
      />
      <div className="container mx-auto px-4 py-8 sm:py-12">
        <motion.div 
          className="bg-card text-card-foreground p-6 sm:p-8 rounded-2xl shadow-lg max-w-4xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Button asChild variant="outline" className="mb-6 border-primary/50 text-primary hover:bg-primary/10">
            <Link to="/blog">
              <ArrowLeft className="mr-2 h-4 w-4" /> Kembali ke Semua Artikel
            </Link>
          </Button>
          
          <article>
            <h1 className="text-3xl sm:text-4xl font-bold text-primary mb-3 leading-tight">{article.title}</h1>
            <div className="flex flex-wrap items-center text-sm text-muted-foreground mb-6 space-x-4">
                {formattedDate && (
                 <div className="flex items-center">
                  <Calendar className="w-4 h-4 mr-1.5" />
                  <span>{formattedDate}</span>
                </div>
              )}
              {article.author && (
                <div className="flex items-center">
                  <UserCircle className="w-4 h-4 mr-1.5" />
                  <span>Oleh: {article.author}</span>
                </div>
              )}
            </div>
            
            {article.image && (
              <div className="w-full h-auto rounded-lg shadow-md mb-8 overflow-hidden aspect-video">
                <img 
                  src={article.image}
                  alt={article.title}
                  className="w-full h-full object-cover"
                />
              </div>
            )}
            
            <div className="prose max-w-none prose-lg text-foreground prose-p:leading-relaxed prose-headings:text-primary prose-a:text-primary hover:prose-a:text-secondary"
              dangerouslySetInnerHTML={{ __html: article.content }}
            >
            </div>
          </article>
        </motion.div>
      </div>
    </>
  );
};

export default React.memo(ArticleDetailPage);