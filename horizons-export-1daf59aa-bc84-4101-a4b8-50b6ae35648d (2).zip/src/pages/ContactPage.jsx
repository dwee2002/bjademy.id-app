import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import SEO from '@/components/SEO';
import { Phone, MapPin, Instagram } from 'lucide-react';
import { WhatsAppIcon } from '@/components/icons/WhatsAppIcon';
import TikTokIcon from '@/components/icons/TikTokIcon';

const ContactPage = () => {
    const { toast } = useToast();
    const phoneNumber = "6282211113049";
    const whatsappMessage = encodeURIComponent("Halo Bratajaya Academy, saya ingin bertanya.");

    const contactPageSchema = {
      "@context": "https://schema.org",
      "@type": "ContactPage",
      "url": "https://www.bratajayaacademy.id/kontak",
      "mainEntity": {
        "@type": "LocalBusiness",
        "name": "Bratajaya Academy",
        "image": "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/0f5d91feeec599efec99e5642e6ddb89.jpg",
        "@id": "https://www.bratajayaacademy.id",
        "url": "https://www.bratajayaacademy.id",
        "telephone": "+6282211113049",
        "address": {
          "@type": "PostalAddress",
          "streetAddress": "Jl. Komp. Barata Karya Raya No.291, Karang Tengah",
          "addressLocality": "Tangerang",
          "postalCode": "15157",
          "addressCountry": "ID"
        },
        "geo": {
          "@type": "GeoCoordinates",
          "latitude": -6.2192049,
          "longitude": 106.7089450
        },
        "openingHoursSpecification": {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": [
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday",
            "Saturday",
            "Sunday"
          ],
          "opens": "08:00",
          "closes": "17:00"
        }
      }
    };

    const handleFormSubmit = (e) => {
        e.preventDefault();
        toast({
            title: "🚧 Fitur Dalam Pengembangan",
            description: "Formulir kontak akan segera berfungsi. Untuk saat ini, silakan hubungi kami melalui WhatsApp atau detail kontak yang tersedia.",
        });
    };

    return (
        <>
            <SEO
                title="Kontak & Lokasi Bimbel TNI Polri | Bratajaya Academy"
                description="Hubungi Bratajaya Academy untuk info pendaftaran bimbel TNI & Polri. Kami melayani area Jakarta, Tangerang, Depok, Bekasi. Kunjungi kami atau chat via WhatsApp."
                keywords="Kontak Bratajaya Academy, Alamat Bimbel Akpol Tangerang, WhatsApp Bimbel TNI Jakarta, Lokasi Bimbel Polri Depok, Bimbel Bekasi"
                schema={contactPageSchema}
                pageUrl="/kontak"
            />
            <div className="bg-background">
                <div className="container mx-auto px-4 py-16 sm:py-24">
                    <motion.div
                        initial={{ y: -20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        transition={{ duration: 0.7 }}
                        className="text-center mb-12"
                    >
                        <h1 className="text-4xl sm:text-5xl font-bold text-primary">Hubungi Kami</h1>
                        <p className="mt-4 text-lg text-muted-foreground max-w-3xl mx-auto">
                            Punya pertanyaan? Kami siap membantu. Hubungi kami melalui formulir, WhatsApp, atau kunjungi kami di lokasi.
                        </p>
                    </motion.div>

                    <div className="grid md:grid-cols-2 gap-12 items-start">
                        {/* Contact Info & WhatsApp Guide */}
                        <motion.div
                            initial={{ opacity: 0, x: -30 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            transition={{ duration: 0.8 }}
                            viewport={{ once: true }}
                            className="space-y-8"
                        >
                            <Card>
                                <CardHeader>
                                    <CardTitle>Informasi Kontak</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    <div className="flex items-start space-x-4">
                                        <MapPin className="h-6 w-6 text-primary mt-1" />
                                        <div>
                                            <p className="font-semibold">Alamat</p>
                                            <p className="text-muted-foreground">Jl. Komp. Barata Karya Raya No.291, Karang Tengah, Kota Tangerang</p>
                                        </div>
                                    </div>
                                    <div className="flex items-start space-x-4">
                                        <Phone className="h-6 w-6 text-primary mt-1" />
                                        <div>
                                            <p className="font-semibold">WhatsApp</p>
                                            <a href={`https://wa.me/${phoneNumber}`} className="text-muted-foreground hover:text-primary">0822-1111-3049</a>
                                        </div>
                                    </div>
                                    <div className="flex items-start space-x-4">
                                        <Instagram className="h-6 w-6 text-primary mt-1" />
                                        <div>
                                            <p className="font-semibold">Instagram</p>
                                            <a href="https://www.instagram.com/brata_jaya/" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary">@brata_jaya</a>
                                        </div>
                                    </div>
                                    <div className="flex items-start space-x-4">
                                        <TikTokIcon className="h-6 w-6 text-primary mt-1" />
                                        <div>
                                            <p className="font-semibold">TikTok</p>
                                            <a href="https://www.tiktok.com/@bratajaya2007" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary">@bratajaya2007</a>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>

                            <Card className="bg-primary text-primary-foreground">
                                <CardHeader>
                                    <CardTitle className="text-secondary">Layanan Cepat via WhatsApp</CardTitle>
                                </CardHeader>
                                <CardContent className="text-sm space-y-3">
                                    <p>Untuk respon cepat, silakan sebutkan layanan yang Anda butuhkan:</p>
                                    <ul className="list-none space-y-1 pl-2">
                                        <li>⿡ Informasi Pendaftaran Siswa Baru</li>
                                        <li>⿢ Jadwal Latihan / Kegiatan</li>
                                        <li>⿣ Konsultasi & Bimbingan Seleksi TNI/POLRI</li>
                                        <li>⿤ Kerja Sama / Kunjungan</li>
                                        <li>⿥ Lainnya (Silakan jelaskan lebih lanjut)</li>
                                    </ul>
                                    <p className="font-semibold pt-2">⏰ Jam Operasional: Senin–Sabtu: 08.00–17.00 WIB (Minggu & Hari Libur Tetap Buka)</p>
                                    <Button asChild className="w-full bg-green-500 hover:bg-green-600 text-white mt-4">
                                        <a href={`https://wa.me/${phoneNumber}?text=${whatsappMessage}`} target="_blank" rel="noopener noreferrer">
                                            <WhatsAppIcon className="w-5 h-5 mr-2" /> Hubungi Sekarang
                                        </a>
                                    </Button>
                                </CardContent>
                            </Card>
                        </motion.div>

                        {/* Map and Form */}
                        <motion.div
                            initial={{ opacity: 0, x: 30 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            transition={{ duration: 0.8, delay: 0.2 }}
                            viewport={{ once: true }}
                            className="space-y-8"
                        >
                             <Card>
                                <CardHeader>
                                    <CardTitle>Lokasi Kami</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="aspect-w-16 aspect-h-9 rounded-lg overflow-hidden">
                                        <iframe
                                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.337390453881!2d106.7089450747495!3d-6.219204993768835!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f9e14d737f39%3A0x85435f4a849363f!2sBimbel%20Polri%20Tangerang%20Bratajaya%20-%20Bimbel%20TNI%2C%20AKPOL%2C%20BINTARA%2C%20IPDN%2C%20CPNS!5e0!3m2!1sen!2sid!4v1700000000000!5m2!1sen!2sid"
                                            width="100%"
                                            height="300"
                                            style={{ border: 0 }}
                                            allowFullScreen=""
                                            loading="lazy"
                                            referrerPolicy="no-referrer-when-downgrade"
                                            title="Lokasi Bratajaya Academy"
                                        ></iframe>
                                    </div>
                                </CardContent>
                            </Card>
                            <Card>
                                <CardHeader>
                                    <CardTitle>Kirim Pesan (Segera Hadir)</CardTitle>
                                    <CardDescription>Gunakan formulir ini untuk pertanyaan umum.</CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <form onSubmit={handleFormSubmit} className="space-y-4">
                                        <div>
                                            <Label htmlFor="name">Nama</Label>
                                            <Input id="name" placeholder="Nama Anda" disabled />
                                        </div>
                                        <div>
                                            <Label htmlFor="email">Email</Label>
                                            <Input id="email" type="email" placeholder="Email Anda" disabled />
                                        </div>
                                        <div>
                                            <Label htmlFor="message">Pesan</Label>
                                            <Textarea id="message" placeholder="Tulis pesan Anda di sini..." disabled />
                                        </div>
                                        <Button type="submit" className="w-full" disabled>Kirim Pesan</Button>
                                    </form>
                                </CardContent>
                            </Card>
                        </motion.div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default ContactPage;