import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, User, Users, CheckCircle, BookOpen, Target, Computer } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import SEO from '@/components/SEO';

const programData = [
  {
    icon: <Users className="h-10 w-10 text-secondary" />,
    title: "Kelas Reguler",
    description: "Program bimbingan intensif dalam kelompok belajar yang kondusif. Cocok untuk membangun fondasi yang kuat bersama teman seperjuangan.",
    features: ["Jadwal Terstruktur", "Diskusi Kelompok", "Tryout Berkala", "Modul Lengkap"],
  },
  {
    icon: <User className="h-10 w-10 text-secondary" />,
    title: "Kelas Privat",
    description: "Bimbingan eksklusif satu-satu dengan pengajar terbaik kami. Fokus pada kebutuhan spesifik Anda untuk hasil yang maksimal.",
    features: ["Jadwal Fleksibel", "Pendampingan Personal", "Materi Disesuaikan", "Konsultasi Mendalam"],
  },
  {
    icon: <Calendar className="h-10 w-10 text-secondary" />,
    title: "Kelas Jumat-Minggu",
    description: "Program akhir pekan yang dirancang khusus bagi Anda yang memiliki kesibukan di hari kerja. Tetap produktif tanpa mengganggu rutinitas.",
    features: ["Intensif di Akhir Pekan", "Materi Ringkas & Efektif", "Cocok untuk Pelajar/Pekerja", "Latihan Terfokus"],
  },
];

const moduleData = [
    { icon: <BookOpen className="h-8 w-8 text-primary" />, title: "Modul Akademik" },
    { icon: <Target className="h-8 w-8 text-primary" />, title: "Modul Psikotes" },
    { icon: <Computer className="h-8 w-8 text-primary" />, title: "Simulasi CAT" },
];

const ProgramsPage = () => {
    const programsPageSchema = {
      "@context": "https://schema.org",
      "@type": "ItemList",
      "name": "Program Bimbingan Bratajaya Academy",
      "description": "Pilihan program bimbingan belajar di Bratajaya Academy: Kelas Reguler, Privat, dan Jumat-Minggu untuk persiapan TNI, Polri, dan sekolah kedinasan.",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "item": {
            "@type": "EducationalCourse",
            "name": "Kelas Reguler",
            "description": "Program bimbingan intensif dalam kelompok belajar yang kondusif."
          }
        },
        {
          "@type": "ListItem",
          "position": 2,
          "item": {
            "@type": "EducationalCourse",
            "name": "Kelas Privat",
            "description": "Bimbingan eksklusif satu-satu dengan pengajar terbaik kami."
          }
        },
        {
          "@type": "ListItem",
          "position": 3,
          "item": {
            "@type": "EducationalCourse",
            "name": "Kelas Jumat-Minggu",
            "description": "Program akhir pekan yang dirancang khusus bagi Anda yang memiliki kesibukan di hari kerja."
          }
        }
      ]
    };

    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
          opacity: 1,
          transition: { staggerChildren: 0.3 },
        },
    };

    const itemVariants = {
        hidden: { y: 20, opacity: 0 },
        visible: { y: 0, opacity: 1, transition: { type: 'spring' } },
    };

    return (
        <div className="bg-background">
            <SEO
                title="Program & Jadwal Kelas Bimbel TNI Polri | Bratajaya Academy"
                description="Pilih program bimbel TNI & Polri terbaik di Jakarta, Tangerang, Depok, dan Bekasi. Tersedia kelas reguler, privat, dan akhir pekan di Bratajaya Academy."
                keywords="Program Bimbel Akpol Jakarta, Jadwal Kelas TNI Polri Tangerang, Kelas Privat Akpol Depok, Bimbel Akhir Pekan Bekasi, Bimbel Kedinasan"
                schema={programsPageSchema}
                pageUrl="/program"
            />
            {/* Header Section */}
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7 }}
                className="bg-primary text-primary-foreground py-16"
            >
                <div className="container mx-auto px-4 text-center">
                    <h1 className="text-4xl sm:text-5xl font-bold">Program & Jadwal Kelas</h1>
                    <p className="mt-4 text-lg max-w-3xl mx-auto text-primary-foreground/80">
                        Kami menyediakan program terbaik untuk calon taruna dari Jakarta, Tangerang, Depok, Bekasi, dan sekitarnya.
                    </p>
                </div>
            </motion.div>

            {/* Programs Section */}
            <div className="container mx-auto px-4 py-16 sm:py-24">
                <motion.div
                    className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
                    variants={containerVariants}
                    initial="hidden"
                    whileInView="visible"
                    viewport={{ once: true, amount: 0.2 }}
                >
                    {programData.map((program, index) => (
                        <motion.div
                            key={index}
                            variants={itemVariants}
                            className="bg-card border border-border rounded-lg shadow-lg p-8 flex flex-col text-center hover:shadow-xl hover:-translate-y-2 transition-all duration-300"
                        >
                            <div className="flex justify-center mb-4">{program.icon}</div>
                            <h2 className="text-2xl font-bold text-primary mb-3">{program.title}</h2>
                            <p className="text-muted-foreground mb-6 flex-grow">{program.description}</p>
                            <ul className="space-y-3 text-left mb-8">
                                {program.features.map((feature, i) => (
                                    <li key={i} className="flex items-center">
                                        <CheckCircle className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                                        <span className="text-muted-foreground">{feature}</span>
                                    </li>
                                ))}
                            </ul>
                            <Button asChild className="mt-auto bg-secondary text-secondary-foreground hover:bg-secondary/90">
                                <Link to="/pendaftaran">Daftar Program Ini</Link>
                            </Button>
                        </motion.div>
                    ))}
                </motion.div>
            </div>

            {/* Modules & Facilities Section */}
            <div className="bg-card py-16 sm:py-24">
                <div className="container mx-auto px-4">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.7 }}
                        className="text-center"
                    >
                        <h2 className="text-3xl sm:text-4xl font-bold text-primary">Modul & Fasilitas Terlengkap</h2>
                        <p className="mt-4 text-lg max-w-3xl mx-auto text-muted-foreground">
                            Kami membekali Anda dengan materi dan fasilitas terbaik untuk menaklukkan semua tahapan tes.
                        </p>
                    </motion.div>
                    <motion.div
                        className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12"
                        variants={containerVariants}
                        initial="hidden"
                        whileInView="visible"
                        viewport={{ once: true, amount: 0.2 }}
                    >
                        {moduleData.map((module, index) => (
                             <motion.div
                                key={index}
                                variants={itemVariants}
                                className="bg-background p-6 rounded-lg shadow-md text-center"
                            >
                                <div className="flex justify-center mb-4">{module.icon}</div>
                                <h3 className="text-xl font-bold text-primary">{module.title}</h3>
                            </motion.div>
                        ))}
                    </motion.div>
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.7, delay: 0.5 }}
                        className="text-center mt-12"
                    >
                        <p className="text-muted-foreground">
                            Semua modul dan fasilitas kami dirancang untuk memberikan pengalaman belajar yang komprehensif dan realistis.
                        </p>
                        <Button asChild size="lg" variant="outline" className="mt-6 border-secondary text-secondary hover:bg-secondary/10">
                            <Link to="/kontak">Hubungi Kami untuk Jadwal Detail</Link>
                        </Button>
                    </motion.div>
                </div>
            </div>
        </div>
    );
};
export default ProgramsPage;