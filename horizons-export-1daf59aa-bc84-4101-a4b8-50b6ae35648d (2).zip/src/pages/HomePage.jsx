import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ShieldCheck, BookOpen, Target, HeartHandshake, Computer, Award, Users, TrendingUp, Globe, Instagram, Phone } from 'lucide-react';
import SEO from '@/components/SEO';

const HomePage = () => {

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.2, delayChildren: 0.3 },
    },
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: 'spring' } },
  };

  const homePageSchema = {
    "@context": "https://schema.org",
    "@type": "EducationalOrganization",
    "name": "Bratajaya Academy",
    "url": "https://www.bratajayaacademy.id",
    "logo": "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/0f5d91feeec599efec99e5642e6ddb89.jpg",
    "description": "Bimbel persiapan Taruna Akpol, TNI, & Polri terdepan di Jakarta, Tangerang, Depok, dan Bekasi. Program lengkap: Jasmani, Akademik, Psikotes. Siap jadi abdi negara!",
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "Jl. Komp. Barata Karya Raya No.291",
      "addressLocality": "Tangerang",
      "addressRegion": "Banten",
      "postalCode": "15157",
      "addressCountry": "ID"
    },
    "contactPoint": {
      "@type": "ContactPoint",
      "telephone": "+62-822-1111-3049",
      "contactType": "Customer Service"
    }
  };

  const programHighlights = [
    { icon: <ShieldCheck className="h-10 w-10 text-secondary" />, title: 'Jasmani', description: 'Latihan fisik terstruktur untuk memenuhi standar ketat seleksi.' },
    { icon: <BookOpen className="h-10 w-10 text-secondary" />, title: 'Akademik', description: 'Pendalaman materi pelajaran yang diujikan dengan metode efektif.' },
    { icon: <Target className="h-10 w-10 text-secondary" />, title: 'Psikotes', description: 'Simulasi dan bimbingan untuk menghadapi tes psikologi dengan percaya diri.' },
    { icon: <HeartHandshake className="h-10 w-10 text-secondary" />, title: 'Mental & Rohani', description: 'Pembinaan karakter dan mental untuk membentuk calon abdi negara yang tangguh.' },
  ];

  const successStats = [
    { icon: <TrendingUp className="h-10 w-10 text-primary" />, value: '70%', label: 'Tingkat Kelulusan' },
    { icon: <Users className="h-10 w-10 text-primary" />, value: '2000+', label: 'Siswa Dibimbing' },
    { icon: <Award className="h-10 w-10 text-primary" />, label: 'Menjadi Perwira, Bintara, IPDN & Sekolah Kedinasan' },
  ];

  return (
    <div className="flex flex-col">
      <SEO schema={homePageSchema} pageUrl="/" />
      {/* Hero Section */}
      <section className="bg-primary text-primary-foreground py-20 sm:py-32">
        <div className="container mx-auto px-4 text-center">
          <motion.h1 
            className="text-4xl sm:text-6xl font-bold mb-4"
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.7 }}
          >
            Keringat Hari Ini, <br/> <span className="text-secondary">Seragam Impian</span> Esok Hari
          </motion.h1>
          <motion.p 
            className="max-w-2xl mx-auto text-lg sm:text-xl text-primary-foreground/80 mb-8"
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.7, delay: 0.2 }}
          >
            Bratajaya Academy adalah partner terpercaya Anda di Jakarta, Tangerang, Depok, dan Bekasi dalam mempersiapkan diri menjadi Taruna Akpol, TNI, dan Polri.
          </motion.p>
          <motion.div 
            className="flex flex-col sm:flex-row gap-4 justify-center"
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.7, delay: 0.2 }}
          >
            <Button asChild size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/90">
              <Link to="/pendaftaran">Daftar Sekarang</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="border-secondary text-secondary hover:bg-secondary/10">
              <a href="https://wa.me/6282211113049?text=Halo%20Bratajaya%20Academy%2C%20saya%20tertarik%20untuk%20mendaftar.%20Mohon%20informasinya." target="_blank" rel="noopener noreferrer">Konsultasi via WhatsApp</a>
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Program Highlights Section */}
      <section className="py-16 sm:py-24 bg-background">
        <div className="container mx-auto px-4">
          <motion.div 
            className="text-center mb-12"
            initial={{ y: 20, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-primary">Program Unggulan di Jabodetabek</h2>
            <p className="max-w-2xl mx-auto text-muted-foreground mt-2">Fokus pada 4 pilar utama untuk memastikan kesiapan 100% calon taruna dari Jakarta, Tangerang, Depok, dan Bekasi.</p>
          </motion.div>
          <motion.div 
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.2 }}
          >
            {programHighlights.map((program, index) => (
              <motion.div 
                key={index} 
                className="bg-card p-6 rounded-lg shadow-md text-center"
                variants={itemVariants}
              >
                <div className="flex justify-center mb-4">{program.icon}</div>
                <h3 className="text-xl font-bold text-primary mb-2">{program.title}</h3>
                <p className="text-muted-foreground text-sm">{program.description}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Success Story Section */}
      <section className="py-16 sm:py-24 bg-primary/5">
        <div className="container mx-auto px-4">
          <motion.div
            className="text-center mb-12"
            initial={{ y: 20, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-primary">Kisah Sukses Kami</h2>
            <p className="max-w-3xl mx-auto text-muted-foreground mt-2">Angka bukan segalanya, tapi ini adalah bukti komitmen dan kualitas bimbingan kami.</p>
          </motion.div>
          <motion.div
            className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.2 }}
          >
            {successStats.map((stat, index) => (
              <motion.div key={index} className="bg-card p-8 rounded-lg shadow-md" variants={itemVariants}>
                <div className="flex justify-center mb-4">{stat.icon}</div>
                {stat.value && <p className="text-4xl font-bold text-secondary">{stat.value}</p>}
                <p className="text-lg font-semibold text-primary mt-2">{stat.label}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Facilities Section */}
      <section className="py-16 sm:py-24 bg-card">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ x: -50, opacity: 0 }}
              whileInView={{ x: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <h2 className="text-3xl sm:text-4xl font-bold text-primary mb-4">Fasilitas & Simulasi CAT Modern</h2>
              <p className="text-muted-foreground mb-6">
                Kami menyediakan fasilitas simulasi Computer Assisted Test (CAT) untuk akademik dan psikologi yang lengkap dan selalu diperbarui. Dengan modul yang komprehensif, siswa dapat berlatih dalam lingkungan yang mirip dengan tes sesungguhnya, meningkatkan kecepatan, ketepatan, dan kepercayaan diri.
              </p>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start">
                  <Computer className="h-6 w-6 text-secondary mr-3 mt-1 flex-shrink-0" />
                  <span>Bank soal ter-update sesuai standar seleksi terbaru.</span>
                </li>
                <li className="flex items-start">
                  <Computer className="h-6 w-6 text-secondary mr-3 mt-1 flex-shrink-0" />
                  <span>Sistem penilaian otomatis dengan analisis hasil yang mendalam.</span>
                </li>
                <li className="flex items-start">
                  <Computer className="h-6 w-6 text-secondary mr-3 mt-1 flex-shrink-0" />
                  <span>Jadwal fleksibel untuk latihan mandiri maupun terstruktur.</span>
                </li>
              </ul>
              <Button asChild size="lg" className="mt-8 bg-secondary text-secondary-foreground hover:bg-secondary/90">
                <Link to="/galeri">Lihat Galeri Fasilitas</Link>
              </Button>
            </motion.div>
            <motion.div
              className="rounded-lg overflow-hidden shadow-2xl"
              initial={{ x: 50, opacity: 0 }}
              whileInView={{ x: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: 0.2 }}
            >
              <img  
                className="w-full h-full object-cover" 
                alt="Siswa Bratajaya Academy sedang mengikuti sesi simulasi Computer Assisted Test (CAT) dengan fokus dan serius." src="https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/89c3b2b9d9aacea30fb566b0b982c4d3.jpg" />
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Call to Action Section */}
      <section className="bg-gray-100 dark:bg-gray-800 py-16 sm:py-20">
        <div className="container mx-auto px-4 text-center">
            <motion.h2 
                className="text-3xl sm:text-4xl font-bold text-primary mb-4"
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
            >
                Ayo Gabung dan Siapkan Masa Depanmu!
            </motion.h2>
            <motion.p 
                className="text-muted-foreground mb-8 max-w-2xl mx-auto"
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.1 }}
            >
                Karier sebagai Taruna Akpol, Taruna TNI, maupun Bintara Polri/TNI adalah impian yang bisa diraih dengan persiapan yang tepat. Bratajaya Academy siap menemani setiap langkahmu menuju cita-cita.
            </motion.p>
            <motion.div
                className="flex flex-wrap justify-center items-center gap-4"
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.2 }}
            >
                <Button asChild size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/90">
                    <a href="https://wa.me/6282211113049" target="_blank" rel="noopener noreferrer" className="flex items-center">
                        <Phone className="h-5 w-5 mr-2" /> WhatsApp Admin
                    </a>
                </Button>
                <Button asChild size="lg" variant="outline">
                    <a href="https://www.instagram.com/bratajayaacademy" target="_blank" rel="noopener noreferrer" className="flex items-center">
                        <Instagram className="h-5 w-5 mr-2" /> @bratajayaacademy
                    </a>
                </Button>
                 <Button asChild size="lg" variant="outline">
                    <a href="http://www.bratajayaacademy.id" target="_blank" rel="noopener noreferrer" className="flex items-center">
                        <Globe className="h-5 w-5 mr-2" /> www.bratajayaacademy.id
                    </a>
                </Button>
            </motion.div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;