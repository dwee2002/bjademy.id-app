import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/Input';
import { Send, Bot, User, Loader } from 'lucide-react';
import OpenAI from 'openai';

const apiKey = "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";

const openai = new OpenAI({
  apiKey: apiKey,
  dangerouslyAllowBrowser: true
});

const ChatbotPage = () => {
  const [messages, setMessages] = useState([]);
  const [userInput, setUserInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    try {
      const storedMessages = JSON.parse(localStorage.getItem('chatMessages'));
      if (storedMessages && storedMessages.length > 0) {
        setMessages(storedMessages);
      } else {
        setMessages([
          { 
            text: "Halo! Saya adalah asisten AI dari Catatan Coklat. Anda bisa bertanya tentang hukum, prosedur pelaporan, atau topik kepolisian lainnya. Apa yang ingin Anda konsultasikan hari ini?", 
            sender: 'bot' 
          }
        ]);
      }
    } catch (error) {
      console.error("Failed to parse messages from localStorage", error);
      setMessages([
        { 
          text: "Halo! Selamat datang di Catatan Coklat.", 
          sender: 'bot' 
        }
      ]);
    }
  }, []);

  useEffect(() => {
    if (messages.length > 0) {
        localStorage.setItem('chatMessages', JSON.stringify(messages));
    }
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };
  
  const handleSendMessage = async () => {
    const messageText = userInput.trim();
    if (!messageText || isLoading) return;

    const newUserMessage = { text: messageText, sender: 'user' };
    const newMessages = [...messages, newUserMessage];
    setMessages(newMessages);
    setUserInput('');
    setIsLoading(true);
    
    try {
      const systemMessage = {
        role: "system",
        content: "Anda adalah asisten AI dari Catatan Coklat. Anda adalah chatbot yang membantu pengguna dengan pertanyaan terkait hukum, prosedur pelaporan, dan topik kepolisian lainnya di Indonesia. Jawablah dengan sopan, informatif, dan dalam bahasa Indonesia."
      };
      
      const apiMessages = newMessages.map(msg => ({
        role: msg.sender === 'user' ? 'user' : 'assistant',
        content: msg.text
      }));

      const completion = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [systemMessage, ...apiMessages],
      });

      const botResponse = completion.choices[0].message.content;
      setMessages(prevMessages => [...prevMessages, { text: botResponse, sender: 'bot' }]);

    } catch (error) {
      console.error("Error calling OpenAI API:", error);
      const errorMessage = "Mohon maaf, terjadi kesalahan saat menghubungi server AI. Silakan coba lagi nanti.";
      setMessages(prevMessages => [...prevMessages, { text: errorMessage, sender: 'bot' }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (event) => {
    if (event.key === 'Enter') {
      handleSendMessage();
    }
  };

  return (
    <motion.div 
      className="container-chatbot"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
    >
      <div className="chat-header">
        <Bot className="w-8 h-8 text-primary" />
        <div className="ml-4">
          <h1 className="title-chatbot">Konsultasi AI Catatan Coklat</h1>
          <p className="status-chatbot">Online</p>
        </div>
      </div>
      <div className="chatbox">
        <div className="messages-chatbot">
          {messages.map((msg, index) => (
            <motion.div
              key={index}
              className={`flex items-end my-2 gap-2 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              {msg.sender === 'bot' && <Bot className="w-6 h-6 text-primary flex-shrink-0" />}
              <div
                className={`p-3 rounded-2xl max-w-[80%] break-words shadow-md ${
                  msg.sender === 'user' 
                  ? 'bg-primary text-primary-foreground rounded-br-none' 
                  : 'bg-secondary text-secondary-foreground rounded-bl-none'
                }`}
              >
                {msg.text}
              </div>
              {msg.sender === 'user' && <User className="w-6 h-6 text-primary flex-shrink-0" />}
            </motion.div>
          ))}
          {isLoading && (
            <motion.div className="flex items-end my-2 gap-2 justify-start"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}>
              <Bot className="w-6 h-6 text-primary flex-shrink-0" />
              <div className="p-3 rounded-2xl bg-secondary text-secondary-foreground rounded-bl-none">
                <Loader className="w-5 h-5 animate-spin" />
              </div>
            </motion.div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>
      <div className="input-area-chatbot">
        <Input
          type="text"
          id="userInputChatbot"
          placeholder="Ketik pertanyaan Anda..."
          value={userInput}
          onChange={(e) => setUserInput(e.target.value)}
          onKeyPress={handleKeyPress}
          className="input-chatbot" 
          aria-label="User input for chatbot"
          disabled={isLoading}
        />
        <Button onClick={handleSendMessage} className="button-chatbot" aria-label="Send message" disabled={isLoading}>
          <Send size={20} />
        </Button>
      </div>
    </motion.div>
  );
};

export default ChatbotPage;