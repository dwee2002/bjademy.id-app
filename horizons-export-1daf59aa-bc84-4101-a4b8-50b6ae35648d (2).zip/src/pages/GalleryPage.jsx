import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import SEO from '@/components/SEO';

const galleryData = {
  akademik: [
    {
      id: 1,
      src: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/ea26fcfadfa4970f0f1c9fcb72f5af6f.jpg",
      alt: "Sesi belajar akademik intensif di Bratajaya Academy",
      description: "Suasana belajar yang fokus dan kondusif di kelas akademik."
    },
    {
      id: 10,
      src: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/c4d1dd50e60f71f32edff0a18453c3c7.jpg",
      alt: "Alumni sukses Bratajaya Academy",
      description: "70% dari 2000+ siswa kami telah berhasil menjadi Perwira, Bintara, dan masuk sekolah kedinasan lainnya."
    },
    {
      id: 2,
      src: "https://bratajayaacademy.id/wp-content/uploads/2024/06/IMG_4474-1024x768.jpg",
      alt: "Diskusi kelompok siswa bimbingan belajar Akpol",
      description: "Siswa Bratajaya Academy berdiskusi memecahkan soal-soal akademik bersama."
    },
    {
      id: 3,
      src: "https://bratajayaacademy.id/wp-content/uploads/2024/06/IMG_4487-1024x768.jpg",
      alt: "Pengajar memberikan materi di kelas",
      description: "Pengajar profesional sedang menjelaskan materi persiapan tes akademik TNI/Polri."
    },
  ],
  jasmani: [
    {
        id: 17,
        src: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/0cdf17a4cff1fff8430e9a836fe6aa58.jpg",
        alt: "Pelatihan renang Bratajaya di kolam renang Bulungan",
        description: "Sesi latihan renang intensif di kolam renang standar olimpiade, Bulungan, untuk persiapan tes jasmani."
    },
    {
        id: 15,
        src: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/37155cc6ace7e0be07b6871f2146765b.jpg",
        alt: "Pelatihan jasmani siswa Bratajaya Academy yang dapat dipantau orang tua",
        description: "Sesi latihan fisik di lapangan yang didokumentasikan agar orang tua dapat memantau perkembangan putra-putrinya."
    },
    {
        id: 12,
        src: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/f30f168c549f104c92eee4f78e733b10.jpg",
        alt: "Pelatih profesional memimpin latihan fisik di lapangan",
        description: "Latihan baris-berbaris di bawah bimbingan pelatih profesional di fasilitas lapangan yang memadai."
    },
    {
      id: 4,
      src: "https://bratajayaacademy.id/wp-content/uploads/2024/06/IMG_4546-1024x768.jpg",
      alt: "Latihan fisik lari di lapangan",
      description: "Siswa Bratajaya Academy sedang melakukan latihan lari untuk meningkatkan ketahanan fisik."
    },
    {
      id: 5,
      src: "https://bratajayaacademy.id/wp-content/uploads/2024/06/IMG_4584-1-1024x768.jpg",
      alt: "Sesi latihan pull-up untuk tes jasmani",
      description: "Calon taruna berlatih pull-up di bawah bimbingan instruktur."
    },
  ],
  mentalRohani: [
    {
      id: 6,
      src: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/08d53631694617752aeb2977a42ec13c.jpg",
      alt: "Kegiatan pembinaan mental dan rohani siswa Bratajaya Academy",
      description: "Sesi pembinaan rohani melalui kegiatan mengaji bersama untuk memperkuat mental dan spiritual."
    },
    {
        id: 7,
        src: "https://bratajayaacademy.id/wp-content/uploads/2024/06/IMG_4591-1024x768.jpg",
        alt: "Sesi motivasi dan pembinaan karakter",
        description: "Instruktur memberikan sesi motivasi untuk membangun mental juara para calon taruna."
    }
  ],
  psikotes: [
    {
      id: 13,
      src: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/1ba13974e5dea0c22860c6e4bd907b2c.jpg",
      alt: "Sesi psikotes untuk calon taruna di Bratajaya Academy",
      description: "Siswa mengikuti sesi psikotes yang dirancang untuk mempersiapkan mereka menghadapi seleksi sekolah kedinasan."
    },
    {
      id: 16,
      src: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/21d26b1366d3b20db71346d335e8fafa.jpg",
      alt: "Pelatihan psikologi dan pembahasan soal di kelas",
      description: "Instruktur memberikan pembahasan mendalam mengenai soal-soal psikotes untuk melatih kemampuan analisis siswa."
    }
  ],
  fasilitas: [
    {
      id: 8,
      src: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/89c3b2b9d9aacea30fb566b0b982c4d3.jpg",
      alt: "Siswa Bratajaya Academy mengikuti simulasi CAT",
      description: "Fasilitas simulasi Computer Assisted Test (CAT) yang modern dan lengkap untuk persiapan tes akademik dan psikologi."
    },
    {
      id: 12,
      src: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/f30f168c549f104c92eee4f78e733b10.jpg",
      alt: "Fasilitas lapangan untuk latihan jasmani yang lengkap",
      description: "Bratajaya Academy menggunakan fasilitas lapangan yang luas dan profesional untuk menunjang semua kegiatan latihan fisik."
    },
    {
      id: 9,
      src: "https://bratajayaacademy.id/wp-content/uploads/2024/06/IMG_4483-1024x768.jpg",
      alt: "Ruang kelas modern dan nyaman",
      description: "Ruang kelas Bratajaya Academy yang dilengkapi dengan fasilitas modern untuk mendukung proses belajar."
    }
  ],
  testimoni: [
    {
      id: 24,
      src: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/cc0e43947b6e0cff9fb6391cb4d5e19a.jpg",
      alt: "Alumni Polwan Bratajaya Academy berfoto bersama",
      description: "Kebersamaan para alumni Polisi Wanita (Polwan) Bratajaya Academy yang siap mengabdi untuk negeri."
    },
    {
      id: 23,
      src: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/de4a6d94f4debb10d92e46a098b528a2.jpg",
      alt: "Sinergi TNI dan Polri, alumni Bratajaya Academy",
      description: "Bukti nyata sinergi TNI dan Polri, alumni kami siap mengabdi untuk negeri."
    },
    {
      id: 22,
      src: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/01f30de854d14a4e725324b46ed5bf39.jpg",
      alt: "Taruna Akpol Ammar Daffa, alumni Bratajaya Academy",
      description: "Ammar Daffa, salah satu alumni kebanggaan kami yang berhasil menjadi Taruna Akademi Kepolisian."
    },
    {
      id: 21,
      src: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/20448178a8863b1366cb31d86739fc44.jpg",
      alt: "Alumni Bratajaya Academy dilantik menjadi Perwira Polri tahun 2024",
      description: "Momen bahagia alumni Bratajaya Academy setelah dilantik menjadi Perwira Polri, bukti nyata keberhasilan program kami."
    },
    {
      id: 20,
      src: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/b99056840d2530c4273d70aafd111ee5.jpg",
      alt: "Alumni Bratajaya Academy yang sukses menjadi anggota Polri berfoto bersama",
      description: "Kebersamaan para alumni Bratajaya Academy yang telah berhasil mewujudkan cita-cita mereka menjadi anggota Polri."
    },
    {
      id: 19,
      src: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/913850251671569ac3c8d33fde0e1980.jpg",
      alt: "Alumni Bratajaya Academy lulusan Setukpa Polri",
      description: "Alumni Bratajaya Academy yang berhasil lulus dari Setukpa (Sekolah Pembentukan Perwira) Polri."
    },
    {
      id: 18,
      src: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/5d07bfe5f79f3390297521cc8da24797.jpg",
      alt: "Alumni Bratajaya Academy lulusan Perwira Polri 2024",
      description: "Salah satu alumni Bratajaya Academy yang sukses dilantik menjadi Perwira Polri pada tahun 2024."
    },
    {
      id: 14,
      src: "https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/0b0d1a8c542af9d0154a00485906e2cd.jpg",
      alt: "Kisah Sukses Alumni Bratajaya Lolos Sekolah Inspektur Polisi Angkatan 52",
      description: "Bukti nyata keberhasilan alumni Bratajaya Academy yang berhasil lolos seleksi Sekolah Inspektur Polisi."
    }
  ],
};

// Function to filter out items without a valid 'src'
const filterValidImages = (items) => items.filter(item => item.src && item.src.trim() !== '');

// Apply the filter to each category
const filteredGalleryData = {
  akademik: filterValidImages(galleryData.akademik),
  jasmani: filterValidImages(galleryData.jasmani),
  mentalRohani: filterValidImages(galleryData.mentalRohani),
  psikotes: filterValidImages(galleryData.psikotes),
  fasilitas: filterValidImages(galleryData.fasilitas),
  testimoni: filterValidImages(galleryData.testimoni),
};

const allImages = [...filteredGalleryData.akademik, ...filteredGalleryData.jasmani, ...filteredGalleryData.mentalRohani, ...filteredGalleryData.psikotes, ...filteredGalleryData.fasilitas, ...filteredGalleryData.testimoni].filter(
  (image, index, self) => index === self.findIndex((t) => t.id === image.id)
);


const GalleryImage = ({ item }) => (
  <motion.div
    layout
    initial={{ opacity: 0, scale: 0.8 }}
    animate={{ opacity: 1, scale: 1 }}
    exit={{ opacity: 0, scale: 0.8 }}
    transition={{ type: 'spring', stiffness: 260, damping: 20 }}
    className="relative overflow-hidden rounded-lg shadow-lg group"
  >
    <Dialog>
      <DialogTrigger asChild>
        <div className="cursor-pointer">
          <img src={item.src} alt={item.alt} className="w-full h-64 object-cover transition-transform duration-300 group-hover:scale-110" />
          <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-all duration-300 flex items-center justify-center">
            <p className="text-white text-center p-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">{item.alt}</p>
          </div>
        </div>
      </DialogTrigger>
      <DialogContent className="p-0 border-0 max-w-4xl bg-transparent">
        <div className="relative">
         <img src={item.src} alt={item.alt} className="w-full h-auto max-h-[90vh] object-contain rounded-lg" />
        </div>
      </DialogContent>
    </Dialog>
  </motion.div>
);

const GalleryGrid = ({ items }) => (
  <motion.div layout className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
    <AnimatePresence>
      {items.map((item) => <GalleryImage key={item.id} item={item} />)}
    </AnimatePresence>
  </motion.div>
);

const EmptyState = ({ category }) => (
  <div className="text-center py-16">
    <h3 className="text-2xl font-semibold text-primary">Segera Hadir</h3>
    <p className="text-muted-foreground mt-2">Galeri untuk kategori {category} sedang kami persiapkan. Nantikan momen-momen terbaik kami!</p>
  </div>
);


const GalleryPage = () => {
  return (
    <div className="container mx-auto px-4 py-16">
      <SEO
        title="Galeri & Testimoni Sukses | Bimbel TNI Polri Bratajaya Academy"
        description="Lihat galeri kegiatan dan fasilitas bimbel TNI Polri kami di Tangerang, yang melayani siswa dari Jakarta, Depok, dan Bekasi. Saksikan kisah sukses para alumni."
        keywords="Galeri Bratajaya Academy, Foto Latihan Jasmani Akpol, Kegiatan Bimbel TNI Jakarta, Fasilitas Simulasi CAT Tangerang, Testimoni Bimbel Polri"
        pageUrl="/galeri"
      />
      <motion.div
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.7 }}
        className="text-center mb-12"
      >
        <h1 className="text-4xl sm:text-5xl font-bold text-primary">Galeri & Testimoni</h1>
        <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
          Lihat lebih dekat perjuangan dan keberhasilan para siswa Bratajaya Academy dari seluruh Jabodetabek dalam mempersiapkan masa depan mereka.
        </p>
      </motion.div>

      <Tabs defaultValue="semua" className="w-full">
        <TabsList className="grid w-full grid-cols-3 sm:grid-cols-4 md:grid-cols-7 mb-8">
          <TabsTrigger value="semua">Semua</TabsTrigger>
          <TabsTrigger value="akademik">Akademik</TabsTrigger>
          <TabsTrigger value="jasmani">Jasmani</TabsTrigger>
          <TabsTrigger value="mentalRohani">Mental & Rohani</TabsTrigger>
          <TabsTrigger value="psikotes">Psikotes</TabsTrigger>
          <TabsTrigger value="fasilitas">Fasilitas</TabsTrigger>
          <TabsTrigger value="testimoni">Testimoni</TabsTrigger>
        </TabsList>
        <TabsContent value="semua">
          {allImages.length > 0 ? <GalleryGrid items={allImages} /> : <EmptyState category="Semua" />}
        </TabsContent>
        <TabsContent value="akademik">
          {filteredGalleryData.akademik.length > 0 ? <GalleryGrid items={filteredGalleryData.akademik} /> : <EmptyState category="Akademik" />}
        </TabsContent>
        <TabsContent value="jasmani">
          {filteredGalleryData.jasmani.length > 0 ? <GalleryGrid items={filteredGalleryData.jasmani} /> : <EmptyState category="Jasmani" />}
        </TabsContent>
        <TabsContent value="mentalRohani">
            {filteredGalleryData.mentalRohani.length > 0 ? <GalleryGrid items={filteredGalleryData.mentalRohani} /> : <EmptyState category="Mental & Rohani" />}
        </TabsContent>
        <TabsContent value="psikotes">
            {filteredGalleryData.psikotes.length > 0 ? <GalleryGrid items={filteredGalleryData.psikotes} /> : <EmptyState category="Psikotes" />}
        </TabsContent>
        <TabsContent value="fasilitas">
            {filteredGalleryData.fasilitas.length > 0 ? <GalleryGrid items={filteredGalleryData.fasilitas} /> : <EmptyState category="Fasilitas" />}
        </TabsContent>
        <TabsContent value="testimoni">
          {filteredGalleryData.testimoni.length > 0 ? <GalleryGrid items={filteredGalleryData.testimoni} /> : <EmptyState category="Testimoni" />}
        </TabsContent>
      </Tabs>
    </div>
  );
};
export default GalleryPage;