import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

const Hero = ({ onStartConsultation }) => {
  return (
    <motion.section
      id="konsultasi"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 1 }}
      className="bg-secondary py-12 sm:py-20 px-6 text-center hero-custom hidden"
    >
      <div className="container mx-auto">
        <motion.h1
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="text-4xl sm:text-5xl font-bold text-primary mb-4"
        >
          Tanya Hukum Tanpa Ribet
        </motion.h1>
        <motion.p
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.7, delay: 0.4 }}
          className="text-lg sm:text-xl text-gray-700 mb-8"
        >
          Dapatkan informasi hukum dan kepolisian langsung dari AI terpercaya.
        </motion.p>
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.6 }}
        >
          <Button
            onClick={onStartConsultation}
            className="cta-button-custom"
            size="lg"
          >
            Mulai Konsultasi
          </Button>
        </motion.div>
      </div>
    </motion.section>
  );
};

export default Hero;