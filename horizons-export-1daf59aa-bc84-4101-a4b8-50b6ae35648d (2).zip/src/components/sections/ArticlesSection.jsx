import React from 'react';
import ArticleCard from '@/components/ui/ArticleCard';
import { motion } from 'framer-motion';
import { useParams } from 'react-router-dom';
import { categories } from '@/data/categories';

const ArticlesSection = ({ allArticles }) => {
  const { categorySlug } = useParams();

  const articlesToDisplay = categorySlug && categorySlug !== "semua"
    ? allArticles.filter(article => article.category.toLowerCase().replace(/\s+/g, '-') === categorySlug)
    : allArticles;
  
  const currentCategory = categories.find(cat => cat.slug === categorySlug);
  const pageTitle = currentCategory && categorySlug !== "semua" ? currentCategory.name : "Artikel Terbaru";

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1, 
        delayChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { type: 'spring', stiffness: 100 } },
  };
  
  return (
    <section id="artikel" className="mb-12">
      <motion.h1 
        className="text-3xl font-bold text-primary mb-8 pb-2 border-b-2 border-primary/30"
        initial={{ opacity: 0, x: -50 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5 }}
      >
        {pageTitle}
      </motion.h1>
      {articlesToDisplay.length === 0 ? (
        <p className="text-center text-gray-500 text-lg">Belum ada artikel dalam kategori ini.</p>
      ) : (
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 gap-8"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {articlesToDisplay.map((article, index) => (
            <motion.div key={article.slug || index} variants={itemVariants}>
              <ArticleCard article={article} />
            </motion.div>
          ))}
        </motion.div>
      )}
    </section>
  );
};

export default ArticlesSection;