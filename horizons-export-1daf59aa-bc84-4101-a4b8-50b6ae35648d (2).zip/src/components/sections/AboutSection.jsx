import React from 'react';
import { motion } from 'framer-motion';

const AboutSection = () => {
  return (
    <section id="tentang" className="py-12 sm:py-16 px-6 bg-secondary hidden">
      <div className="container mx-auto">
        <motion.h2
          initial={{ y: 20, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-3xl sm:text-4xl font-bold text-primary text-center mb-8"
        >
          Tentang CatatanCoklat.com
        </motion.h2>
        <motion.p
          initial={{ y: 20, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="text-lg text-gray-700 text-center max-w-3xl mx-auto leading-relaxed"
        >
          Catatan Coklat.com adalah platform terbuka untuk informasi hukum dan kepolisian Indonesia, terintegrasi dengan AI agar semua orang dapat mengakses keadilan secara mudah dan cepat.
        </motion.p>
      </div>
    </section>
  );
};

export default AboutSection;