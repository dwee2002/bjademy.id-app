import React from 'react';
import { motion } from 'framer-motion';

const Widget = ({ title, children, className = '' }) => {
  return (
    <motion.section 
      className={`bg-white p-6 rounded-xl shadow-lg ${className}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
    >
      <h3 className="text-xl font-semibold text-primary mb-4 pb-2 border-b border-primary/20">
        {title}
      </h3>
      {children}
    </motion.section>
  );
};

export default Widget;