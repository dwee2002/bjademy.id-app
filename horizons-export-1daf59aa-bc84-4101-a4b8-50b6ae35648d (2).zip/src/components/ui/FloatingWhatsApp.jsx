
import React from 'react';
import { motion } from 'framer-motion';
import { WhatsAppIcon } from '@/components/icons/WhatsAppIcon';

const FloatingWhatsApp = ({ phoneNumber }) => {
  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent('Halo Bratajaya Academy, saya tertarik untuk mendaftar. Mohon informasinya.')}`;

  return (
    <motion.a
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 bg-[#25D366] text-white rounded-full p-3 shadow-lg z-50 flex items-center justify-center"
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ delay: 1, duration: 0.5, type: 'spring' }}
      whileHover={{ scale: 1.1, boxShadow: '0 10px 20px rgba(0,0,0,0.2)' }}
      whileTap={{ scale: 0.9 }}
      aria-label="Hubungi kami via WhatsApp untuk Pendaftaran"
    >
      <WhatsAppIcon className="h-8 w-8" />
    </motion.a>
  );
};

export default FloatingWhatsApp;
