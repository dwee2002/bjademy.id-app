import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, UserCircle, Calendar } from 'lucide-react';

const ArticleCard = ({ article }) => {
  const formattedDate = article.date
    ? new Date(article.date).toLocaleDateString('id-ID', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      })
    : null;

  return (
    <motion.div 
      className="bg-card text-card-foreground rounded-xl shadow-lg overflow-hidden h-full flex flex-col transition-all duration-300 hover:shadow-2xl hover:scale-[1.02]"
      whileHover={{ y: -5 }}
    >
      <Link to={`/artikel/${article.slug}`} className="block h-48 overflow-hidden group">
        {article.image ? (
          <img 
            src={article.image}
            alt={article.title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
        ) : article.image_description ? (
          <img  
            alt={article.title} 
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" src="https://images.unsplash.com/photo-1595872018818-97555653a011" />
        ) : (
          <div className="w-full h-full bg-gray-200 flex items-center justify-center">
            <span className="text-gray-500 text-sm">Gambar tidak tersedia</span>
          </div>
        )}
      </Link>
      <div className="p-6 flex flex-col flex-grow">
        <div className="mb-2">
          {formattedDate && (
             <div className="flex items-center text-xs text-gray-500 mb-2">
              <Calendar className="w-3 h-3 mr-1.5" />
              <span>{formattedDate}</span>
            </div>
          )}
          {article.author && (
            <div className="flex items-center text-xs text-gray-500">
              <UserCircle className="w-3 h-3 mr-1.5" />
              <span>Oleh: {article.author}</span>
            </div>
          )}
        </div>
         <h3 className="text-xl font-semibold text-primary mb-2">
          <Link to={`/artikel/${article.slug}`} className="hover:underline">
            {article.title}
          </Link>
        </h3>
        <p className="text-gray-600 text-sm mb-4 flex-grow">
          {article.description}
        </p>
        <Button asChild variant="outline" className="mt-auto self-start border-primary text-primary hover:bg-primary/10">
          <Link to={`/artikel/${article.slug}`}>
            Baca Selengkapnya <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </div>
    </motion.div>
  );
};

export default React.memo(ArticleCard);