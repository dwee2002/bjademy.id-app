import React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button'; // Assuming Button is a shadcn/ui component

const Pagination = ({ currentPage = 1, totalPages = 3, onPageChange = () => {} }) => {
  const pageNumbers = [];
  for (let i = 1; i <= totalPages; i++) {
    pageNumbers.push(i);
  }

  return (
    <nav className="pagination" aria-label="Page navigation">
      <div className="pagination-prev">
        <Button
          variant="outline"
          size="icon"
          onClick={() => onPageChange(currentPage - 1)}
          disabled={currentPage === 1}
          aria-label="Previous page"
        >
          <ChevronLeft className="h-5 w-5" />
        </Button>
      </div>
      {pageNumbers.map(number => (
        <Button
          key={number}
          variant={currentPage === number ? "default" : "outline"}
          onClick={() => onPageChange(number)}
          className={`pagination-page ${currentPage === number ? 'current' : ''}`}
          aria-current={currentPage === number ? "page" : undefined}
        >
          {number}
        </Button>
      ))}
      <div className="pagination-next">
        <Button
          variant="outline"
          size="icon"
          onClick={() => onPageChange(currentPage + 1)}
          disabled={currentPage === totalPages}
          aria-label="Next page"
        >
          <ChevronRight className="h-5 w-5" />
        </Button>
      </div>
    </nav>
  );
};

export default Pagination;