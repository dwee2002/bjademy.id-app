
import React from 'react';
import { Helmet } from 'react-helmet-async';
import Schema from './Schema';

const SEO = ({ title, description, keywords, schema, pageUrl, imageUrl }) => {
  const defaultTitle = 'Bimbel TNI & Polri Terbaik di Jakarta, Tangerang, Depok, Bekasi | Bratajaya Academy';
  const defaultDescription = 'Bratajaya Academy: Bimbel persiapan Taruna Akpol, TNI, & Polri terdepan di Jakarta, Tangerang, Depok, dan Bekasi. Program lengkap: Jasmani, Akademik, Psikotes. Siap jadi abdi negara!';
  const defaultKeywords = 'Bimbel Akpol Jakarta, Bimbel TNI Tangerang, Bimbel Polri Depok, Bimbel Kedinasan Bekasi, Bimbingan Belajar TNI Polri, Persiapan Masuk Akpol, Latihan Jasmani TNI, Psikotes Polri, Bratajaya Academy';
  const siteUrl = 'https://www.bratajayaacademy.id';
  const defaultImage = 'https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/0f5d91feeec599efec99e5642e6ddb89.jpg';

  const seo = {
    title: title ? `${title}` : defaultTitle,
    description: description || defaultDescription,
    keywords: keywords || defaultKeywords,
    url: pageUrl ? `${siteUrl}${pageUrl}` : siteUrl,
    image: imageUrl || defaultImage,
  };

  return (
    <>
      <Helmet>
        <title>{seo.title}</title>
        <meta name="description" content={seo.description} />
        <meta name="keywords" content={seo.keywords} />
        {/* Open Graph / Facebook */}
        <meta property="og:type" content="website" />
        <meta property="og:url" content={seo.url} />
        <meta property="og:title" content={seo.title} />
        <meta property="og:description" content={seo.description} />
        <meta property="og:image" content={seo.image} />
        {/* Twitter */}
        <meta property="twitter:card" content="summary_large_image" />
        <meta property="twitter:url" content={seo.url} />
        <meta property="twitter:title" content={seo.title} />
        <meta property="twitter:description" content={seo.description} />
        <meta property="twitter:image" content={seo.image} />
      </Helmet>
      {schema && <Schema schema={schema} />}
    </>
  );
};

export default SEO;
