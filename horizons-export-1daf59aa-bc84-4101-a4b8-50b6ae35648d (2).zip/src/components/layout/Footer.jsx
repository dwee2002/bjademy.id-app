
import React from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Phone } from 'lucide-react';
import TikTokIcon from '@/components/icons/TikTokIcon';
import { WhatsAppIcon } from '@/components/icons/WhatsAppIcon';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const quickLinks = [
    { name: 'Tentang Kami', path: '/tentang-bratajaya' },
    { name: 'Program', path: '/program' },
    { name: 'Galeri', path: '/galeri' },
    { name: 'Blog', path: '/blog' },
    { name: 'Pendaftaran', path: '/pendaftaran' },
  ];

  const contactInfo = [
    { 
      icon: <WhatsAppIcon className="h-5 w-5 mr-3" />, 
      text: '0822-1111-3049', 
      href: 'https://wa.me/6282211113049' 
    },
    { 
      icon: <Instagram className="h-5 w-5 mr-3" />, 
      text: '@brata_jaya', 
      href: 'https://www.instagram.com/brata_jaya/' 
    },
    { 
      icon: <TikTokIcon className="h-5 w-5 mr-3" />, 
      text: '@bratajaya2007', 
      href: 'https://www.tiktok.com/@bratajaya2007' 
    },
  ];

  return (
    <footer className="bg-primary text-primary-foreground pt-12 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8 text-center md:text-left">
          {/* About Us */}
          <div className="md:col-span-2">
            <h3 className="text-lg font-bold text-secondary mb-3">Bratajaya Academy</h3>
            <p className="text-sm text-primary-foreground/80">
              Pusat bimbingan belajar terbaik untuk persiapan menjadi Taruna Akpol, TNI, & Polri di Jakarta, Tangerang, Depok, dan Bekasi. Wujudkan impian Anda bersama kami.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold text-secondary mb-3">Tautan Cepat</h3>
            <ul className="space-y-2">
              {quickLinks.map(link => (
                <li key={link.name}>
                  <Link to={link.path} className="text-sm text-primary-foreground/80 hover:text-secondary transition-colors">{link.name}</Link>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Contact Us */}
          <div>
            <h3 className="text-lg font-bold text-secondary mb-3">Hubungi Kami</h3>
            <address className="text-sm not-italic space-y-2 text-primary-foreground/80">
              <p>Jl. Komp. Barata Karya Raya No.291, Karang Tengah, Kota Tangerang</p>
              {contactInfo.map((item, index) => (
                <p key={index} className="flex items-center justify-center md:justify-start">
                   {item.icon}
                  <a href={item.href} target="_blank" rel="noopener noreferrer" className="hover:text-secondary transition-colors">{item.text}</a>
                </p>
              ))}
            </address>
          </div>
        </div>
        <div className="border-t border-primary-foreground/20 pt-6 text-center text-sm text-primary-foreground/60">
          <p>&copy; {currentYear} Bratajaya Academy. Semua Hak Cipta Dilindungi.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
