import React from 'react';
import { motion } from 'framer-motion';
import Widget from '@/components/ui/Widget';
import { Button } from '@/components/ui/button';
import { MessageSquare } from 'lucide-react';
import { Link } from 'react-router-dom';

const Sidebar = ({ categories, articles }) => {
  return (
    <aside className="lg:w-1/3 mt-8 lg:mt-0">
      <Widget title="Kategori Artikel">
        <ul>
          {categories.map((category, index) => (
            <motion.li 
              key={category.slug} 
              className="mb-2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
            >
              <Link to={`/kategori/${category.slug}`} className="text-primary hover:underline hover:text-primary/80 transition-colors">
                {category.name}
              </Link>
            </motion.li>
          ))}
        </ul>
      </Widget>

      <Widget title="Konsultasi AI via WhatsApp" className="chatbot-widget mt-8">
        <p className="mb-4 text-gray-600">
          Butuh konsultasi hukum cepat? Chat langsung dengan agen AI kami.
        </p>
        <Button 
          asChild 
          className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
          size="lg"
        >
          <a href="https://wa.me/62811439899" target="_blank" rel="noopener noreferrer">
            <MessageSquare className="mr-2 h-5 w-5" /> Chat Sekarang
          </a>
        </Button>
      </Widget>
    </aside>
  );
};

export default React.memo(Sidebar);