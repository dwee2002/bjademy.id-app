import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { name: 'Beranda', path: '/' },
    { name: 'Tentang Bratajaya', path: '/tentang-bratajaya' },
    { name: 'Program', path: '/program' },
    { name: 'Galeri', path: '/galeri' },
    { name: 'Blog', path: '/blog' },
    { name: 'Kontak', path: '/kontak' },
  ];

  const menuVariants = {
    closed: { opacity: 0, y: -20 },
    open: { 
      opacity: 1, 
      y: 0,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.1,
      }
    },
    exit: { opacity: 0, y: -20 }
  };
  
  const menuItemVariants = {
    closed: { opacity: 0, y: -10 },
    open: { opacity: 1, y: 0 }
  };

  return (
    <header className="bg-background/80 backdrop-blur-md shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <Link to="/" className="flex items-center space-x-2">
          <img src="https://storage.googleapis.com/hostinger-horizons-assets-prod/1daf59aa-bc84-4101-a4b8-50b6ae35648d/0f5d91feeec599efec99e5642e6ddb89.jpg" alt="Bratajaya Academy Logo" className="h-12 w-auto" />
          <span className="text-xl font-bold text-primary hidden sm:inline">Bratajaya Academy</span>
        </Link>
        <nav className="hidden lg:flex items-center space-x-6">
          {navItems.map((item) => (
            <NavLink
              key={item.name}
              to={item.path}
              className={({ isActive }) =>
                `text-sm font-semibold transition-colors hover:text-secondary ${isActive ? 'text-secondary' : 'text-primary'}`
              }
            >
              {item.name}
            </NavLink>
          ))}
        </nav>
        <div className="hidden lg:block">
            <Button asChild className="bg-secondary text-secondary-foreground hover:bg-secondary/90">
              <Link to="/pendaftaran">Daftar Sekarang</Link>
            </Button>
        </div>
        <div className="lg:hidden">
          <button onClick={() => setIsOpen(!isOpen)} className="text-primary">
            {isOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>
      </div>
      <AnimatePresence>
        {isOpen && (
          <motion.nav 
            variants={menuVariants}
            initial="closed"
            animate="open"
            exit="exit"
            className="lg:hidden bg-background shadow-lg absolute w-full"
          >
            <ul className="flex flex-col items-center py-4">
              {navItems.map((item) => (
                <motion.li key={item.name} variants={menuItemVariants} className="w-full text-center">
                  <NavLink
                    to={item.path}
                    onClick={() => setIsOpen(false)}
                    className={({ isActive }) =>
                      `block py-3 text-lg font-semibold transition-colors hover:bg-secondary/10 ${isActive ? 'text-secondary' : 'text-primary'}`
                    }
                  >
                    {item.name}
                  </NavLink>
                </motion.li>
              ))}
              <motion.li variants={menuItemVariants} className="mt-4">
                <Button asChild className="bg-secondary text-secondary-foreground hover:bg-secondary/90" size="lg" onClick={() => setIsOpen(false)}>
                  <Link to="/pendaftaran">Daftar Sekarang</Link>
                </Button>
              </motion.li>
            </ul>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;