import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import HomePage from '@/pages/HomePage';
import AboutPage from '@/pages/AboutPage';
import ProgramsPage from '@/pages/ProgramsPage';
import GalleryPage from '@/pages/GalleryPage';
import RegistrationPage from '@/pages/RegistrationPage';
import BlogPage from '@/pages/BlogPage';
import ArticleDetailPage from '@/pages/ArticleDetailPage';
import ContactPage from '@/pages/ContactPage';
import FloatingWhatsApp from '@/components/ui/FloatingWhatsApp';
import { HelmetProvider } from 'react-helmet-async';
import { Toaster } from '@/components/ui/toaster';

const App = () => {
  return (
    <HelmetProvider>
      <div className="flex flex-col min-h-screen bg-background">
        <Toaster />
        <Header />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/tentang-bratajaya" element={<AboutPage />} />
            <Route path="/program" element={<ProgramsPage />} />
            <Route path="/galeri" element={<GalleryPage />} />
            <Route path="/pendaftaran" element={<RegistrationPage />} />
            <Route path="/blog" element={<BlogPage />} />
            <Route path="/blog/:slug" element={<ArticleDetailPage />} />
            <Route path="/kontak" element={<ContactPage />} />
          </Routes>
        </main>
        <Footer />
        <FloatingWhatsApp phoneNumber="6282211113049" />
      </div>
    </HelmetProvider>
  );
};

export default App;